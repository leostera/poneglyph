// bench/operator.ts
var tenant = "control:tenant:d9d839ba-4c07-41dc-a5bd-77ccc5763413";
var feature = `${tenant}:feature-settings`;
var credential = `${tenant}:credential-settings`;
var point = `control:config:enabled(${JSON.stringify(feature)}, Enabled)`;
var combined = [
  `control:config:tenant(${JSON.stringify(feature)}, Tenant)`,
  point,
  `control:credential:tenant(${JSON.stringify(credential)}, Tenant)`,
  `control:credential:token-version(${JSON.stringify(credential)}, TokenVersion)`,
  `control:credential:status(${JSON.stringify(credential)}, Status)`
].join(", ");
function response(runId, result) {
  return Response.json({ runId, ...result }, { status: result.kind === "complete" ? 200 : 502 });
}
var operator_default = {
  async fetch(request, env) {
    const path = new URL(request.url).pathname;
    if (request.headers.has("origin")) return new Response("Forbidden", { status: 403 });
    if (path === "/health" && request.method === "GET") return Response.json({ runId: env.RUN_ID, readOnly: true });
    if (request.method !== "POST" || path !== "/point" && path !== "/combined") return new Response("Not found", { status: 404 });
    const started = performance.now();
    try {
      const result = await env.PONEGLYPH.query({ graphId: "control-plane-validation", query: path === "/point" ? point : combined });
      const row = result.rows[0], keys = path === "/point" ? ["Enabled"] : ["Tenant", "Enabled", "TokenVersion", "Status"];
      const expected = result.snapshotSeq === 1 && result.rows.length === 1 && row !== void 0 && Object.keys(row).length === keys.length && keys.every((key) => Object.hasOwn(row, key) && row[key]?.type === "string") && row.Enabled?.value === "false" && (path === "/point" || row.Tenant?.value === tenant && row.Status?.value === "active" && row.TokenVersion?.value === "fake-token-test-only-v0-d9d839ba-4c07-41dc-a5bd-77ccc5763413");
      if (!expected) return response(env.RUN_ID, { kind: "unexpected-answer", hostedMs: performance.now() - started });
      const { timing, cacheHits, treeReadLeaseAcquisitions } = result.metrics;
      if (timing === void 0 || typeof cacheHits !== "number" || typeof treeReadLeaseAcquisitions !== "number") {
        return response(env.RUN_ID, { kind: "invalid-metrics", hostedMs: performance.now() - started });
      }
      return response(env.RUN_ID, { kind: "complete", metrics: {
        snapshotSeq: result.snapshotSeq,
        hostedMs: performance.now() - started,
        serviceMs: timing.executionMs,
        snapshotMs: timing.snapshotMs,
        evaluationMs: timing.evaluationMs,
        releaseMs: timing.releaseMs,
        cacheHits,
        leases: treeReadLeaseAcquisitions
      } });
    } catch {
      return response(env.RUN_ID, { kind: "unavailable", hostedMs: performance.now() - started });
    }
  }
};
export {
  operator_default as default
};
