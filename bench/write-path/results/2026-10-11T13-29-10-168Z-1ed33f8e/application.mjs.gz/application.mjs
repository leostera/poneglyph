// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/domain/date-validation.js
function isCalendarDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match)
    return false;
  return calendarDatePartsAreValid(Number(match[1]), Number(match[2]), Number(match[3]));
}
function isRfc3339Timestamp(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(Z|([+-])(\d{2}):(\d{2}))$/.exec(value);
  if (!match)
    return false;
  const [year, month, day, hour, minute, second] = match.slice(1, 7).map(Number);
  if (year === void 0 || month === void 0 || day === void 0 || hour === void 0 || minute === void 0 || second === void 0 || !calendarDatePartsAreValid(year, month, day) || hour > 23 || minute > 59 || second > 59) {
    return false;
  }
  if (match[8] !== void 0) {
    const offsetHour = Number(match[9]);
    const offsetMinute = Number(match[10]);
    if (offsetHour > 23 || offsetMinute > 59)
      return false;
  }
  return Number.isFinite(Date.parse(value));
}
function calendarDatePartsAreValid(year, month, day) {
  if (month < 1 || month > 12 || day < 1)
    return false;
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return daysInMonth !== void 0 && day <= daysInMonth;
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/domain/result.js
function parsed(value) {
  return { ok: true, value };
}
function rejected(path, message, offset) {
  const error = offset === void 0 ? { path, message } : { path, message, offset };
  return { ok: false, error };
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/domain/identifiers.js
var MAX_URI_LENGTH = 2048;
var MAX_TRANSACTION_ID_BYTES = 256;
function parseUri(input, path = "uri") {
  if (typeof input !== "string" || input.length === 0) {
    return rejected(path, "expected a non-empty URI string");
  }
  if (input.length > MAX_URI_LENGTH) {
    return rejected(path, `URI cannot exceed ${MAX_URI_LENGTH} characters`);
  }
  try {
    return parsed(new URL(input).href);
  } catch {
    return rejected(path, "expected an absolute URI with a scheme");
  }
}
function parseTransactionId(input, path = "txId") {
  if (typeof input === "string" && new TextEncoder().encode(input).byteLength > MAX_TRANSACTION_ID_BYTES) {
    return rejected(path, `transaction ID cannot exceed ${MAX_TRANSACTION_ID_BYTES} UTF-8 bytes`);
  }
  const uri = parseUri(input, path);
  return uri.ok ? parsed(uri.value) : uri;
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/domain/int64.js
var I64_MIN = -(1n << 63n);
var I64_MAX = (1n << 63n) - 1n;
function parseInt64String(input, path) {
  if (typeof input !== "string" || !/^-?(?:0|[1-9][0-9]*)$/.test(input)) {
    return rejected(path, "expected a canonical signed 64-bit integer string");
  }
  try {
    const integer = BigInt(input);
    if (integer >= I64_MIN && integer <= I64_MAX && integer.toString() === input) {
      return parsed(input);
    }
  } catch {
  }
  return rejected(path, "integer is outside the signed 64-bit range");
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/domain/string-order.js
function compareUnicodeScalars(left, right) {
  const leftPoints = Array.from(left, (character) => character.codePointAt(0) ?? 0);
  const rightPoints = Array.from(right, (character) => character.codePointAt(0) ?? 0);
  const length = Math.min(leftPoints.length, rightPoints.length);
  for (let index = 0; index < length; index += 1) {
    const leftPoint = leftPoints[index] ?? 0;
    const rightPoint = rightPoints[index] ?? 0;
    if (leftPoint !== rightPoint)
      return leftPoint < rightPoint ? -1 : 1;
  }
  return leftPoints.length < rightPoints.length ? -1 : leftPoints.length > rightPoints.length ? 1 : 0;
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/domain/fact-value.js
var MAX_VALUE_DEPTH = 64;
function parseFactValue(input, path = "value") {
  return parseAtDepth(input, path, 0);
}
function parseAtDepth(input, path, depth) {
  if (depth > MAX_VALUE_DEPTH) {
    return rejected(path, `fact values cannot be nested more than ${MAX_VALUE_DEPTH} levels`);
  }
  if (!isRecord(input) || typeof input["type"] !== "string") {
    return rejected(path, "expected a tagged fact value");
  }
  switch (input["type"]) {
    case "null":
      if (input["value"] !== void 0 && input["value"] !== null) {
        return rejected(`${path}.value`, "null values cannot carry a payload");
      }
      return parsed(Object.freeze({ type: "null" }));
    case "text":
      return typeof input["value"] === "string" ? parsed(Object.freeze({ type: "text", value: input["value"] })) : rejected(`${path}.value`, "expected a string for text");
    case "number": {
      const number = parseInt64String(input["value"], `${path}.value`);
      return number.ok ? parsed(Object.freeze({ type: "number", value: number.value })) : number;
    }
    case "boolean":
      return typeof input["value"] === "boolean" ? parsed(Object.freeze({ type: "boolean", value: input["value"] })) : rejected(`${path}.value`, "expected a boolean");
    case "bytes":
      return parseBytes(input["value"], `${path}.value`);
    case "reference": {
      const uri = parseUri(input["value"], `${path}.value`);
      return uri.ok ? parsed(Object.freeze({ type: "reference", value: uri.value })) : uri;
    }
    case "date":
      return parseDate(input["value"], `${path}.value`);
    case "date_time":
      return parseDateTime(input["value"], `${path}.value`);
    case "list":
      return parseList(input["value"], `${path}.value`, depth);
    case "map":
      return parseMap(input["value"], `${path}.value`, depth);
    default:
      return rejected(`${path}.type`, `unsupported fact value tag: ${input["type"]}`);
  }
}
function parseBytes(input, path) {
  if (!Array.isArray(input)) {
    return rejected(path, "expected an array of byte values");
  }
  const bytes = [];
  for (const [index, byte] of input.entries()) {
    if (typeof byte !== "number" || !Number.isInteger(byte) || byte < 0 || byte > 255) {
      return rejected(`${path}[${index}]`, "expected an integer between 0 and 255");
    }
    bytes.push(byte);
  }
  return parsed(Object.freeze({ type: "bytes", value: Object.freeze(bytes) }));
}
function parseDate(input, path) {
  if (typeof input !== "string" || !isCalendarDate(input)) {
    return rejected(path, "expected a valid calendar date in YYYY-MM-DD form");
  }
  return parsed(Object.freeze({ type: "date", value: input }));
}
function parseDateTime(input, path) {
  if (typeof input !== "string" || !isRfc3339Timestamp(input)) {
    return rejected(path, "expected an RFC 3339 timestamp with a timezone");
  }
  return parsed(Object.freeze({ type: "date_time", value: input }));
}
function parseList(input, path, depth) {
  if (!Array.isArray(input)) {
    return rejected(path, "expected an array of fact values");
  }
  const values = [];
  for (const [index, item] of input.entries()) {
    const value = parseAtDepth(item, `${path}[${index}]`, depth + 1);
    if (!value.ok)
      return value;
    values.push(value.value);
  }
  return parsed(Object.freeze({ type: "list", value: Object.freeze(values) }));
}
function parseMap(input, path, depth) {
  if (!isRecord(input)) {
    return rejected(path, "expected an object of fact values");
  }
  const entries = Object.entries(input).sort(([left], [right]) => compareUnicodeScalars(left, right));
  const values = /* @__PURE__ */ Object.create(null);
  for (const [key, item] of entries) {
    const value = parseAtDepth(item, `${path}.${key}`, depth + 1);
    if (!value.ok)
      return value;
    values[key] = value.value;
  }
  return parsed(Object.freeze({ type: "map", value: Object.freeze(values) }));
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/domain/fact.js
function parseFactDraft(input, path = "fact") {
  if (!isRecord(input))
    return rejected(path, "expected a fact object");
  const source = parseUri(input["source"], `${path}.source`);
  if (!source.ok)
    return source;
  const entity = parseUri(input["entity"], `${path}.entity`);
  if (!entity.ok)
    return entity;
  const field = parseUri(input["field"], `${path}.field`);
  if (!field.ok)
    return field;
  const value = parseFactValue(input["value"], `${path}.value`);
  if (!value.ok)
    return value;
  if (typeof input["retraction"] !== "boolean") {
    return rejected(`${path}.retraction`, "expected a boolean");
  }
  return parsed(Object.freeze({
    source: source.value,
    entity: entity.value,
    field: field.value,
    value: value.value,
    retraction: input["retraction"]
  }));
}
function parseFactBatch(input, path = "batch") {
  if (!isRecord(input))
    return rejected(path, "expected a fact batch object");
  const txId = parseTransactionId(input["txId"], `${path}.txId`);
  if (!txId.ok)
    return txId;
  if (!Array.isArray(input["facts"]) || input["facts"].length === 0) {
    return rejected(`${path}.facts`, "expected a non-empty array of facts");
  }
  const facts = [];
  for (const [index, inputFact] of input["facts"].entries()) {
    const fact = parseFactDraft(inputFact, `${path}.facts[${index}]`);
    if (!fact.ok)
      return fact;
    facts.push(fact.value);
  }
  return parsed(Object.freeze({
    txId: txId.value,
    facts: Object.freeze(facts)
  }));
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/domain/graph-id.js
function parseGraphId(input, path = "graphId") {
  if (typeof input !== "string" || !/^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$/.test(input)) {
    return rejected(path, "expected a lowercase graph ID using letters, digits, and hyphens");
  }
  return parsed(input);
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/datalog/ast.js
var MAX_QUERY_CLAUSES = 64;
function createDatalogQuery(facts, constraints) {
  if (facts.length === 0) {
    return rejected("query", "a query must contain at least one positive fact relation");
  }
  if (facts.length + constraints.length > MAX_QUERY_CLAUSES) {
    return rejected("query", `a query cannot contain more than ${MAX_QUERY_CLAUSES} clauses`);
  }
  const boundVariables = /* @__PURE__ */ new Set();
  for (const fact of facts) {
    collectVariables(fact.entity, boundVariables);
    collectVariables(fact.value, boundVariables);
  }
  for (const [index, constraint] of constraints.entries()) {
    for (const term of [constraint.left, constraint.right]) {
      if (term.kind === "wildcard") {
        return rejected(`query.constraints[${index}]`, "wildcards are not valid builtin arguments");
      }
      if (term.kind === "variable" && !boundVariables.has(term.name)) {
        return rejected(`query.constraints[${index}]`, `builtin variable ${term.name} must be bound by a fact relation`);
      }
    }
  }
  const nonEmptyFacts = facts;
  return parsed(Object.freeze({
    facts: Object.freeze([...nonEmptyFacts]),
    constraints: Object.freeze([...constraints])
  }));
}
function collectVariables(term, variables) {
  if (term.kind === "variable")
    variables.add(term.name);
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/datalog/value.js
function parseDatalogValue(input, path = "value") {
  if (!isRecord(input) || typeof input["type"] !== "string") {
    return rejected(path, "expected a tagged Datalog value");
  }
  if (input["type"] === "string" && typeof input["value"] === "string") {
    return parsed(stringValue(input["value"]));
  }
  if (input["type"] === "integer") {
    const raw = parseInt64String(input["value"], `${path}.value`);
    return raw.ok ? parsed(integerValue(BigInt(raw.value))) : raw;
  }
  return rejected(path, "expected a string or signed 64-bit integer Datalog value");
}
function stringValue(value) {
  return Object.freeze({ type: "string", value });
}
function integerValue(value) {
  return Object.freeze({ type: "integer", value: value.toString() });
}

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/datalog/parser.js
var MAX_QUERY_LENGTH = 8192;
var I64_MIN2 = -(1n << 63n);
var I64_MAX2 = (1n << 63n) - 1n;
var BUILTINS = /* @__PURE__ */ new Set([
  "=",
  "<",
  "<=",
  ">",
  ">=",
  "eq",
  "lt",
  "lte",
  "gt",
  "gte",
  "before",
  "after",
  "contains",
  "startsWith",
  "endsWith"
]);
function parseDatalogQuery(source) {
  if (source.length > MAX_QUERY_LENGTH) {
    return rejected("query", `query text cannot exceed ${MAX_QUERY_LENGTH} characters`);
  }
  const tokens = tokenize(source);
  if (!tokens.ok)
    return tokens;
  if (tokens.value.length === 0)
    return rejected("query", "expected a query");
  const parser = new Parser(source, tokens.value);
  return parser.parse();
}
function tokenize(source) {
  const tokens = [];
  let offset = 0;
  while (offset < source.length) {
    const character = source[offset];
    if (character === void 0)
      break;
    if (/\s/.test(character)) {
      offset += 1;
      continue;
    }
    if (character === '"') {
      const string = readJsonString(source, offset);
      if (!string.ok)
        return string;
      tokens.push(string.value.token);
      offset = string.value.nextOffset;
      continue;
    }
    if (character === "'") {
      const quoted = readQuotedIdentifier(source, offset);
      if (!quoted.ok)
        return quoted;
      tokens.push(quoted.value.token);
      offset = quoted.value.nextOffset;
      continue;
    }
    if (isIdentifierStart(character) || character === "_") {
      const start = offset;
      offset += 1;
      while (offset < source.length && isIdentifierContinuation(source[offset] ?? "")) {
        offset += 1;
      }
      tokens.push({ kind: "identifier", value: source.slice(start, offset), offset: start });
      continue;
    }
    if (isDigit(character) || character === "-" && isDigit(source[offset + 1] ?? "")) {
      const start = offset;
      offset += character === "-" ? 1 : 0;
      while (isDigit(source[offset] ?? ""))
        offset += 1;
      const text = source.slice(start, offset);
      const value = BigInt(text);
      if (value < I64_MIN2 || value > I64_MAX2) {
        return rejected("query", "integer literal is outside the signed 64-bit range", start);
      }
      tokens.push({ kind: "integer", value, offset: start });
      continue;
    }
    if (character === ">" || character === "<") {
      const next = source[offset + 1];
      const value = next === "=" ? `${character}=` : character;
      tokens.push({ kind: "operator", value, offset });
      offset += value.length;
      continue;
    }
    if (character === "=") {
      tokens.push({ kind: "operator", value: "=", offset });
      offset += 1;
      continue;
    }
    if (character === "(" || character === ")" || character === "," || character === "!") {
      tokens.push({ kind: "punctuation", value: character, offset });
      offset += 1;
      continue;
    }
    return rejected("query", `unexpected character ${JSON.stringify(character)}`, offset);
  }
  return parsed(Object.freeze(tokens));
}
function readJsonString(source, start) {
  let escaped = false;
  for (let offset = start + 1; offset < source.length; offset += 1) {
    const character = source[offset];
    if (character === void 0)
      break;
    if (escaped) {
      escaped = false;
    } else if (character === "\\") {
      escaped = true;
    } else if (character === '"') {
      const raw = source.slice(start, offset + 1);
      try {
        const value = JSON.parse(raw);
        if (typeof value !== "string")
          return rejected("query", "expected a string literal", start);
        return parsed({ token: { kind: "string", value, offset: start }, nextOffset: offset + 1 });
      } catch {
        return rejected("query", "invalid JSON string literal", start);
      }
    }
  }
  return rejected("query", "unterminated string literal", start);
}
function readQuotedIdentifier(source, start) {
  const end = source.indexOf("'", start + 1);
  if (end < 0)
    return rejected("query", "unterminated quoted identifier", start);
  const value = source.slice(start + 1, end);
  if (value.length === 0)
    return rejected("query", "quoted identifier cannot be empty", start);
  return parsed({ token: { kind: "quoted_identifier", value, offset: start }, nextOffset: end + 1 });
}
function isIdentifierStart(character) {
  return /^[A-Za-z]$/.test(character);
}
function isIdentifierContinuation(character) {
  return /^[A-Za-z0-9:_?+.-]$/.test(character);
}
function isDigit(character) {
  return /^[0-9]$/.test(character);
}
var Parser = class {
  source;
  tokens;
  cursor = 0;
  constructor(source, tokens) {
    this.source = source;
    this.tokens = tokens;
  }
  parse() {
    const facts = [];
    const constraints = [];
    while (this.cursor < this.tokens.length) {
      const clause = this.parseClause();
      if (!clause.ok)
        return clause;
      if (clause.value.kind === "fact")
        facts.push(clause.value);
      else
        constraints.push(clause.value);
      if (this.cursor === this.tokens.length)
        break;
      const comma = this.consumePunctuation(",");
      if (!comma) {
        const token = this.peek();
        return this.errorAt(token, "expected a comma between clauses");
      }
      if (this.cursor === this.tokens.length) {
        return rejected("query", "expected a clause after the comma", this.source.length);
      }
    }
    return createDatalogQuery(facts, constraints);
  }
  parseClause() {
    if (this.peek()?.kind === "punctuation" && this.peek()?.value === "!") {
      return this.errorAt(this.take(), "negated relations are outside the initial Datalog subset");
    }
    if (this.isCallStart())
      return this.parseCallClause();
    return this.parseComparison();
  }
  parseCallClause() {
    const predicate = this.take();
    if (predicate === void 0 || predicate.kind !== "identifier" && predicate.kind !== "quoted_identifier") {
      return this.errorAt(predicate, "expected a relation name");
    }
    if (!this.consumePunctuation("("))
      return this.errorAt(this.peek(), "expected `(` after relation name");
    const left = this.parseTerm();
    if (!left.ok)
      return left;
    if (!this.consumePunctuation(","))
      return this.errorAt(this.peek(), "expected `,` between relation terms");
    const right = this.parseTerm();
    if (!right.ok)
      return right;
    if (!this.consumePunctuation(")")) {
      return this.errorAt(this.peek(), "relations in this subset must have exactly two terms");
    }
    if (BUILTINS.has(predicate.value)) {
      return parsed(Object.freeze({
        kind: "builtin",
        name: predicate.value,
        left: left.value,
        right: right.value
      }));
    }
    const parsedPredicate = parseUri(predicate.value, "query.predicate");
    if (!parsedPredicate.ok) {
      return rejected("query", parsedPredicate.error.message, predicate.offset);
    }
    return parsed(Object.freeze({
      kind: "fact",
      predicate: parsedPredicate.value,
      entity: left.value,
      value: right.value
    }));
  }
  parseComparison() {
    const left = this.parseTerm();
    if (!left.ok)
      return left;
    const operator = this.take();
    if (operator?.kind !== "operator")
      return this.errorAt(operator, "expected a supported comparison operator");
    const right = this.parseTerm();
    if (!right.ok)
      return right;
    return parsed(Object.freeze({ kind: "builtin", name: operator.value, left: left.value, right: right.value }));
  }
  parseTerm() {
    const token = this.take();
    if (token === void 0)
      return this.errorAt(void 0, "expected a term");
    if (token.kind === "integer") {
      return parsed(Object.freeze({ kind: "constant", value: integerValue(token.value) }));
    }
    if (token.kind === "string" || token.kind === "quoted_identifier") {
      return parsed(Object.freeze({ kind: "constant", value: stringValue(token.value) }));
    }
    if (token.kind === "identifier") {
      if (token.value === "_")
        return parsed(Object.freeze({ kind: "wildcard" }));
      const firstCharacter = token.value[0] ?? "";
      if (/^[A-Z]$/.test(firstCharacter)) {
        return parsed(Object.freeze({ kind: "variable", name: token.value }));
      }
      return parsed(Object.freeze({ kind: "constant", value: stringValue(token.value) }));
    }
    return this.errorAt(token, "expected a variable, constant, or wildcard");
  }
  isCallStart() {
    const current = this.peek();
    const next = this.tokens[this.cursor + 1];
    return (current?.kind === "identifier" || current?.kind === "quoted_identifier") && next?.kind === "punctuation" && next.value === "(";
  }
  consumePunctuation(value) {
    const token = this.peek();
    if (token?.kind !== "punctuation" || token.value !== value)
      return false;
    this.cursor += 1;
    return true;
  }
  errorAt(token, message) {
    const offset = token?.offset ?? this.source.length;
    return rejected("query", message, offset);
  }
  peek() {
    return this.tokens[this.cursor];
  }
  take() {
    const token = this.tokens[this.cursor];
    if (token !== void 0)
      this.cursor += 1;
    return token;
  }
};

// node_modules/.pnpm/@leostera+poneglyph@file+..+..+poneglyph/node_modules/@leostera/poneglyph/dist/client.js
var PoneglyphInputError = class extends TypeError {
  path;
  offset;
  constructor(message, parseError) {
    super(message);
    this.name = "PoneglyphInputError";
    if (parseError !== void 0) {
      this.path = parseError.path;
      if (parseError.offset !== void 0)
        this.offset = parseError.offset;
    }
  }
};
var PoneglyphNetworkError = class extends Error {
  txId;
  constructor(message, cause, txId) {
    super(message, { cause });
    this.name = "PoneglyphNetworkError";
    if (txId !== void 0)
      this.txId = txId;
  }
};
var PoneglyphRequestError = class extends Error {
  status;
  retryable;
  retryAfter;
  txId;
  constructor(input) {
    super(input.message);
    this.name = "PoneglyphRequestError";
    this.status = input.status;
    this.retryable = input.retryable;
    if (input.retryAfter !== void 0)
      this.retryAfter = input.retryAfter;
    if (input.txId !== void 0)
      this.txId = input.txId;
  }
};
var PoneglyphProtocolError = class extends Error {
  txId;
  constructor(message, txId) {
    super(message);
    this.name = "PoneglyphProtocolError";
    if (txId !== void 0)
      this.txId = txId;
  }
};
function createDatabase(config) {
  if (typeof config !== "object" || config === null) {
    throw new TypeError("Poneglyph config must be an object");
  }
  const transport = new HttpTransport(config);
  const database = new Database(transport);
  if (config.graphId === void 0)
    return database;
  const graph = database.defineGraph({ id: config.graphId });
  return new DatabaseWithGraph(transport, graph);
}
var Database = class {
  transport;
  constructor(transport) {
    this.transport = transport;
  }
  defineGraph(definition) {
    const graphId = parseGraphId(definition?.id, "graph.id");
    if (!graphId.ok)
      throw new PoneglyphInputError(graphId.error.message, graphId.error);
    return new HttpGraphClient(this.transport, graphId.value);
  }
};
var DatabaseWithGraph = class extends Database {
  defaultGraph;
  constructor(transport, defaultGraph) {
    super(transport);
    this.defaultGraph = defaultGraph;
    this.id = defaultGraph.id;
  }
  id;
  stateFacts(facts, options) {
    return this.defaultGraph.stateFacts(facts, options);
  }
  state(facts, options) {
    return this.stateFacts(facts, options);
  }
  transact(facts, options) {
    return this.defaultGraph.transact(facts, options);
  }
  query(source, options) {
    return this.defaultGraph.query(source, options);
  }
};
var HttpGraphClient = class {
  transport;
  id;
  constructor(transport, id) {
    this.transport = transport;
    this.id = id;
  }
  async stateFacts(facts, options = {}) {
    const receipt = await this.transact(facts, options);
    return receipt.txId;
  }
  state(facts, options = {}) {
    return this.stateFacts(facts, options);
  }
  async transact(facts, options = {}) {
    const txId = options.txId ?? createTransactionId();
    const normalizedFacts = normalizeFacts(facts);
    const batch = parseFactBatch({ txId, facts: normalizedFacts });
    if (!batch.ok)
      throw new PoneglyphInputError(batch.error.message, batch.error);
    const response = await this.transport.post(graphPath(this.id, "transactions"), { txId: batch.value.txId, facts: batch.value.facts }, batch.value.txId, options.signal);
    return parseTransactionReceipt(response, batch.value.txId);
  }
  async query(source, options = {}) {
    if (typeof source !== "string")
      throw new PoneglyphInputError("query must be a Datalog string");
    const parsedQuery = parseDatalogQuery(source);
    if (!parsedQuery.ok)
      throw new PoneglyphInputError(parsedQuery.error.message, parsedQuery.error);
    const response = await this.transport.post(graphPath(this.id, "query"), { query: source }, void 0, options.signal);
    return parseQueryResult(response);
  }
};
var HttpTransport = class {
  origin;
  pathPrefix;
  headers;
  fetcher;
  constructor(config) {
    const baseUrl = parseBaseUrl(config.url);
    this.origin = baseUrl.origin;
    this.pathPrefix = baseUrl.pathname.replace(/\/+$/, "");
    this.headers = parseHeaders(config.headers);
    const fetcher = config.fetch ?? globalThis.fetch;
    if (typeof fetcher !== "function") {
      throw new TypeError("Poneglyph requires a fetch implementation");
    }
    this.fetcher = fetcher;
  }
  async post(path, body, txId, signal) {
    const headers = new Headers(this.headers);
    headers.set("content-type", "application/json");
    const init = {
      method: "POST",
      headers,
      body: JSON.stringify(body)
    };
    if (signal !== void 0)
      init.signal = signal;
    let response;
    try {
      response = await this.fetcher(`${this.origin}${this.pathPrefix}${path}`, init);
    } catch (cause) {
      throw new PoneglyphNetworkError("Poneglyph request could not reach the Worker", cause, txId);
    }
    let text;
    try {
      text = await response.text();
    } catch (cause) {
      throw new PoneglyphNetworkError("Poneglyph response could not be read", cause, txId);
    }
    let bodyValue;
    try {
      bodyValue = JSON.parse(text);
    } catch {
      if (response.ok)
        throw new PoneglyphProtocolError("Poneglyph Worker returned invalid JSON", txId);
      bodyValue = { error: text.slice(0, 512) };
    }
    if (!response.ok) {
      const message = isRecord(bodyValue) && typeof bodyValue["error"] === "string" ? bodyValue["error"] : `Poneglyph request failed with HTTP ${response.status}`;
      const retryAfter = response.headers.get("retry-after") ?? void 0;
      throw new PoneglyphRequestError({
        status: response.status,
        message,
        retryable: isRetryableStatus(response.status) || isRecord(bodyValue) && bodyValue["retryable"] === true,
        ...retryAfter === void 0 ? {} : { retryAfter },
        ...txId === void 0 ? {} : { txId }
      });
    }
    if (!isRecord(bodyValue))
      throw new PoneglyphProtocolError("Poneglyph Worker returned a non-object response", txId);
    return bodyValue;
  }
};
function normalizeFacts(facts) {
  if (!Array.isArray(facts))
    throw new PoneglyphInputError("facts must be an array");
  return facts.map((fact) => {
    if (!isRecord(fact))
      return fact;
    return { ...fact, retraction: fact["retraction"] ?? false };
  });
}
function createTransactionId() {
  if (typeof globalThis.crypto?.randomUUID !== "function") {
    throw new TypeError("Poneglyph needs crypto.randomUUID() to generate a transaction ID; pass options.txId instead");
  }
  return `poneglyph:tx:${globalThis.crypto.randomUUID()}`;
}
function graphPath(graphId, action) {
  return `/v1/graphs/${encodeURIComponent(graphId)}/${action}`;
}
function parseBaseUrl(input) {
  let url;
  try {
    url = new URL(input instanceof URL ? input.href : input);
  } catch {
    throw new TypeError("Poneglyph config.url must be an absolute HTTP or HTTPS URL");
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") {
    throw new TypeError("Poneglyph config.url must use HTTP or HTTPS");
  }
  if (url.username !== "" || url.password !== "" || url.search !== "" || url.hash !== "") {
    throw new TypeError("Poneglyph config.url cannot contain credentials, a query, or a fragment");
  }
  return url;
}
function parseHeaders(input) {
  try {
    return new Headers(input);
  } catch (cause) {
    throw new TypeError("Poneglyph config.headers must contain valid HTTP headers", { cause });
  }
}
function parseTransactionReceipt(input, expectedTxId) {
  const txId = input["txId"];
  const commitSeq = input["commitSeq"];
  if (input["status"] !== "committed" || txId !== expectedTxId || typeof commitSeq !== "number" || !Number.isSafeInteger(commitSeq) || commitSeq < 1) {
    throw new PoneglyphProtocolError("Poneglyph Worker returned an invalid transaction receipt", expectedTxId);
  }
  return Object.freeze({ txId: expectedTxId, commitSeq, status: "committed" });
}
function parseQueryResult(input) {
  const snapshotSeq = input["snapshotSeq"];
  if (typeof snapshotSeq !== "number" || !Number.isSafeInteger(snapshotSeq) || snapshotSeq < 0) {
    throw new PoneglyphProtocolError("Poneglyph Worker returned an invalid query snapshot sequence");
  }
  const rows = input["rows"];
  if (!Array.isArray(rows))
    throw new PoneglyphProtocolError("Poneglyph Worker returned invalid query rows");
  const metrics = parseQueryMetrics(input["metrics"]);
  return Object.freeze({
    rows: Object.freeze(rows.map((row, index) => parseQueryBinding(row, index))),
    snapshotSeq,
    metrics
  });
}
function parseQueryBinding(input, index) {
  if (!isRecord(input))
    throw new PoneglyphProtocolError(`Poneglyph query row ${index} is not an object`);
  const binding = /* @__PURE__ */ Object.create(null);
  for (const [variable, value] of Object.entries(input)) {
    const parsedValue = parseDatalogValue(value, `rows[${index}].${variable}`);
    if (!parsedValue.ok) {
      throw new PoneglyphProtocolError(`Poneglyph query row ${index} contains an invalid binding for ${variable}`);
    }
    binding[variable] = parsedValue.value;
  }
  return Object.freeze(binding);
}
function parseQueryMetrics(input) {
  if (!isRecord(input))
    throw new PoneglyphProtocolError("Poneglyph Worker returned invalid query metrics");
  return Object.freeze({
    scanCalls: readMetric(input, "scanCalls"),
    shardRequests: readMetric(input, "shardRequests"),
    tuplesRead: readMetric(input, "tuplesRead"),
    bytesRead: readMetric(input, "bytesRead"),
    directoryRequests: readMetric(input, "directoryRequests")
  });
}
function readMetric(input, name) {
  const value = input[name];
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < 0) {
    throw new PoneglyphProtocolError(`Poneglyph Worker returned invalid query metric ${name}`);
  }
  return value;
}
function isRetryableStatus(status) {
  return status === 408 || status === 423 || status === 429 || status >= 500;
}

// worker/application.ts
async function authorized(request, token) {
  const encode = new TextEncoder();
  const [provided, expected] = await Promise.all([
    crypto.subtle.digest("SHA-256", encode.encode(request.headers.get("authorization") ?? "")),
    crypto.subtle.digest("SHA-256", encode.encode(`Bearer ${token}`))
  ]);
  let difference = 0;
  const a = new Uint8Array(provided), b = new Uint8Array(expected);
  for (let i = 0; i < a.length; i++) difference |= a[i] ^ b[i];
  return token.length > 0 && difference === 0;
}
async function readBody(request) {
  if (request.body === null) throw new PoneglyphInputError("missing body");
  const reader = request.body.getReader();
  const chunks = [];
  let size = 0;
  while (true) {
    const part = await reader.read();
    if (part.done) break;
    size += part.value.byteLength;
    if (size > 11e5) {
      await reader.cancel();
      throw new PoneglyphInputError("benchmark envelope exceeds 1.1 MB");
    }
    chunks.push(part.value);
  }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.length;
  }
  try {
    return JSON.parse(new TextDecoder().decode(bytes));
  } catch {
    throw new PoneglyphInputError("invalid JSON");
  }
}
var application_default = {
  async fetch(request, env) {
    if (!await authorized(request, env.BENCH_TOKEN)) return Response.json({ error: "unauthorized" }, { status: 401 });
    const path = new URL(request.url).pathname;
    if (request.method !== "POST" || path !== "/facts") return new Response("not found", { status: 404 });
    try {
      const raw = await readBody(request);
      if (typeof raw !== "object" || raw === null || !("txId" in raw) || !("facts" in raw) || typeof raw.txId !== "string" || !Array.isArray(raw.facts)) {
        throw new PoneglyphInputError("expected {txId, facts}");
      }
      const db = await createDatabase({
        url: "https://poneglyph.internal",
        graphId: env.GRAPH_ID,
        fetch: (input, init) => env.DATABASE.fetch(input, init)
      });
      const started = performance.now();
      const txId = await db.stateFacts(raw.facts, { txId: raw.txId });
      return Response.json({ txId, workerId: env.WORKER_ID, databaseMs: performance.now() - started });
    } catch (error) {
      if (error instanceof PoneglyphInputError) return Response.json({ error: error.message, retryable: false }, { status: 400 });
      if (error instanceof PoneglyphRequestError) return Response.json({ error: error.message, retryable: error.retryable }, { status: error.status });
      return Response.json({ error: "database outcome unknown", retryable: true }, { status: 502 });
    }
  }
};
export {
  application_default as default
};
