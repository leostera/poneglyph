// ../../poneglyph/src/domain/result.ts
function parsed(value) {
  return { ok: true, value };
}
function rejected(path, message, offset) {
  const error = offset === void 0 ? { path, message } : { path, message, offset };
  return { ok: false, error };
}
function isRecord(value) {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

// ../../poneglyph/src/domain/graph-id.ts
function parseGraphId(input, path = "graphId") {
  if (typeof input !== "string" || !/^[a-z0-9](?:[a-z0-9-]{0,62}[a-z0-9])?$/.test(input)) {
    return rejected(path, "expected a lowercase graph ID using letters, digits, and hyphens");
  }
  return parsed(input);
}

// ../../poneglyph/src/domain/date-validation.ts
function isCalendarDate(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return false;
  return calendarDatePartsAreValid(Number(match[1]), Number(match[2]), Number(match[3]));
}
function isRfc3339Timestamp(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(Z|([+-])(\d{2}):(\d{2}))$/.exec(value);
  if (!match) return false;
  const [year, month, day, hour, minute, second] = match.slice(1, 7).map(Number);
  if (year === void 0 || month === void 0 || day === void 0 || hour === void 0 || minute === void 0 || second === void 0 || !calendarDatePartsAreValid(year, month, day) || hour > 23 || minute > 59 || second > 59) {
    return false;
  }
  if (match[8] !== void 0) {
    const offsetHour = Number(match[9]);
    const offsetMinute = Number(match[10]);
    if (offsetHour > 23 || offsetMinute > 59) return false;
  }
  return Number.isFinite(Date.parse(value));
}
function calendarDatePartsAreValid(year, month, day) {
  if (month < 1 || month > 12 || day < 1) return false;
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month - 1];
  return daysInMonth !== void 0 && day <= daysInMonth;
}

// ../../poneglyph/src/domain/identifiers.ts
var MAX_URI_LENGTH = 2048;
var MAX_TRANSACTION_ID_BYTES = 256;
function parseUri(input, path = "uri") {
  if (typeof input !== "string" || input.length === 0) {
    return rejected(path, "expected a non-empty URI string");
  }
  if (input.length > MAX_URI_LENGTH) {
    return rejected(path, `URI cannot exceed ${MAX_URI_LENGTH} characters`);
  }
  try {
    return parsed(new URL(input).href);
  } catch {
    return rejected(path, "expected an absolute URI with a scheme");
  }
}
function parseFactId(input, path = "factId") {
  const uri = parseUri(input, path);
  return uri.ok ? parsed(uri.value) : uri;
}
function parseTransactionId(input, path = "txId") {
  if (typeof input === "string" && new TextEncoder().encode(input).byteLength > MAX_TRANSACTION_ID_BYTES) {
    return rejected(path, `transaction ID cannot exceed ${MAX_TRANSACTION_ID_BYTES} UTF-8 bytes`);
  }
  const uri = parseUri(input, path);
  return uri.ok ? parsed(uri.value) : uri;
}

// ../../poneglyph/src/domain/int64.ts
var I64_MIN = -(1n << 63n);
var I64_MAX = (1n << 63n) - 1n;
function parseInt64String(input, path) {
  if (typeof input !== "string" || !/^-?(?:0|[1-9][0-9]*)$/.test(input)) {
    return rejected(path, "expected a canonical signed 64-bit integer string");
  }
  try {
    const integer = BigInt(input);
    if (integer >= I64_MIN && integer <= I64_MAX && integer.toString() === input) {
      return parsed(input);
    }
  } catch {
  }
  return rejected(path, "integer is outside the signed 64-bit range");
}

// ../../poneglyph/src/domain/string-order.ts
function compareUnicodeScalars(left, right) {
  const leftPoints = Array.from(left, (character) => character.codePointAt(0) ?? 0);
  const rightPoints = Array.from(right, (character) => character.codePointAt(0) ?? 0);
  const length = Math.min(leftPoints.length, rightPoints.length);
  for (let index = 0; index < length; index += 1) {
    const leftPoint = leftPoints[index] ?? 0;
    const rightPoint = rightPoints[index] ?? 0;
    if (leftPoint !== rightPoint) return leftPoint < rightPoint ? -1 : 1;
  }
  return leftPoints.length < rightPoints.length ? -1 : leftPoints.length > rightPoints.length ? 1 : 0;
}

// ../../poneglyph/src/domain/fact-value.ts
var MAX_VALUE_DEPTH = 64;
function parseFactValue(input, path = "value") {
  return parseAtDepth(input, path, 0);
}
function parseAtDepth(input, path, depth) {
  if (depth > MAX_VALUE_DEPTH) {
    return rejected(path, `fact values cannot be nested more than ${MAX_VALUE_DEPTH} levels`);
  }
  if (!isRecord(input) || typeof input["type"] !== "string") {
    return rejected(path, "expected a tagged fact value");
  }
  switch (input["type"]) {
    case "null":
      if (input["value"] !== void 0 && input["value"] !== null) {
        return rejected(`${path}.value`, "null values cannot carry a payload");
      }
      return parsed(Object.freeze({ type: "null" }));
    case "text":
      return typeof input["value"] === "string" ? parsed(Object.freeze({ type: "text", value: input["value"] })) : rejected(`${path}.value`, "expected a string for text");
    case "number": {
      const number = parseInt64String(input["value"], `${path}.value`);
      return number.ok ? parsed(Object.freeze({ type: "number", value: number.value })) : number;
    }
    case "boolean":
      return typeof input["value"] === "boolean" ? parsed(Object.freeze({ type: "boolean", value: input["value"] })) : rejected(`${path}.value`, "expected a boolean");
    case "bytes":
      return parseBytes(input["value"], `${path}.value`);
    case "reference": {
      const uri = parseUri(input["value"], `${path}.value`);
      return uri.ok ? parsed(Object.freeze({ type: "reference", value: uri.value })) : uri;
    }
    case "date":
      return parseDate(input["value"], `${path}.value`);
    case "date_time":
      return parseDateTime(input["value"], `${path}.value`);
    case "list":
      return parseList(input["value"], `${path}.value`, depth);
    case "map":
      return parseMap(input["value"], `${path}.value`, depth);
    default:
      return rejected(`${path}.type`, `unsupported fact value tag: ${input["type"]}`);
  }
}
function parseBytes(input, path) {
  if (!Array.isArray(input)) {
    return rejected(path, "expected an array of byte values");
  }
  const bytes = [];
  for (const [index, byte] of input.entries()) {
    if (typeof byte !== "number" || !Number.isInteger(byte) || byte < 0 || byte > 255) {
      return rejected(`${path}[${index}]`, "expected an integer between 0 and 255");
    }
    bytes.push(byte);
  }
  return parsed(Object.freeze({ type: "bytes", value: Object.freeze(bytes) }));
}
function parseDate(input, path) {
  if (typeof input !== "string" || !isCalendarDate(input)) {
    return rejected(path, "expected a valid calendar date in YYYY-MM-DD form");
  }
  return parsed(Object.freeze({ type: "date", value: input }));
}
function parseDateTime(input, path) {
  if (typeof input !== "string" || !isRfc3339Timestamp(input)) {
    return rejected(path, "expected an RFC 3339 timestamp with a timezone");
  }
  return parsed(Object.freeze({ type: "date_time", value: input }));
}
function parseList(input, path, depth) {
  if (!Array.isArray(input)) {
    return rejected(path, "expected an array of fact values");
  }
  const values = [];
  for (const [index, item] of input.entries()) {
    const value = parseAtDepth(item, `${path}[${index}]`, depth + 1);
    if (!value.ok) return value;
    values.push(value.value);
  }
  return parsed(Object.freeze({ type: "list", value: Object.freeze(values) }));
}
function parseMap(input, path, depth) {
  if (!isRecord(input)) {
    return rejected(path, "expected an object of fact values");
  }
  const entries = Object.entries(input).sort(([left], [right]) => compareUnicodeScalars(left, right));
  const values = /* @__PURE__ */ Object.create(null);
  for (const [key, item] of entries) {
    const value = parseAtDepth(item, `${path}.${key}`, depth + 1);
    if (!value.ok) return value;
    values[key] = value.value;
  }
  return parsed(Object.freeze({ type: "map", value: Object.freeze(values) }));
}

// ../../poneglyph/src/domain/fact.ts
function parseFactDraft(input, path = "fact") {
  if (!isRecord(input)) return rejected(path, "expected a fact object");
  const source = parseUri(input["source"], `${path}.source`);
  if (!source.ok) return source;
  const entity = parseUri(input["entity"], `${path}.entity`);
  if (!entity.ok) return entity;
  const field = parseUri(input["field"], `${path}.field`);
  if (!field.ok) return field;
  const value = parseFactValue(input["value"], `${path}.value`);
  if (!value.ok) return value;
  if (typeof input["retraction"] !== "boolean") {
    return rejected(`${path}.retraction`, "expected a boolean");
  }
  return parsed(Object.freeze({
    source: source.value,
    entity: entity.value,
    field: field.value,
    value: value.value,
    retraction: input["retraction"]
  }));
}
function parseFactBatch(input, path = "batch") {
  if (!isRecord(input)) return rejected(path, "expected a fact batch object");
  const txId = parseTransactionId(input["txId"], `${path}.txId`);
  if (!txId.ok) return txId;
  if (!Array.isArray(input["facts"]) || input["facts"].length === 0) {
    return rejected(`${path}.facts`, "expected a non-empty array of facts");
  }
  const facts = [];
  for (const [index, inputFact] of input["facts"].entries()) {
    const fact2 = parseFactDraft(inputFact, `${path}.facts[${index}]`);
    if (!fact2.ok) return fact2;
    facts.push(fact2.value);
  }
  return parsed(Object.freeze({
    txId: txId.value,
    facts: Object.freeze(facts)
  }));
}

// ../../poneglyph/src/datalog/value.ts
function parseDatalogValue(input, path = "value") {
  if (!isRecord(input) || typeof input["type"] !== "string") {
    return rejected(path, "expected a tagged Datalog value");
  }
  if (input["type"] === "string" && typeof input["value"] === "string") {
    return parsed(stringValue(input["value"]));
  }
  if (input["type"] === "integer") {
    const raw = parseInt64String(input["value"], `${path}.value`);
    return raw.ok ? parsed(integerValue(BigInt(raw.value))) : raw;
  }
  return rejected(path, "expected a string or signed 64-bit integer Datalog value");
}
function stringValue(value) {
  return Object.freeze({ type: "string", value });
}
function integerValue(value) {
  return Object.freeze({ type: "integer", value: value.toString() });
}
function factScalarToDatalogValue(value) {
  switch (value.type) {
    case "null":
      return stringValue("null");
    case "text":
      return stringValue(value.value);
    case "number":
      return numberOrString(value.value);
    case "boolean":
      return stringValue(String(value.value));
    case "bytes":
      return stringValue(JSON.stringify(value.value));
    case "reference":
    case "date":
    case "date_time":
      return stringValue(value.value);
    case "list":
      return stringValue(JSON.stringify(value.value.map(toSerdeValue)));
    case "map":
      return stringValue(JSON.stringify(
        Object.fromEntries(Object.entries(value.value).map(([key, item]) => [key, toSerdeValue(item)]))
      ));
  }
}
function sameDatalogValue(left, right) {
  return left.type === right.type && left.value === right.value;
}
function compareDatalogValues(left, right) {
  if (left.type !== right.type) return void 0;
  if (left.type === "integer" && right.type === "integer") {
    const leftInteger = BigInt(left.value);
    const rightInteger = BigInt(right.value);
    return leftInteger < rightInteger ? -1 : leftInteger > rightInteger ? 1 : 0;
  }
  if (left.type === "string" && right.type === "string") {
    return compareUnicodeScalars(left.value, right.value);
  }
  return void 0;
}
function numberOrString(value) {
  const integer = parseInt64String(value, "number");
  return integer.ok ? integerValue(BigInt(integer.value)) : stringValue(value);
}
function toSerdeValue(value) {
  switch (value.type) {
    case "null":
      return { type: "null" };
    case "text":
    case "number":
    case "boolean":
    case "bytes":
    case "reference":
    case "date":
    case "date_time":
      return { type: value.type, value: value.value };
    case "list":
    case "map":
      return { type: value.type, value: value.value };
  }
}

// ../../poneglyph/src/storage/constants.ts
var ROUTING_VERSION = 2;
var MAX_DIRECTORY_DEPTH = 256;
var MAX_DIRECTORY_LOOKUP_HOPS = MAX_DIRECTORY_DEPTH + 1;
var MAX_TRANSACTION_PARTICIPANTS = 32;
var MAX_QUERY_SHARD_FANOUT = 256;
var MAX_QUERY_DIRECTORY_NODES = 511;
var MAX_SPLITS_PER_WRITE = 8;
var MAX_ACCOUNTED_BYTES_PER_DO = 8e9;
var TRANSACTION_IDEMPOTENCY_RETENTION_MS = 7 * 24 * 60 * 60 * 1e3;
var MAX_RETAINED_TRANSACTION_OUTCOMES = 1e5;
var SHARD_SPLIT_TRIGGER_BYTES = 5e9;
var MINIMUM_UNCERTAINTY_HEADROOM_BYTES = 2e9;
var MINIMUM_WAL_RESERVE_BYTES = 64e6;
var MAX_TRANSACTION_FACTS = 1e3;
var MAX_TRANSACTION_BYTES = 1e6;
var MAX_ACTIVE_FACTS_PER_ENTITY = 1e4;
var MAX_ENTITY_FIELDS = 5e3;
var MAX_QUERY_RESULTS = 2e3;
var MAX_QUERY_TUPLES = 5e4;
var MAX_QUERY_SHARD_REQUESTS = 2e4;
var MAX_QUERY_SCAN_BYTES = 2e7;
var MAX_QUERY_RESPONSE_BYTES = 2e6;
var MAX_READ_LEASES = 128;
var READ_LEASE_TTL_MS = 3e4;
var QUERY_TIMEOUT_MS = 2e4;
var SHARD_SCAN_PAGE_SIZE = 128;
var SPLIT_COPY_PAGE_SIZE = 128;

// ../../poneglyph/src/storage/keys.ts
var ROOT_PREFIX = "";
function parseVirtualPrefix(input) {
  if (typeof input !== "string" || input.length > 256 || !/^[01]*$/.test(input)) {
    return rejected("prefix", "expected a 0/1 prefix no deeper than 256 bits");
  }
  return parsed(input);
}
function parseVirtualKey(input) {
  if (typeof input !== "string" || !/^[a-f0-9]{64}$/.test(input)) {
    return rejected("virtualKey", "expected a 256-bit lowercase hexadecimal key");
  }
  return parsed(input);
}
async function virtualKeyForEntity(graphId, entity) {
  const graph = parseGraphId(graphId);
  if (!graph.ok) throw new TypeError("cannot route an invalid graph ID");
  const digest = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`${graph.value}\0${entity}`)
  );
  const hex = [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  return hex;
}
function bitAt(key, depth) {
  if (!Number.isInteger(depth) || depth < 0 || depth >= 256) {
    throw new RangeError("virtual-key bit depth must be in 0..255");
  }
  const nibble = Number.parseInt(key[Math.floor(depth / 4)] ?? "0", 16);
  return (nibble & 1 << 3 - depth % 4) === 0 ? "0" : "1";
}
function prefixOfKey(key, depth) {
  if (!Number.isInteger(depth) || depth < 0 || depth > 256) {
    throw new RangeError("virtual-key prefix depth must be in 0..256");
  }
  let prefix = "";
  for (let bit = 0; bit < depth; bit += 1) prefix += bitAt(key, bit);
  return prefix;
}
function matchesPrefix(key, prefix) {
  return prefixOfKey(key, prefix.length) === prefix;
}
function shardObjectName(graphId, prefix = ROOT_PREFIX) {
  const graph = parseGraphId(graphId);
  if (!graph.ok) throw new TypeError("cannot name a shard for an invalid graph ID");
  const token = prefix === ROOT_PREFIX ? "root" : `${prefix.length.toString(16)}-${packPrefix(prefix)}`;
  return `graph:${graph.value}:node:v${ROUTING_VERSION}:${token}`;
}
function coordinatorObjectName(graphId) {
  const graph = parseGraphId(graphId);
  if (!graph.ok) throw new TypeError("cannot name a coordinator for an invalid graph ID");
  return `graph:${graph.value}:coordinator:v${ROUTING_VERSION}`;
}
function packPrefix(prefix) {
  let packed = "";
  for (let offset = 0; offset < prefix.length; offset += 4) {
    const bits = prefix.slice(offset, offset + 4).padEnd(4, "0");
    packed += Number.parseInt(bits, 2).toString(16);
  }
  return packed;
}

// ../../poneglyph/src/storage/protocol.ts
function parseParticipantBatch(input) {
  if (!isRecord(input)) return rejected("participant", "expected a prepare request object");
  const graphId = parseGraphId(input["graphId"], "participant.graphId");
  if (!graphId.ok) return graphId;
  const shardPrefix = parseVirtualPrefix(input["shardPrefix"]);
  if (!shardPrefix.ok) return shardPrefix;
  const shardGeneration = readNonNegativeInteger(input["shardGeneration"]);
  const directoryEpoch = readNonNegativeInteger(input["directoryEpoch"]);
  if (shardGeneration === void 0 || directoryEpoch === void 0) return rejected("participant", "invalid shard generation or directory epoch");
  const txId = parseTransactionId(input["txId"], "participant.txId");
  if (!txId.ok) return txId;
  const payloadHash = input["payloadHash"];
  if (typeof payloadHash !== "string" || !/^[a-f0-9]{64}$/.test(payloadHash)) {
    return rejected("participant.payloadHash", "expected a SHA-256 hex digest");
  }
  const statementTimeMs = input["statementTimeMs"];
  if (!Number.isSafeInteger(statementTimeMs) || typeof statementTimeMs !== "number" || statementTimeMs < 0) {
    return rejected("participant.statementTimeMs", "expected a non-negative safe integer timestamp");
  }
  const commitSeq = input["commitSeq"];
  if (!Number.isSafeInteger(commitSeq) || typeof commitSeq !== "number" || commitSeq < 1) {
    return rejected("participant.commitSeq", "expected a positive safe integer sequence");
  }
  if (!Array.isArray(input["facts"]) || input["facts"].length === 0) {
    return rejected("participant.facts", "expected a non-empty fact list");
  }
  const facts = [];
  const indices = /* @__PURE__ */ new Set();
  for (const [offset, item] of input["facts"].entries()) {
    if (!isRecord(item)) return rejected(`participant.facts[${offset}]`, "expected an indexed fact");
    const index = item["index"];
    if (!Number.isSafeInteger(index) || typeof index !== "number" || index < 0 || indices.has(index)) {
      return rejected(`participant.facts[${offset}].index`, "expected a unique non-negative fact index");
    }
    const fact2 = parseFactDraft(item["fact"], `participant.facts[${offset}].fact`);
    if (!fact2.ok) return fact2;
    const virtualKey = parseVirtualKey(item["virtualKey"]);
    if (!virtualKey.ok) return virtualKey;
    indices.add(index);
    facts.push(Object.freeze({ index, fact: fact2.value, virtualKey: virtualKey.value }));
  }
  return parsed(Object.freeze({
    graphId: graphId.value,
    shardPrefix: shardPrefix.value,
    shardGeneration,
    directoryEpoch,
    txId: txId.value,
    payloadHash,
    statementTimeMs,
    commitSeq,
    facts: Object.freeze(facts)
  }));
}
function parseScanRequest(input) {
  if (!isRecord(input)) return rejected("scan", "expected a scan request object");
  const graphId = parseGraphId(input["graphId"], "scan.graphId");
  if (!graphId.ok) return graphId;
  const shardPrefix = parseVirtualPrefix(input["shardPrefix"]);
  if (!shardPrefix.ok) return shardPrefix;
  const shardGeneration = readNonNegativeInteger(input["shardGeneration"]);
  const directoryEpoch = readNonNegativeInteger(input["directoryEpoch"]);
  if (shardGeneration === void 0 || directoryEpoch === void 0) return rejected("scan", "invalid shard generation or directory epoch");
  const field = parseUri(input["field"], "scan.field");
  if (!field.ok) return field;
  const snapshotSeq = input["snapshotSeq"];
  if (!Number.isSafeInteger(snapshotSeq) || typeof snapshotSeq !== "number" || snapshotSeq < 0) {
    return rejected("scan.snapshotSeq", "expected a non-negative safe integer");
  }
  const leaseExpiresAtMs = input["leaseExpiresAtMs"];
  if (!Number.isSafeInteger(leaseExpiresAtMs) || typeof leaseExpiresAtMs !== "number") {
    return rejected("scan.leaseExpiresAtMs", "expected a safe integer timestamp");
  }
  const request = {
    graphId: graphId.value,
    shardPrefix: shardPrefix.value,
    shardGeneration,
    directoryEpoch,
    field: field.value,
    snapshotSeq,
    leaseExpiresAtMs
  };
  if (input["entity"] !== void 0) {
    const entity = parseDatalogValue(input["entity"], "scan.entity");
    if (!entity.ok) return entity;
    request.entity = entity.value;
  }
  if (input["value"] !== void 0) {
    const value = parseDatalogValue(input["value"], "scan.value");
    if (!value.ok) return value;
    request.value = value.value;
  }
  return parsed(Object.freeze(request));
}
function factAsJson(fact2) {
  return {
    source: fact2.source,
    entity: fact2.entity,
    field: fact2.field,
    value: fact2.value,
    retraction: fact2.retraction
  };
}
function readNonNegativeInteger(input) {
  return typeof input === "number" && Number.isSafeInteger(input) && input >= 0 ? input : void 0;
}

// ../../poneglyph/src/storage/http.ts
async function readJsonBody(request, maxBytes) {
  if (request.body === null) return rejected("body", "request body is required");
  const reader = request.body.getReader();
  const decoder = new TextDecoder();
  let text = "";
  let size = 0;
  try {
    while (true) {
      const chunk = await reader.read();
      if (chunk.done) break;
      size += chunk.value.byteLength;
      if (size > maxBytes) {
        await reader.cancel();
        return rejected("body", `request body exceeds the ${maxBytes}-byte limit`);
      }
      text += decoder.decode(chunk.value, { stream: true });
    }
    text += decoder.decode();
  } catch {
    return rejected("body", "could not read the request body");
  }
  try {
    const value = JSON.parse(text);
    return { ok: true, value };
  } catch {
    return rejected("body", "request body must be valid JSON");
  }
}
function parseBatchBody(input) {
  const batch = parseFactBatch(input);
  if (!batch.ok) return batch;
  const json = canonicalBatchJson(batch.value);
  return { ok: true, value: Object.freeze({ batch: batch.value, json }) };
}
function canonicalBatchJson(batch) {
  return JSON.stringify({
    txId: batch.txId,
    facts: batch.facts.map(factAsJson)
  });
}
async function sha256Hex(value) {
  const digest = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
function jsonResponse(body, status = 200, extraHeaders) {
  return jsonStringResponse(JSON.stringify(body), status, extraHeaders);
}
function jsonStringResponse(serialized, status = 200, extraHeaders) {
  const headers = new Headers(extraHeaders);
  headers.set("content-type", "application/json; charset=utf-8");
  headers.set("cache-control", "no-store");
  return new Response(serialized, { status, headers });
}
function requestObject(value) {
  return isRecord(value) ? { ok: true, value } : rejected("body", "expected a JSON object");
}

// ../../poneglyph/src/todo_demo/auth.ts
var SESSION_COOKIE = "poneglyph_todo";
var SESSION_TTL_SECONDS = 3600;
var MAX_PASSPHRASE_BYTES = 256;
var encoder = new TextEncoder();
async function handleTodoLogin(request, env) {
  const secret = env.TODO_SHARED_PASSPHRASE;
  if (typeof secret !== "string" || secret.length === 0) {
    return jsonResponse({ error: "TODO authentication is not configured" }, 503);
  }
  const body = await readJsonBody(request, 1024);
  if (!body.ok || !isRecord(body.value) || typeof body.value["passphrase"] !== "string") {
    return jsonResponse({ error: "expected a passphrase" }, 400);
  }
  const supplied = body.value["passphrase"];
  if (encoder.encode(supplied).byteLength > MAX_PASSPHRASE_BYTES || !await passphraseMatches(supplied, secret)) {
    return jsonResponse({ error: "invalid passphrase" }, 401);
  }
  const expiresAtSeconds = Math.floor(Date.now() / 1e3) + SESSION_TTL_SECONDS;
  const payload = `${expiresAtSeconds}:${crypto.randomUUID()}`;
  const signature = await sign(payload, secret);
  const cookieValue = `${base64Url(encoder.encode(payload))}.${base64Url(signature)}`;
  return jsonResponse({ authenticated: true, expiresAt: expiresAtSeconds }, 200, {
    "set-cookie": `${SESSION_COOKIE}=${cookieValue}; Max-Age=${SESSION_TTL_SECONDS}; Path=/; Secure; HttpOnly; SameSite=Strict`
  });
}
async function hasTodoSession(request, env) {
  const secret = env.TODO_SHARED_PASSPHRASE;
  if (typeof secret !== "string" || secret.length === 0) return false;
  const cookieHeader = request.headers.get("cookie") ?? "";
  const cookie = cookieHeader.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${SESSION_COOKIE}=`));
  if (cookie === void 0) return false;
  const token = cookie.slice(SESSION_COOKIE.length + 1);
  if (token.length > 512) return false;
  const [encodedPayload, encodedSignature, extra] = token.split(".");
  if (encodedPayload === void 0 || encodedSignature === void 0 || extra !== void 0) return false;
  try {
    const payloadBytes = fromBase64Url(encodedPayload);
    const signature = fromBase64Url(encodedSignature);
    const payload = new TextDecoder().decode(payloadBytes);
    const separator = payload.indexOf(":");
    if (separator <= 0) return false;
    const expiresAtSeconds = Number(payload.slice(0, separator));
    if (!Number.isSafeInteger(expiresAtSeconds) || expiresAtSeconds <= Math.floor(Date.now() / 1e3)) return false;
    if (expiresAtSeconds > Math.floor(Date.now() / 1e3) + SESSION_TTL_SECONDS + 30) return false;
    const key = await hmacKey(secret);
    const signatureBuffer = new ArrayBuffer(signature.byteLength);
    new Uint8Array(signatureBuffer).set(signature);
    const payloadBuffer = new ArrayBuffer(payloadBytes.byteLength);
    new Uint8Array(payloadBuffer).set(payloadBytes);
    return await crypto.subtle.verify("HMAC", key, signatureBuffer, payloadBuffer);
  } catch {
    return false;
  }
}
function hasSameOriginWebSocket(request) {
  const origin = request.headers.get("origin");
  if (origin === null) return false;
  try {
    const requestUrl = new URL(request.url);
    const originUrl = new URL(origin);
    const secureContext = requestUrl.protocol === "https:" || requestUrl.protocol === "http:" && ["localhost", "127.0.0.1", "[::1]"].includes(requestUrl.hostname);
    return secureContext && originUrl.origin === requestUrl.origin;
  } catch {
    return false;
  }
}
async function passphraseMatches(supplied, expected) {
  const [suppliedDigest, expectedDigest] = await Promise.all([
    crypto.subtle.digest("SHA-256", encoder.encode(supplied)),
    crypto.subtle.digest("SHA-256", encoder.encode(expected))
  ]);
  const left = new Uint8Array(suppliedDigest);
  const right = new Uint8Array(expectedDigest);
  let difference = left.length ^ right.length;
  for (let index = 0; index < Math.max(left.length, right.length); index += 1) {
    difference |= (left[index] ?? 0) ^ (right[index] ?? 0);
  }
  return difference === 0;
}
async function sign(payload, secret) {
  const key = await hmacKey(secret);
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, encoder.encode(payload)));
}
async function hmacKey(secret) {
  return crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign", "verify"]);
}
function base64Url(bytes) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}
function fromBase64Url(value) {
  if (!/^[A-Za-z0-9_-]+$/.test(value)) throw new TypeError("invalid base64url token");
  const base64 = value.replaceAll("-", "+").replaceAll("_", "/").padEnd(Math.ceil(value.length / 4) * 4, "=");
  return Uint8Array.from(atob(base64), (character) => character.charCodeAt(0));
}

// ../../poneglyph/src/todo_demo/page.ts
var TODO_PAGE = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Shared Poneglyph TODO</title>
<style>body{font:16px system-ui;max-width:760px;margin:3rem auto;padding:0 1rem;color:#222}form,li{display:flex;gap:.6rem;align-items:center;margin:.7rem 0}input,select,button{font:inherit;padding:.45rem}input{flex:1}li span{flex:1}.meta{color:#666;font-size:.85rem}#app[hidden],#login[hidden]{display:none}</style></head>
<body><h1>Shared TODO</h1><p class="meta">Changes are append-only facts. Moving a task commits across the old list, task, and new list before clients are invalidated.</p>
<section id="login"><form id="login-form"><label>Shared passphrase <input id="passphrase" type="password" autocomplete="current-password" required></label><button>Join</button></form><p id="login-error" role="status"></p></section>
<section id="app" hidden><form id="task-form"><input id="title" maxlength="200" placeholder="What needs doing?" required><select id="new-list"></select><button>Add task</button></form><p id="status" role="status"></p><div id="lists"></div></section>
<script type="module">
const login=document.querySelector('#login'),app=document.querySelector('#app'),status=document.querySelector('#status'),error=document.querySelector('#login-error');
let snapshot=null,socket=null;
async function json(url,options={}){const response=await fetch(url,{...options,headers:{'content-type':'application/json',...(options.headers||{})}});const body=await response.json().catch(()=>({error:'Invalid server response'}));if(!response.ok){const error=new Error(body.error||'Request failed');error.status=response.status;throw error}return body}
function show(){login.hidden=true;app.hidden=false;connect();load()}
async function load(){try{snapshot=await json('/api/todo/snapshot');const select=document.querySelector('#new-list');select.replaceChildren(...snapshot.lists.map(list=>{const option=document.createElement('option');option.value=list.id;option.textContent=list.label;return option}));render();status.textContent='Snapshot '+snapshot.snapshotSeq+' \xB7 '+(snapshot.metrics?.shardRequests??0)+' shard scans'}catch(e){status.textContent=e.message;if(e.status===401){login.hidden=false;app.hidden=true}}}
function render(){const target=document.querySelector('#lists');target.replaceChildren();for(const list of snapshot.lists){const section=document.createElement('section'),heading=document.createElement('h2'),items=document.createElement('ul');heading.textContent=list.label;for(const task of snapshot.tasks.filter(item=>item.list===list.id)){const li=document.createElement('li'),title=document.createElement('span'),button=document.createElement('button');title.textContent=task.title;button.textContent='Move to '+(list.id==='todo:list:todo'?'Done':'To do');button.addEventListener('click',()=>move(task.id,list.id==='todo:list:todo'?'todo:list:done':'todo:list:todo'));li.append(title,button);items.append(li)}section.append(heading,items);target.append(section)}}
async function move(id,toList){try{const outcome=await json('/api/todo/tasks/'+encodeURIComponent(id)+'/move',{method:'POST',body:JSON.stringify({toList})});status.textContent='Committed '+outcome.txId+' at sequence '+outcome.commitSeq}catch(e){status.textContent=e.message}}
function connect(){if(socket&&socket.readyState<2)return;const scheme=location.protocol==='https:'?'wss:':'ws:';socket=new WebSocket(scheme+'//'+location.host+'/api/todo/ws');socket.onopen=()=>load();socket.onmessage=event=>{try{const message=JSON.parse(event.data);if(message.type==='invalidate'){status.textContent='Committed sequence '+message.commitSeq+'; refreshing';load()}}catch{}};socket.onclose=()=>setTimeout(connect,1500)}
document.querySelector('#login-form').addEventListener('submit',async event=>{event.preventDefault();error.textContent='';try{const input=document.querySelector('#passphrase');await json('/api/todo/login',{method:'POST',body:JSON.stringify({passphrase:input.value})});input.value='';show()}catch(e){error.textContent=e.message}});
document.querySelector('#task-form').addEventListener('submit',async event=>{event.preventDefault();try{const title=document.querySelector('#title');const outcome=await json('/api/todo/tasks',{method:'POST',body:JSON.stringify({title:title.value,list:document.querySelector('#new-list').value})});title.value='';status.textContent='Committed '+outcome.txId+' at sequence '+outcome.commitSeq;await load()}catch(e){status.textContent=e.message}});
json('/api/todo/snapshot').then(()=>show()).catch(()=>{});
</script></body></html>`;

// ../../poneglyph/src/todo_demo/service.ts
var TODO_GRAPH_ID = "todo-shared-2026";
var TODO_LISTS = Object.freeze({
  todo: "todo:list:todo",
  done: "todo:list:done"
});
var TODO_SOURCE = "agent:shared-todo-demo";
async function handleTodoApi(request, env) {
  const path = new URL(request.url).pathname;
  if (path === "/api/todo/snapshot" && request.method === "GET") return await readSnapshot(env);
  if (path === "/api/todo/tasks" && request.method === "POST") return await createTask(request, env);
  const move = /^\/api\/todo\/tasks\/([0-9a-f-]{36})\/move$/.exec(path);
  if (move !== null && request.method === "POST") return await moveTask(request, env, move[1] ?? "");
  return jsonResponse({ error: "not found" }, 404);
}
async function readSnapshot(env) {
  const topology = await ensureTodoTopology(env);
  if (topology !== void 0) return topology;
  const query = await runQuery(env, "todo:task-list(Task, List), schema:name(Task, Title)");
  if (!query.ok) return query.response;
  const tasks = [];
  for (const row of query.rows) {
    const task = bindingString(row["Task"]);
    const title = bindingString(row["Title"]);
    const list = bindingString(row["List"]);
    if (task === void 0 || title === void 0 || list === void 0) continue;
    tasks.push({ id: task.slice("todo:task:".length), title, list });
  }
  return jsonResponse({
    graphId: TODO_GRAPH_ID,
    snapshotSeq: query.snapshotSeq,
    tasks,
    lists: [
      { id: TODO_LISTS.todo, label: "To do" },
      { id: TODO_LISTS.done, label: "Done" }
    ],
    metrics: query.metrics
  });
}
async function createTask(request, env) {
  const input = await readJsonBody(request, 4096);
  if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "expected a task object" }, 400);
  const title = input.value["title"];
  const list = input.value["list"];
  if (typeof title !== "string" || title.trim().length === 0 || title.trim().length > 200 || !isTodoList(list)) {
    return jsonResponse({ error: "title (1\u2013200 characters) and a supported list are required" }, 400);
  }
  const topology = await ensureTodoTopology(env);
  if (topology !== void 0) return topology;
  const taskId = crypto.randomUUID();
  const task = `todo:task:${taskId}`;
  const transaction = await commitFacts(env, [
    fact(task, "schema:name", { type: "text", value: title.trim() }),
    fact(task, "todo:task-list", { type: "reference", value: list }),
    fact(list, "todo:contains", { type: "reference", value: task })
  ]);
  if (!transaction.ok) return transaction.response;
  await publishInvalidation(env, transaction, [list]);
  return jsonResponse({ taskId, title: title.trim(), list, ...transaction });
}
async function moveTask(request, env, taskId) {
  const input = await readJsonBody(request, 4096);
  if (!input.ok || !isRecord(input.value) || !isTodoList(input.value["toList"])) {
    return jsonResponse({ error: "expected a supported toList" }, 400);
  }
  const toList = input.value["toList"];
  const topology = await ensureTodoTopology(env);
  if (topology !== void 0) return topology;
  const task = `todo:task:${taskId}`;
  const current = await runQuery(env, `todo:task-list("${task}", List)`);
  if (!current.ok) return current.response;
  const rows = current.rows.filter((row) => bindingString(row["List"]) !== void 0);
  if (rows.length !== 1) return jsonResponse({ error: "task not found or has an invalid list projection" }, 404);
  const fromList = bindingString(rows[0]?.["List"]);
  if (!isTodoList(fromList)) return jsonResponse({ error: "task list is outside the shared demo" }, 409);
  if (fromList === toList) return jsonResponse({ error: "task is already in that list" }, 409);
  const transaction = await commitFacts(env, [
    fact(task, "todo:task-list", { type: "reference", value: fromList }, true),
    fact(task, "todo:task-list", { type: "reference", value: toList }),
    fact(fromList, "todo:contains", { type: "reference", value: task }, true),
    fact(toList, "todo:contains", { type: "reference", value: task })
  ]);
  if (!transaction.ok) return transaction.response;
  await publishInvalidation(env, transaction, [fromList, toList]);
  return jsonResponse({ taskId, fromList, toList, ...transaction });
}
async function ensureTodoTopology(env) {
  const coordinator = env.GRAPH_COORDINATORS.getByName(coordinatorObjectName(TODO_GRAPH_ID));
  const response = await coordinator.fetch("https://coordinator.internal/_split", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ graphId: TODO_GRAPH_ID, prefix: "", force: true })
  });
  if (response.ok) return void 0;
  const detail = (await response.text()).slice(0, 512);
  return jsonResponse({ error: `TODO topology is unavailable: ${detail}`, retryable: response.status >= 500 }, response.status);
}
async function commitFacts(env, facts) {
  const txId = `poneglyph:tx:${crypto.randomUUID()}`;
  const response = await env.GRAPH_COORDINATORS.getByName(coordinatorObjectName(TODO_GRAPH_ID)).fetch(
    `https://coordinator.internal/v1/graphs/${TODO_GRAPH_ID}/transactions`,
    {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ txId, facts })
    }
  );
  const body = await response.json().catch(() => void 0);
  if (!response.ok || !isRecord(body) || body["status"] !== "committed" || typeof body["commitSeq"] !== "number") {
    return { ok: false, response: jsonResponse(isRecord(body) ? body : { error: "transaction failed" }, response.status || 502) };
  }
  return { ok: true, txId, commitSeq: body["commitSeq"], status: "committed" };
}
async function runQuery(env, query) {
  const response = await env.GRAPH_COORDINATORS.getByName(coordinatorObjectName(TODO_GRAPH_ID)).fetch(
    `https://coordinator.internal/v1/graphs/${TODO_GRAPH_ID}/query`,
    { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ query }) }
  );
  const body = await response.json().catch(() => void 0);
  if (!response.ok || !isRecord(body) || !Array.isArray(body["rows"]) || typeof body["snapshotSeq"] !== "number") {
    return { ok: false, response: jsonResponse(isRecord(body) ? body : { error: "query failed" }, response.status || 502) };
  }
  const rows = body["rows"].filter(isRecord);
  return { ok: true, rows, snapshotSeq: body["snapshotSeq"], metrics: body["metrics"] };
}
async function publishInvalidation(env, transaction, changedLists) {
  const hub = env.TODO_HUBS.getByName("shared-todo");
  const message = {
    type: "invalidate",
    graphId: TODO_GRAPH_ID,
    txId: transaction.txId,
    commitSeq: transaction.commitSeq,
    changedLists
  };
  try {
    const response = await hub.fetch("https://todo-hub.internal/broadcast", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(message)
    });
    if (!response.ok) console.error("TODO invalidation was not delivered", { txId: transaction.txId, status: response.status });
  } catch (error) {
    console.error("TODO invalidation was not delivered", { txId: transaction.txId, error: String(error) });
  }
}
function fact(entity, field, value, retraction = false) {
  return { source: TODO_SOURCE, entity, field, value, retraction };
}
function isTodoList(input) {
  return input === TODO_LISTS.todo || input === TODO_LISTS.done;
}
function bindingString(input) {
  return isRecord(input) && input["type"] === "string" && typeof input["value"] === "string" ? input["value"] : void 0;
}

// ../../poneglyph/src/todo_demo/worker.ts
async function handleTodoRequest(request, env) {
  const path = new URL(request.url).pathname;
  if (path === "/todo" && request.method === "GET") {
    return new Response(TODO_PAGE, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
  }
  if (path === "/api/todo/login" && request.method === "POST") {
    if (!hasSameOriginHttp(request)) return jsonResponse({ error: "same-origin request required" }, 403);
    return handleTodoLogin(request, env);
  }
  const graphPath = /^\/v1\/graphs\/([^/]+)\//.exec(path);
  const isSharedTodoGraph = graphPath !== null && decodeURIComponent(graphPath[1] ?? "") === TODO_GRAPH_ID;
  if (!path.startsWith("/api/todo/") && !isSharedTodoGraph) return void 0;
  if (request.method === "POST" && !hasSameOriginHttp(request)) {
    return jsonResponse({ error: "same-origin request required" }, 403);
  }
  if (!await hasTodoSession(request, env)) return jsonResponse({ error: "authentication required" }, 401);
  if (isSharedTodoGraph) {
    if (request.method === "POST" && graphPath?.[1] === TODO_GRAPH_ID && path.endsWith("/transactions")) {
      return jsonResponse({ error: "shared TODO writes must use the authenticated reactive API" }, 403);
    }
    return void 0;
  }
  if (path === "/api/todo/ws") {
    if (!hasSameOriginWebSocket(request)) return jsonResponse({ error: "same-origin HTTPS WebSocket required" }, 403);
    if (request.headers.get("upgrade")?.toLowerCase() !== "websocket") return jsonResponse({ error: "WebSocket upgrade required" }, 426);
    const hub = env.TODO_HUBS.getByName("shared-todo");
    return hub.fetch(new Request("https://todo-hub.internal/connect", { headers: { upgrade: "websocket" } }));
  }
  return handleTodoApi(request, env);
}
function hasSameOriginHttp(request) {
  const origin = request.headers.get("origin");
  if (origin === null) return true;
  try {
    return new URL(origin).origin === new URL(request.url).origin;
  } catch {
    return false;
  }
}

// ../../poneglyph/src/storage/coordinator.ts
import { DurableObject } from "cloudflare:workers";

// ../../poneglyph/src/datalog/evaluator.ts
var DEFAULT_MAX_RESULTS = 1e4;
var QueryResultLimitExceeded = class extends Error {
  constructor(maxResults) {
    super(`query result limit exceeded (${maxResults})`);
    this.maxResults = maxResults;
    this.name = "QueryResultLimitExceeded";
  }
  maxResults;
};
async function* evaluateDatalog(query, facts, options = {}) {
  const maxResults = options.maxResults ?? DEFAULT_MAX_RESULTS;
  if (!Number.isSafeInteger(maxResults) || maxResults < 1) {
    throw new RangeError("maxResults must be a positive safe integer");
  }
  let emitted = 0;
  for await (const binding of evaluateFacts(
    query.facts,
    facts,
    options.signal,
    0,
    /* @__PURE__ */ new Map()
  )) {
    throwIfAborted(options.signal);
    if (query.constraints.every((constraint) => {
      const left = resolveTerm(constraint.left, binding);
      const right = resolveTerm(constraint.right, binding);
      return left !== void 0 && right !== void 0 && evaluateBuiltin(constraint.name, left, right);
    })) {
      if (emitted === maxResults) throw new QueryResultLimitExceeded(maxResults);
      emitted += 1;
      yield binding;
    }
  }
}
async function* evaluateFacts(clauses, facts, signal, clauseIndex, binding) {
  throwIfAborted(signal);
  if (clauseIndex === clauses.length) {
    yield new Map(binding);
    return;
  }
  const clause = clauses[clauseIndex];
  if (clause === void 0) return;
  const lookup = lookupFor(clause, binding);
  for await (const tuple of facts.scan(lookup, signal)) {
    throwIfAborted(signal);
    const nextBinding = new Map(binding);
    if (!unify(clause.entity, tuple.entity, nextBinding)) continue;
    if (!unify(clause.value, tuple.value, nextBinding)) continue;
    yield* evaluateFacts(clauses, facts, signal, clauseIndex + 1, nextBinding);
  }
}
function lookupFor(clause, binding) {
  const lookup = {
    field: clause.predicate
  };
  const entity = resolveTerm(clause.entity, binding);
  if (entity !== void 0) lookup.entity = entity;
  const value = resolveTerm(clause.value, binding);
  if (value !== void 0) lookup.value = value;
  return lookup;
}
function resolveTerm(term, binding) {
  switch (term.kind) {
    case "constant":
      return term.value;
    case "variable":
      return binding.get(term.name);
    case "wildcard":
      return void 0;
  }
}
function unify(term, value, binding) {
  switch (term.kind) {
    case "constant":
      return sameDatalogValue(term.value, value);
    case "wildcard":
      return true;
    case "variable": {
      const existing = binding.get(term.name);
      if (existing !== void 0) return sameDatalogValue(existing, value);
      binding.set(term.name, value);
      return true;
    }
  }
}
function evaluateBuiltin(name, left, right) {
  const ordering = compareDatalogValues(left, right);
  switch (name) {
    case "=":
    case "eq":
      return sameDatalogValue(left, right);
    case "<":
    case "lt":
    case "before":
      return ordering !== void 0 && ordering < 0;
    case "<=":
    case "lte":
      return ordering !== void 0 && ordering <= 0;
    case ">":
    case "gt":
    case "after":
      return ordering !== void 0 && ordering > 0;
    case ">=":
    case "gte":
      return ordering !== void 0 && ordering >= 0;
    case "contains":
      return stringPair(left, right, (value, part) => value.includes(part));
    case "startsWith":
      return stringPair(left, right, (value, prefix) => value.startsWith(prefix));
    case "endsWith":
      return stringPair(left, right, (value, suffix) => value.endsWith(suffix));
  }
}
function stringPair(left, right, matches) {
  return left.type === "string" && right.type === "string" && matches(left.value, right.value);
}
function throwIfAborted(signal) {
  if (signal?.aborted) {
    throw signal.reason instanceof Error ? signal.reason : new DOMException("Query was aborted", "AbortError");
  }
}

// ../../poneglyph/src/datalog/ast.ts
var MAX_QUERY_CLAUSES = 64;
function createDatalogQuery(facts, constraints) {
  if (facts.length === 0) {
    return rejected("query", "a query must contain at least one positive fact relation");
  }
  if (facts.length + constraints.length > MAX_QUERY_CLAUSES) {
    return rejected("query", `a query cannot contain more than ${MAX_QUERY_CLAUSES} clauses`);
  }
  const boundVariables = /* @__PURE__ */ new Set();
  for (const fact2 of facts) {
    collectVariables(fact2.entity, boundVariables);
    collectVariables(fact2.value, boundVariables);
  }
  for (const [index, constraint] of constraints.entries()) {
    for (const term of [constraint.left, constraint.right]) {
      if (term.kind === "wildcard") {
        return rejected(`query.constraints[${index}]`, "wildcards are not valid builtin arguments");
      }
      if (term.kind === "variable" && !boundVariables.has(term.name)) {
        return rejected(
          `query.constraints[${index}]`,
          `builtin variable ${term.name} must be bound by a fact relation`
        );
      }
    }
  }
  const nonEmptyFacts = facts;
  return parsed(Object.freeze({
    facts: Object.freeze([...nonEmptyFacts]),
    constraints: Object.freeze([...constraints])
  }));
}
function collectVariables(term, variables) {
  if (term.kind === "variable") variables.add(term.name);
}

// ../../poneglyph/src/datalog/parser.ts
var MAX_QUERY_LENGTH = 8192;
var I64_MIN2 = -(1n << 63n);
var I64_MAX2 = (1n << 63n) - 1n;
var BUILTINS = /* @__PURE__ */ new Set([
  "=",
  "<",
  "<=",
  ">",
  ">=",
  "eq",
  "lt",
  "lte",
  "gt",
  "gte",
  "before",
  "after",
  "contains",
  "startsWith",
  "endsWith"
]);
function parseDatalogQuery(source) {
  if (source.length > MAX_QUERY_LENGTH) {
    return rejected("query", `query text cannot exceed ${MAX_QUERY_LENGTH} characters`);
  }
  const tokens = tokenize(source);
  if (!tokens.ok) return tokens;
  if (tokens.value.length === 0) return rejected("query", "expected a query");
  const parser = new Parser(source, tokens.value);
  return parser.parse();
}
function tokenize(source) {
  const tokens = [];
  let offset = 0;
  while (offset < source.length) {
    const character = source[offset];
    if (character === void 0) break;
    if (/\s/.test(character)) {
      offset += 1;
      continue;
    }
    if (character === '"') {
      const string = readJsonString(source, offset);
      if (!string.ok) return string;
      tokens.push(string.value.token);
      offset = string.value.nextOffset;
      continue;
    }
    if (character === "'") {
      const quoted = readQuotedIdentifier(source, offset);
      if (!quoted.ok) return quoted;
      tokens.push(quoted.value.token);
      offset = quoted.value.nextOffset;
      continue;
    }
    if (isIdentifierStart(character) || character === "_") {
      const start = offset;
      offset += 1;
      while (offset < source.length && isIdentifierContinuation(source[offset] ?? "")) {
        offset += 1;
      }
      tokens.push({ kind: "identifier", value: source.slice(start, offset), offset: start });
      continue;
    }
    if (isDigit(character) || character === "-" && isDigit(source[offset + 1] ?? "")) {
      const start = offset;
      offset += character === "-" ? 1 : 0;
      while (isDigit(source[offset] ?? "")) offset += 1;
      const text = source.slice(start, offset);
      const value = BigInt(text);
      if (value < I64_MIN2 || value > I64_MAX2) {
        return rejected("query", "integer literal is outside the signed 64-bit range", start);
      }
      tokens.push({ kind: "integer", value, offset: start });
      continue;
    }
    if (character === ">" || character === "<") {
      const next = source[offset + 1];
      const value = next === "=" ? `${character}=` : character;
      tokens.push({ kind: "operator", value, offset });
      offset += value.length;
      continue;
    }
    if (character === "=") {
      tokens.push({ kind: "operator", value: "=", offset });
      offset += 1;
      continue;
    }
    if (character === "(" || character === ")" || character === "," || character === "!") {
      tokens.push({ kind: "punctuation", value: character, offset });
      offset += 1;
      continue;
    }
    return rejected("query", `unexpected character ${JSON.stringify(character)}`, offset);
  }
  return parsed(Object.freeze(tokens));
}
function readJsonString(source, start) {
  let escaped = false;
  for (let offset = start + 1; offset < source.length; offset += 1) {
    const character = source[offset];
    if (character === void 0) break;
    if (escaped) {
      escaped = false;
    } else if (character === "\\") {
      escaped = true;
    } else if (character === '"') {
      const raw = source.slice(start, offset + 1);
      try {
        const value = JSON.parse(raw);
        if (typeof value !== "string") return rejected("query", "expected a string literal", start);
        return parsed({ token: { kind: "string", value, offset: start }, nextOffset: offset + 1 });
      } catch {
        return rejected("query", "invalid JSON string literal", start);
      }
    }
  }
  return rejected("query", "unterminated string literal", start);
}
function readQuotedIdentifier(source, start) {
  const end = source.indexOf("'", start + 1);
  if (end < 0) return rejected("query", "unterminated quoted identifier", start);
  const value = source.slice(start + 1, end);
  if (value.length === 0) return rejected("query", "quoted identifier cannot be empty", start);
  return parsed({ token: { kind: "quoted_identifier", value, offset: start }, nextOffset: end + 1 });
}
function isIdentifierStart(character) {
  return /^[A-Za-z]$/.test(character);
}
function isIdentifierContinuation(character) {
  return /^[A-Za-z0-9:_?+.-]$/.test(character);
}
function isDigit(character) {
  return /^[0-9]$/.test(character);
}
var Parser = class {
  constructor(source, tokens) {
    this.source = source;
    this.tokens = tokens;
  }
  source;
  tokens;
  cursor = 0;
  parse() {
    const facts = [];
    const constraints = [];
    while (this.cursor < this.tokens.length) {
      const clause = this.parseClause();
      if (!clause.ok) return clause;
      if (clause.value.kind === "fact") facts.push(clause.value);
      else constraints.push(clause.value);
      if (this.cursor === this.tokens.length) break;
      const comma = this.consumePunctuation(",");
      if (!comma) {
        const token = this.peek();
        return this.errorAt(token, "expected a comma between clauses");
      }
      if (this.cursor === this.tokens.length) {
        return rejected("query", "expected a clause after the comma", this.source.length);
      }
    }
    return createDatalogQuery(facts, constraints);
  }
  parseClause() {
    if (this.peek()?.kind === "punctuation" && this.peek()?.value === "!") {
      return this.errorAt(this.take(), "negated relations are outside the initial Datalog subset");
    }
    if (this.isCallStart()) return this.parseCallClause();
    return this.parseComparison();
  }
  parseCallClause() {
    const predicate = this.take();
    if (predicate === void 0 || predicate.kind !== "identifier" && predicate.kind !== "quoted_identifier") {
      return this.errorAt(predicate, "expected a relation name");
    }
    if (!this.consumePunctuation("(")) return this.errorAt(this.peek(), "expected `(` after relation name");
    const left = this.parseTerm();
    if (!left.ok) return left;
    if (!this.consumePunctuation(",")) return this.errorAt(this.peek(), "expected `,` between relation terms");
    const right = this.parseTerm();
    if (!right.ok) return right;
    if (!this.consumePunctuation(")")) {
      return this.errorAt(this.peek(), "relations in this subset must have exactly two terms");
    }
    if (BUILTINS.has(predicate.value)) {
      return parsed(Object.freeze({
        kind: "builtin",
        name: predicate.value,
        left: left.value,
        right: right.value
      }));
    }
    const parsedPredicate = parseUri(predicate.value, "query.predicate");
    if (!parsedPredicate.ok) {
      return rejected("query", parsedPredicate.error.message, predicate.offset);
    }
    return parsed(Object.freeze({
      kind: "fact",
      predicate: parsedPredicate.value,
      entity: left.value,
      value: right.value
    }));
  }
  parseComparison() {
    const left = this.parseTerm();
    if (!left.ok) return left;
    const operator = this.take();
    if (operator?.kind !== "operator") return this.errorAt(operator, "expected a supported comparison operator");
    const right = this.parseTerm();
    if (!right.ok) return right;
    return parsed(Object.freeze({ kind: "builtin", name: operator.value, left: left.value, right: right.value }));
  }
  parseTerm() {
    const token = this.take();
    if (token === void 0) return this.errorAt(void 0, "expected a term");
    if (token.kind === "integer") {
      return parsed(Object.freeze({ kind: "constant", value: integerValue(token.value) }));
    }
    if (token.kind === "string" || token.kind === "quoted_identifier") {
      return parsed(Object.freeze({ kind: "constant", value: stringValue(token.value) }));
    }
    if (token.kind === "identifier") {
      if (token.value === "_") return parsed(Object.freeze({ kind: "wildcard" }));
      const firstCharacter = token.value[0] ?? "";
      if (/^[A-Z]$/.test(firstCharacter)) {
        return parsed(Object.freeze({ kind: "variable", name: token.value }));
      }
      return parsed(Object.freeze({ kind: "constant", value: stringValue(token.value) }));
    }
    return this.errorAt(token, "expected a variable, constant, or wildcard");
  }
  isCallStart() {
    const current = this.peek();
    const next = this.tokens[this.cursor + 1];
    return (current?.kind === "identifier" || current?.kind === "quoted_identifier") && next?.kind === "punctuation" && next.value === "(";
  }
  consumePunctuation(value) {
    const token = this.peek();
    if (token?.kind !== "punctuation" || token.value !== value) return false;
    this.cursor += 1;
    return true;
  }
  errorAt(token, message) {
    const offset = token?.offset ?? this.source.length;
    return rejected("query", message, offset);
  }
  peek() {
    return this.tokens[this.cursor];
  }
  take() {
    const token = this.tokens[this.cursor];
    if (token !== void 0) this.cursor += 1;
    return token;
  }
};

// ../../poneglyph/src/storage/routing.ts
async function resolveEntityLeaf(env, graphId, entity, directoryEpoch) {
  const key = await virtualKeyForEntity(graphId, entity);
  return resolveKeyLeaf(env, graphId, key, directoryEpoch);
}
async function resolveKeyLeaf(env, graphId, key, directoryEpoch) {
  let prefix = "";
  for (let hop = 0; hop < MAX_DIRECTORY_LOOKUP_HOPS; hop += 1) {
    const node = await readDirectoryNode(env, graphId, prefix, directoryEpoch, key);
    if (node.kind === "leaf" || directoryEpoch < node.splitEpoch) {
      if (node.kind === "router" && node.retired) {
        throw new DirectoryRouteError(410, "the requested directory epoch has retired");
      }
      if (!matchesPrefix(key, node.prefix)) throw new DirectoryRouteError(409, "directory returned an owner outside the entity range");
      const generation = node.kind === "router" ? node.generation - 1 : node.generation;
      return { address: { prefix: node.prefix, generation }, directoryHops: hop + 1 };
    }
    if (prefix.length >= MAX_DIRECTORY_DEPTH) throw new DirectoryRouteError(507, "directory reached the full virtual-key depth");
    prefix = bitAt(key, prefix.length) === "0" ? node.children[0] : node.children[1];
  }
  throw new DirectoryRouteError(507, "directory lookup exceeded its hop budget");
}
async function listShardLeaves(env, graphId, directoryEpoch) {
  const pending = [""];
  const leaves = [];
  let directoryHops = 0;
  while (pending.length > 0) {
    const prefix = pending.pop();
    if (prefix === void 0) break;
    directoryHops += 1;
    if (directoryHops > MAX_QUERY_DIRECTORY_NODES) {
      throw new DirectoryRouteError(413, "query directory traversal budget exceeded");
    }
    const node = await readDirectoryNode(env, graphId, prefix, directoryEpoch);
    if (node.kind === "leaf" || directoryEpoch < node.splitEpoch) {
      if (node.kind === "router" && node.retired) {
        throw new DirectoryRouteError(410, "the requested directory epoch has retired");
      }
      leaves.push({ prefix: node.prefix, generation: node.kind === "router" ? node.generation - 1 : node.generation });
      if (leaves.length > MAX_QUERY_SHARD_FANOUT) {
        throw new DirectoryRouteError(413, "query leaf fan-out budget exceeded");
      }
      continue;
    }
    pending.push(node.children[1], node.children[0]);
  }
  leaves.sort((left, right) => left.prefix.localeCompare(right.prefix));
  return { leaves, directoryHops };
}
async function readDirectoryNode(env, graphId, prefix, directoryEpoch, key) {
  const stub = env.GRAPH_SHARDS.getByName(shardObjectName(graphId, prefix));
  const body = { graphId, prefix, directoryEpoch };
  if (key !== void 0) body["virtualKey"] = key;
  const response = await stub.fetch("https://shard.internal/_route", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify(body)
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 256);
    throw new DirectoryRouteError(response.status, `directory lookup failed: ${detail}`);
  }
  let input;
  try {
    input = await response.json();
  } catch {
    throw new DirectoryRouteError(502, "directory returned invalid JSON");
  }
  return parseDirectoryNode(input, prefix);
}
function parseDirectoryNode(input, expectedPrefix) {
  if (!isRecord(input) || input["prefix"] !== expectedPrefix) {
    throw new DirectoryRouteError(502, "directory returned an invalid node identity");
  }
  const generation = input["generation"];
  if (typeof generation !== "number" || !Number.isSafeInteger(generation) || generation < 0) {
    throw new DirectoryRouteError(502, "directory returned an invalid generation");
  }
  if (input["kind"] === "leaf") return { kind: "leaf", prefix: expectedPrefix, generation };
  if (input["kind"] !== "router") throw new DirectoryRouteError(502, "directory returned an unknown node kind");
  const splitEpoch = input["splitEpoch"];
  const rawChildren = input["children"];
  if (!Number.isSafeInteger(splitEpoch) || typeof splitEpoch !== "number" || splitEpoch < 1 || !Array.isArray(rawChildren) || rawChildren.length !== 2) {
    throw new DirectoryRouteError(502, "directory returned invalid split metadata");
  }
  const left = parseVirtualPrefix(rawChildren[0]);
  const right = parseVirtualPrefix(rawChildren[1]);
  if (!left.ok || !right.ok || left.value !== `${expectedPrefix}0` || right.value !== `${expectedPrefix}1`) {
    throw new DirectoryRouteError(502, "directory returned invalid child prefixes");
  }
  if (typeof input["retired"] !== "boolean") throw new DirectoryRouteError(502, "directory returned an invalid retirement flag");
  return {
    kind: "router",
    prefix: expectedPrefix,
    generation,
    splitEpoch,
    children: [left.value, right.value],
    retired: input["retired"]
  };
}
var DirectoryRouteError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "DirectoryRouteError";
  }
  status;
};

// ../../poneglyph/src/storage/distributed-fact-source.ts
var DistributedFactSource = class {
  constructor(env, graphId, snapshotSeq, directoryEpoch, leaseExpiresAtMs, metrics = { scanCalls: 0, shardRequests: 0, tuplesRead: 0, bytesRead: 0, directoryRequests: 0 }) {
    this.env = env;
    this.graphId = graphId;
    this.snapshotSeq = snapshotSeq;
    this.directoryEpoch = directoryEpoch;
    this.leaseExpiresAtMs = leaseExpiresAtMs;
    this.metrics = metrics;
  }
  env;
  graphId;
  snapshotSeq;
  directoryEpoch;
  leaseExpiresAtMs;
  metrics;
  allLeaves;
  entityRoutes = /* @__PURE__ */ new Map();
  async *scan(lookup, signal) {
    const shardAddresses = await this.targetShards(lookup);
    if (shardAddresses === void 0) return;
    this.metrics.scanCalls += 1;
    this.metrics.shardRequests += shardAddresses.length;
    if (this.metrics.shardRequests > MAX_QUERY_SHARD_REQUESTS) {
      throw new QueryScanBudgetExceeded("query shard-request budget exceeded");
    }
    const opened = await Promise.allSettled(shardAddresses.map(async (address) => {
      const stub = this.env.GRAPH_SHARDS.getByName(shardObjectName(this.graphId, address.prefix));
      const body = {
        graphId: this.graphId,
        shardPrefix: address.prefix,
        shardGeneration: address.generation,
        directoryEpoch: this.directoryEpoch,
        field: lookup.field,
        snapshotSeq: this.snapshotSeq,
        leaseExpiresAtMs: this.leaseExpiresAtMs
      };
      if (lookup.entity !== void 0) body["entity"] = lookup.entity;
      if (lookup.value !== void 0) body["value"] = lookup.value;
      const init = {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body)
      };
      if (signal !== void 0) init.signal = signal;
      const response = await stub.fetch("https://shard.internal/_scan", init);
      if (!response.ok) {
        const detail = await response.text();
        throw new Error(`shard ${address.prefix} scan failed (${response.status}): ${detail.slice(0, 512)}`);
      }
      if (response.body === null) throw new Error(`shard ${address.prefix} returned no scan stream`);
      return { shardPrefix: address.prefix, body: response.body };
    }));
    const responses = [];
    let openFailure;
    let failedToOpen = false;
    for (const result of opened) {
      if (result.status === "fulfilled") responses.push(result.value);
      else if (!failedToOpen) {
        openFailure = result.reason;
        failedToOpen = true;
      }
    }
    if (failedToOpen) {
      await Promise.all(responses.map(async ({ body }) => {
        try {
          await body.cancel();
        } catch {
        }
      }));
      throw openFailure;
    }
    const iterators = responses.map(({ body }) => readTupleStream(body, this.metrics, signal)[Symbol.asyncIterator]());
    const pending = /* @__PURE__ */ new Map();
    for (const [index, iterator] of iterators.entries()) {
      pending.set(index, iterator.next().then((next) => ({ index, next })));
    }
    try {
      while (pending.size > 0) {
        const { index, next } = await Promise.race(pending.values());
        pending.delete(index);
        if (next.done) continue;
        yield next.value;
        const iterator = iterators[index];
        if (iterator !== void 0) pending.set(index, iterator.next().then((result) => ({ index, next: result })));
      }
    } finally {
      await Promise.all(iterators.map(async (iterator) => {
        try {
          await iterator.return?.(void 0);
        } catch {
        }
      }));
    }
  }
  async targetShards(lookup) {
    if (lookup.entity === void 0) {
      if (this.allLeaves === void 0) {
        const listing = await listShardLeaves(this.env, this.graphId, this.directoryEpoch);
        this.metrics.directoryRequests += listing.directoryHops;
        this.allLeaves = listing.leaves;
      }
      return this.allLeaves;
    }
    if (lookup.entity.type !== "string") return void 0;
    const entity = parseUri(lookup.entity.value);
    if (!entity.ok) return void 0;
    const cached = this.entityRoutes.get(entity.value);
    if (cached !== void 0) return [cached];
    const route = await resolveEntityLeaf(this.env, this.graphId, entity.value, this.directoryEpoch);
    this.metrics.directoryRequests += route.directoryHops;
    this.entityRoutes.set(entity.value, route.address);
    return [route.address];
  }
};
async function* readTupleStream(body, metrics, signal) {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffered = "";
  let finished = false;
  try {
    while (true) {
      if (signal?.aborted) throw abortError(signal);
      const chunk = await reader.read();
      if (chunk.done) {
        finished = true;
        buffered += decoder.decode();
        if (buffered.length > 0) yield parseTupleLine(buffered, metrics);
        return;
      }
      metrics.bytesRead += chunk.value.byteLength;
      if (metrics.bytesRead > MAX_QUERY_SCAN_BYTES) throw new QueryScanBudgetExceeded("query scan byte budget exceeded");
      buffered += decoder.decode(chunk.value, { stream: true });
      if (buffered.length > MAX_TRANSACTION_BYTES && !buffered.includes("\n")) {
        throw new QueryScanBudgetExceeded("a shard emitted a tuple larger than the row budget");
      }
      while (true) {
        const newline = buffered.indexOf("\n");
        if (newline < 0) break;
        const line = buffered.slice(0, newline);
        buffered = buffered.slice(newline + 1);
        if (line.length > 0) yield parseTupleLine(line, metrics);
      }
    }
  } finally {
    if (!finished) {
      try {
        await reader.cancel();
      } catch {
      }
    }
    reader.releaseLock();
  }
}
function parseTupleLine(line, metrics) {
  let input;
  try {
    input = JSON.parse(line);
  } catch {
    throw new Error("shard emitted invalid NDJSON");
  }
  if (!isRecord(input)) throw new Error("shard emitted an invalid fact tuple");
  const entity = parseUri(input["entity"], "tuple.entity");
  const value = parseDatalogValue(input["value"], "tuple.value");
  if (!entity.ok || !value.ok) throw new Error("shard emitted an invalid fact tuple");
  metrics.tuplesRead += 1;
  if (metrics.tuplesRead > MAX_QUERY_TUPLES) throw new QueryScanBudgetExceeded("query tuple budget exceeded");
  return Object.freeze({
    entity: Object.freeze({ type: "string", value: entity.value }),
    value: value.value
  });
}
function abortError(signal) {
  return signal.reason instanceof Error ? signal.reason : new DOMException("Query aborted", "AbortError");
}
var QueryScanBudgetExceeded = class extends Error {
  constructor(message) {
    super(message);
    this.name = "QueryScanBudgetExceeded";
  }
};

// ../../poneglyph/src/storage/capacity.ts
var encoder2 = new TextEncoder();
function estimateMutationFootprint(facts, existingProjectionBytesByEntity = /* @__PURE__ */ new Map()) {
  const factsByEntity = /* @__PURE__ */ new Map();
  let factLogBytes = 0;
  let activeIndexBytes = 0;
  let transactionStagingBytes = 0;
  for (const fact2 of facts) {
    const serialized = JSON.stringify(fact2);
    const factBytes = encoder2.encode(serialized).byteLength;
    factLogBytes += factBytes + 256;
    transactionStagingBytes += factBytes + 128;
    const scalarCount = fact2.value.type === "list" ? Math.max(1, fact2.value.value.length) : 1;
    activeIndexBytes += (factBytes + 128) * scalarCount * 4;
    factsByEntity.set(fact2.entity, (factsByEntity.get(fact2.entity) ?? 0) + factBytes);
  }
  let projectionBytes = 0;
  for (const [entity, entityFactBytes] of factsByEntity) {
    const existingProjectionBytes = existingProjectionBytesByEntity.get(entity) ?? 0;
    projectionBytes += (existingProjectionBytes + entityFactBytes + encoder2.encode(entity).byteLength + 512) * 2;
  }
  return Object.freeze({ factLogBytes, activeIndexBytes, projectionBytes, transactionStagingBytes });
}
function accountStorage(databaseBytes, pending, migrationReserveBytes = 0) {
  if (!isByteCount(databaseBytes) || !isByteCount(migrationReserveBytes)) {
    throw new RangeError("storage byte counts must be non-negative safe integers");
  }
  for (const bytes of Object.values(pending)) {
    if (!isByteCount(bytes)) throw new RangeError("pending byte estimates must be non-negative safe integers");
  }
  const pendingGrowthBytes = pending.factLogBytes + pending.activeIndexBytes + pending.projectionBytes + pending.transactionStagingBytes;
  const projectedDatabaseBytes = databaseBytes + pendingGrowthBytes;
  const walAndCheckpointReserveBytes = Math.max(
    MINIMUM_WAL_RESERVE_BYTES,
    Math.ceil(projectedDatabaseBytes * 0.1)
  );
  const uncertaintyHeadroomBytes = MINIMUM_UNCERTAINTY_HEADROOM_BYTES;
  const projectedAccountedBytes = projectedDatabaseBytes + walAndCheckpointReserveBytes + migrationReserveBytes + uncertaintyHeadroomBytes;
  return Object.freeze({
    databaseBytes,
    pending,
    walAndCheckpointReserveBytes,
    migrationReserveBytes,
    uncertaintyHeadroomBytes,
    projectedAccountedBytes,
    shouldSplit: projectedDatabaseBytes >= SHARD_SPLIT_TRIGGER_BYTES,
    canAdmit: projectedAccountedBytes <= MAX_ACCOUNTED_BYTES_PER_DO
  });
}
function isByteCount(input) {
  return Number.isSafeInteger(input) && input >= 0;
}

// ../../poneglyph/src/storage/sql.ts
var COORDINATOR_SCHEMA = [
  `CREATE TABLE IF NOT EXISTS graph_identity (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    graph_id TEXT NOT NULL,
    routing_version INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS graph_state (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    visible_seq INTEGER NOT NULL,
    directory_epoch INTEGER NOT NULL,
    writer_tx_id TEXT,
    topology_op_id TEXT,
    next_statement_time_ms INTEGER NOT NULL
  )`,
  `INSERT OR IGNORE INTO graph_state
   (singleton, visible_seq, directory_epoch, writer_tx_id, topology_op_id, next_statement_time_ms)
   VALUES (1, 0, 0, NULL, NULL, 0)`,
  `CREATE TABLE IF NOT EXISTS graph_transactions (
    tx_id TEXT PRIMARY KEY,
    payload_hash TEXT NOT NULL,
    batch_json TEXT,
    participants_json TEXT NOT NULL,
    directory_epoch INTEGER NOT NULL,
    statement_time_ms INTEGER NOT NULL,
    commit_seq INTEGER NOT NULL,
    phase TEXT NOT NULL CHECK (phase IN ('preparing', 'committing', 'cancelling', 'complete', 'aborted')),
    created_at_ms INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS graph_read_leases (
    read_id TEXT PRIMARY KEY,
    snapshot_seq INTEGER NOT NULL,
    directory_epoch INTEGER NOT NULL,
    expires_at_ms INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS graph_read_leases_by_expiry
   ON graph_read_leases (expires_at_ms, snapshot_seq, directory_epoch)`,
  `CREATE TABLE IF NOT EXISTS graph_splits (
    migration_id TEXT PRIMARY KEY,
    source_prefix TEXT NOT NULL,
    source_generation INTEGER NOT NULL,
    left_prefix TEXT NOT NULL,
    right_prefix TEXT NOT NULL,
    base_visible_seq INTEGER NOT NULL,
    old_directory_epoch INTEGER NOT NULL,
    split_epoch INTEGER NOT NULL,
    phase TEXT NOT NULL CHECK (phase IN ('copying', 'ready', 'cutover', 'retired')),
    force INTEGER NOT NULL DEFAULT 0,
    created_at_ms INTEGER NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS graph_splits_by_phase ON graph_splits (phase, created_at_ms)`
];
var SHARD_SCHEMA = [
  `CREATE TABLE IF NOT EXISTS shard_identity (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    graph_id TEXT NOT NULL,
    prefix TEXT NOT NULL,
    generation INTEGER NOT NULL,
    role TEXT NOT NULL CHECK (role IN ('leaf', 'router')),
    split_epoch INTEGER,
    child_zero_prefix TEXT,
    child_one_prefix TEXT,
    migration_id TEXT,
    migration_state TEXT NOT NULL CHECK (migration_state IN ('active', 'copying', 'ready', 'retired'))
  )`,
  `CREATE TABLE IF NOT EXISTS shard_transactions (
    tx_id TEXT PRIMARY KEY,
    payload_hash TEXT NOT NULL,
    payload_json TEXT,
    status TEXT NOT NULL CHECK (status IN ('prepared', 'committed', 'cancelled')),
    created_at_ms INTEGER NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS fact_log (
    fact_id TEXT PRIMARY KEY,
    tx_id TEXT NOT NULL,
    tx_index INTEGER NOT NULL,
    commit_seq INTEGER NOT NULL,
    source TEXT NOT NULL,
    entity TEXT NOT NULL,
    entity_hash TEXT NOT NULL,
    field TEXT NOT NULL,
    value_json TEXT NOT NULL,
    retraction INTEGER NOT NULL,
    stated_at TEXT NOT NULL
  )`,
  `CREATE INDEX IF NOT EXISTS fact_log_by_entity_hash
   ON fact_log (entity_hash, entity, fact_id)`,
  `CREATE TABLE IF NOT EXISTS active_facts (
    source TEXT NOT NULL,
    entity TEXT NOT NULL,
    entity_hash TEXT NOT NULL,
    field TEXT NOT NULL,
    value_json TEXT NOT NULL,
    fact_id TEXT NOT NULL,
    tx_id TEXT NOT NULL,
    stated_at TEXT NOT NULL,
    valid_from_seq INTEGER NOT NULL,
    valid_to_seq INTEGER,
    PRIMARY KEY (source, entity, field, value_json, valid_from_seq, fact_id)
  )`,
  `CREATE UNIQUE INDEX IF NOT EXISTS active_facts_by_current_tuple
   ON active_facts (source, entity, field, value_json) WHERE valid_to_seq IS NULL`,
  `CREATE INDEX IF NOT EXISTS active_facts_by_entity_hash
   ON active_facts (entity_hash, entity, valid_from_seq, valid_to_seq)`,
  `CREATE INDEX IF NOT EXISTS active_facts_by_field_snapshot
   ON active_facts (field, valid_from_seq, valid_to_seq)`,
  `CREATE INDEX IF NOT EXISTS active_facts_by_entity_field_snapshot
   ON active_facts (entity, field, valid_from_seq, valid_to_seq)`,
  `CREATE TABLE IF NOT EXISTS active_values (
    fact_id TEXT NOT NULL,
    value_index INTEGER NOT NULL,
    source TEXT NOT NULL,
    entity TEXT NOT NULL,
    entity_hash TEXT NOT NULL,
    field TEXT NOT NULL,
    datalog_type TEXT NOT NULL,
    datalog_value TEXT NOT NULL,
    value_key TEXT NOT NULL,
    value_json TEXT NOT NULL,
    tx_id TEXT NOT NULL,
    stated_at TEXT NOT NULL,
    valid_from_seq INTEGER NOT NULL,
    valid_to_seq INTEGER,
    PRIMARY KEY (fact_id, value_index, valid_from_seq)
  )`,
  `CREATE INDEX IF NOT EXISTS active_values_by_entity_hash
   ON active_values (entity_hash, entity, fact_id, value_index)`,
  `CREATE INDEX IF NOT EXISTS active_values_by_field_snapshot
   ON active_values (field, valid_from_seq, valid_to_seq, entity)`,
  `CREATE INDEX IF NOT EXISTS active_values_by_field_page
   ON active_values (field, entity, fact_id, value_index, valid_from_seq, valid_to_seq)`,
  `CREATE INDEX IF NOT EXISTS active_values_by_field_entity_snapshot
   ON active_values (field, entity, valid_from_seq, valid_to_seq)`,
  `CREATE INDEX IF NOT EXISTS active_values_by_field_value_snapshot
   ON active_values (field, value_key, valid_from_seq, valid_to_seq, entity)`,
  `CREATE INDEX IF NOT EXISTS active_values_by_field_entity_value_snapshot
   ON active_values (field, entity, value_key, valid_from_seq, valid_to_seq)`,
  `CREATE TABLE IF NOT EXISTS entity_versions (
    entity TEXT NOT NULL,
    entity_hash TEXT NOT NULL,
    fields_json TEXT NOT NULL,
    last_tx_id TEXT NOT NULL,
    valid_from_seq INTEGER NOT NULL,
    valid_to_seq INTEGER,
    PRIMARY KEY (entity, valid_from_seq)
  )`,
  `CREATE INDEX IF NOT EXISTS entity_versions_by_entity_hash
   ON entity_versions (entity_hash, entity, valid_from_seq, valid_to_seq)`,
  `CREATE INDEX IF NOT EXISTS entity_versions_by_snapshot
   ON entity_versions (entity, valid_from_seq, valid_to_seq)`,
  `CREATE TABLE IF NOT EXISTS migration_import_pages (
    migration_id TEXT NOT NULL,
    table_name TEXT NOT NULL,
    target_prefix TEXT NOT NULL,
    page_number INTEGER NOT NULL,
    page_hash TEXT NOT NULL,
    row_count INTEGER NOT NULL,
    PRIMARY KEY (migration_id, table_name, target_prefix, page_number)
  )`,
  `CREATE TABLE IF NOT EXISTS shard_accounting (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    migration_reserved_bytes INTEGER NOT NULL DEFAULT 0,
    synthetic_size_bytes INTEGER NOT NULL DEFAULT 0
  )`,
  `INSERT OR IGNORE INTO shard_accounting (singleton, migration_reserved_bytes) VALUES (1, 0)`
];
var PONEGLYPH_SCHEMA_VERSION = 1;
function ensureCoordinatorSchema(storage) {
  ensureSchema(storage, "coordinator", COORDINATOR_SCHEMA);
}
function ensureShardSchema(storage) {
  ensureSchema(storage, "shard", SHARD_SCHEMA);
}
function ensureSchema(storage, kind, statements) {
  storage.transactionSync(() => {
    const schemaMarkerExists = storage.sql.exec(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'poneglyph_schema'"
    ).toArray().length > 0;
    if (schemaMarkerExists) {
      const marker = storage.sql.exec(
        "SELECT kind, version FROM poneglyph_schema WHERE singleton = 1"
      ).toArray()[0];
      if (marker?.kind !== kind || marker.version !== PONEGLYPH_SCHEMA_VERSION) {
        throw new Error(`unsupported ${kind} Durable Object schema marker; refusing to reinterpret persisted data`);
      }
      return;
    }
    const existingTables = storage.sql.exec(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'"
    ).toArray();
    if (existingTables.length > 0) {
      throw new Error(
        `existing ${kind} Durable Object SQLite schema is unversioned; automatic schema upgrade/import is unsupported, use a fresh namespace`
      );
    }
    for (const statement of statements) storage.sql.exec(statement);
    storage.sql.exec(
      `CREATE TABLE poneglyph_schema (
        singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
        kind TEXT NOT NULL,
        version INTEGER NOT NULL
      )`
    );
    storage.sql.exec(
      "INSERT INTO poneglyph_schema (singleton, kind, version) VALUES (1, ?, ?)",
      kind,
      PONEGLYPH_SCHEMA_VERSION
    );
  });
}

// ../../poneglyph/src/storage/coordinator.ts
var GraphCoordinatorDO = class extends DurableObject {
  activeWriterTxId;
  activeTopologyOpId;
  constructor(ctx, env) {
    super(ctx, env);
    void ctx.blockConcurrencyWhile(async () => ensureCoordinatorSchema(ctx.storage));
  }
  async fetch(request) {
    if (request.method === "POST" && new URL(request.url).pathname === "/_split") {
      try {
        return await this.requestSplit(request);
      } catch (error) {
        const status = error instanceof CoordinatorError ? error.status : 503;
        return jsonResponse({ error: errorMessage(error), retryable: status >= 500 }, status, { "retry-after": "1" });
      }
    }
    const route = parseGraphRoute(request);
    if (route === void 0) return jsonResponse({ error: "not found" }, 404);
    try {
      this.assertGraphIdentity(route.graphId);
      if (route.action === "transactions" && request.method === "POST") {
        return await this.writeTransaction(request, route.graphId);
      }
      if (route.action === "query" && request.method === "POST") {
        return await this.runQuery(request, route.graphId);
      }
      if (route.action === "entities" && request.method === "GET") {
        return await this.readEntity(request, route.graphId);
      }
      return jsonResponse({ error: "method not allowed" }, 405);
    } catch (error) {
      const status = error instanceof CoordinatorError ? error.status : 503;
      return jsonResponse({ error: errorMessage(error), retryable: status >= 500 }, status);
    }
  }
  async requestSplit(request) {
    const input = await readJsonBody(request, 8192);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "expected a split request object" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const prefix = parseVirtualPrefix(input.value["prefix"]);
    const force = input.value["force"] === true;
    const stopAfterPages = input.value["stopAfterPages"];
    if (!graphId.ok || !prefix.ok || stopAfterPages !== void 0 && (typeof stopAfterPages !== "number" || !Number.isSafeInteger(stopAfterPages) || stopAfterPages < 1)) {
      return jsonResponse({ error: "invalid split request identity" }, 400);
    }
    this.assertGraphIdentity(graphId.value);
    const current = this.readGraphState();
    const route = await this.postShard(prefix.value, "_route", {
      graphId: graphId.value,
      prefix: prefix.value,
      directoryEpoch: current.directory_epoch
    });
    if (route["kind"] === "router") {
      return jsonResponse({ status: "already-split", prefix: prefix.value, directoryEpoch: current.directory_epoch, visibleSeq: current.visible_seq });
    }
    const migrationId = this.reserveSplit(prefix.value, force);
    const interrupted = await this.performSplit(migrationId, stopAfterPages);
    if (interrupted instanceof Response) return interrupted;
    const state = this.readGraphState();
    return jsonResponse({ status: "split", prefix: prefix.value, directoryEpoch: state.directory_epoch, visibleSeq: state.visible_seq });
  }
  reserveSplit(prefix, force) {
    return this.ctx.storage.transactionSync(() => {
      const state = this.readGraphState();
      if (state.writer_tx_id !== null) throw new CoordinatorError(423, "cannot split while a transaction decision is pending");
      if (state.topology_op_id !== null) {
        const existing = this.readSplit(state.topology_op_id);
        if (existing?.source_prefix === prefix) return state.topology_op_id;
        throw new CoordinatorError(423, "another topology operation is already active");
      }
      const capacity = accountStorage(this.ctx.storage.sql.databaseSize, {
        factLogBytes: 0,
        activeIndexBytes: 0,
        projectionBytes: 0,
        transactionStagingBytes: 2048
      });
      if (!capacity.canAdmit) throw new CoordinatorError(413, "coordinator cannot reserve metadata for another topology operation");
      const migrationId = crypto.randomUUID();
      const leftPrefix = `${prefix}0`;
      const rightPrefix = `${prefix}1`;
      const splitEpoch = state.directory_epoch + 1;
      this.ctx.storage.sql.exec(
        `INSERT INTO graph_splits
         (migration_id, source_prefix, source_generation, left_prefix, right_prefix, base_visible_seq,
          old_directory_epoch, split_epoch, phase, force, created_at_ms)
         VALUES (?, ?, 0, ?, ?, ?, ?, ?, 'copying', ?, ?)`,
        migrationId,
        prefix,
        leftPrefix,
        rightPrefix,
        state.visible_seq,
        state.directory_epoch,
        splitEpoch,
        force ? 1 : 0,
        Date.now()
      );
      this.ctx.storage.sql.exec("UPDATE graph_state SET topology_op_id = ? WHERE singleton = 1", migrationId);
      return migrationId;
    });
  }
  async performSplit(migrationId, stopAfterPages) {
    if (this.activeTopologyOpId !== void 0) return this.topologyBusy(this.activeTopologyOpId);
    this.activeTopologyOpId = migrationId;
    try {
      return await this.performSplitStep(migrationId, stopAfterPages);
    } finally {
      this.activeTopologyOpId = void 0;
    }
  }
  async performSplitStep(migrationId, stopAfterPages) {
    const split = this.readSplit(migrationId);
    if (split === void 0) throw new CoordinatorError(500, "topology operation record is missing");
    if (split.phase === "retired" || split.phase === "cutover") return void 0;
    const graphId = this.readGraphIdentity();
    const sourcePrefix = split.source_prefix;
    const splitIdentity = {
      graphId,
      prefix: sourcePrefix,
      generation: split.source_generation,
      migrationId,
      splitEpoch: split.split_epoch,
      leftPrefix: split.left_prefix,
      rightPrefix: split.right_prefix,
      force: split.force === 1
    };
    const started = await this.postShard(sourcePrefix, "_begin-split", splitIdentity);
    const beginStatus = started["status"];
    if (beginStatus === "capacity-limit" || beginStatus === "no-progress") {
      await this.postShard(sourcePrefix, "_abort-split", { graphId, prefix: sourcePrefix, migrationId });
      this.clearSplit(migrationId);
      throw new CoordinatorError(413, beginStatus === "capacity-limit" ? "split children cannot fit under the per-DO accounted capacity limit" : "virtual-prefix split would make no progress");
    }
    if (beginStatus !== "copying" && beginStatus !== "already-cut-over") {
      throw new CoordinatorError(503, "source did not enter the expected split state");
    }
    let copiedPages = 0;
    if (beginStatus !== "already-cut-over") {
      const children = [split.left_prefix, split.right_prefix];
      const reserves = [started["leftReservedBytes"], started["rightReservedBytes"]];
      for (const [index, childPrefix] of children.entries()) {
        const reservedBytes = reserves[index];
        if (typeof reservedBytes !== "number" || !Number.isSafeInteger(reservedBytes) || reservedBytes < 0) {
          throw new CoordinatorError(500, "source returned an invalid child capacity estimate");
        }
        await this.postShard(childPrefix, "_init-child", { graphId, prefix: childPrefix, migrationId, reservedBytes });
      }
      for (const table of ["fact_log", "active_facts", "active_values", "entity_versions"]) {
        for (const childPrefix of children) {
          let pageNumber = 0;
          let afterRowId = 0;
          while (true) {
            const exported = await this.postShard(sourcePrefix, "_export", {
              graphId,
              sourcePrefix,
              targetPrefix: childPrefix,
              migrationId,
              table,
              pageNumber,
              afterRowId
            });
            const rows = exported["rows"];
            const nextRowId = exported["nextRowId"];
            const hasMore = exported["hasMore"];
            const pageHash = exported["pageHash"];
            if (!Array.isArray(rows) || typeof nextRowId !== "number" || typeof hasMore !== "boolean" || typeof pageHash !== "string") {
              throw new CoordinatorError(502, "source returned an invalid split page");
            }
            if (rows.length > 0) {
              await this.postShard(childPrefix, "_import", {
                graphId,
                targetPrefix: childPrefix,
                migrationId,
                table,
                pageNumber,
                pageHash,
                rows
              });
              copiedPages += 1;
              if (stopAfterPages !== void 0 && copiedPages >= stopAfterPages) {
                return jsonResponse({ status: "copy-interrupted-for-recovery-test", migrationId, copiedPages }, 503, { "retry-after": "1" });
              }
            }
            if (!hasMore) break;
            if (nextRowId <= afterRowId || pageNumber > 1e6) throw new CoordinatorError(500, "split export cursor failed to advance");
            afterRowId = nextRowId;
            pageNumber += 1;
          }
        }
      }
      for (const table of ["fact_log", "active_facts", "active_values", "entity_versions"]) {
        for (const childPrefix of children) {
          const sourceCount = await this.postShard(sourcePrefix, "_count", {
            graphId,
            nodePrefix: sourcePrefix,
            rangePrefix: childPrefix,
            table
          });
          const childCount = await this.postShard(childPrefix, "_count", {
            graphId,
            nodePrefix: childPrefix,
            rangePrefix: childPrefix,
            table
          });
          if (sourceCount["count"] !== childCount["count"]) {
            throw new CoordinatorError(503, `split verification count mismatch for ${table} at prefix ${childPrefix}`);
          }
        }
      }
      for (const childPrefix of children) {
        await this.postShard(childPrefix, "_finish-child", { graphId, prefix: childPrefix, migrationId });
      }
      this.ctx.storage.transactionSync(() => {
        this.ctx.storage.sql.exec("UPDATE graph_splits SET phase = 'ready' WHERE migration_id = ? AND phase = 'copying'", migrationId);
      });
    }
    await this.postShard(sourcePrefix, "_cutover", splitIdentity);
    this.ctx.storage.transactionSync(() => {
      const state = this.readGraphState();
      if (state.directory_epoch === split.old_directory_epoch) {
        if (state.topology_op_id !== migrationId || state.visible_seq !== split.base_visible_seq) {
          throw new CoordinatorError(500, "graph state changed during a fenced topology operation");
        }
        this.ctx.storage.sql.exec(
          "UPDATE graph_state SET directory_epoch = ?, topology_op_id = NULL WHERE singleton = 1",
          split.split_epoch
        );
      } else if (state.directory_epoch !== split.split_epoch) {
        throw new CoordinatorError(500, "directory epoch changed unexpectedly during split recovery");
      }
      this.ctx.storage.sql.exec("UPDATE graph_splits SET phase = 'cutover' WHERE migration_id = ?", migrationId);
    });
    await this.pruneVersions();
    return void 0;
  }
  async postShard(prefix, path, body) {
    const stub = this.env.GRAPH_SHARDS.getByName(shardObjectName(this.readGraphIdentity(), prefix));
    const response = await stub.fetch(`https://shard.internal/${path}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body)
    });
    const text = await response.text();
    let result;
    try {
      result = JSON.parse(text);
    } catch {
      result = void 0;
    }
    if (!response.ok) throw new ParticipantResponseError(response.status, text.slice(0, 512));
    if (!isRecord(result)) throw new CoordinatorError(502, `shard ${prefix} returned invalid JSON`);
    return result;
  }
  readSplit(migrationId) {
    return this.ctx.storage.sql.exec(
      `SELECT migration_id, source_prefix, source_generation, left_prefix, right_prefix, base_visible_seq,
        old_directory_epoch, split_epoch, phase, force, created_at_ms FROM graph_splits WHERE migration_id = ?`,
      migrationId
    ).toArray()[0];
  }
  clearSplit(migrationId) {
    this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec("DELETE FROM graph_splits WHERE migration_id = ? AND phase = 'copying'", migrationId);
      this.ctx.storage.sql.exec("UPDATE graph_state SET topology_op_id = NULL WHERE singleton = 1 AND topology_op_id = ?", migrationId);
    });
  }
  async writeTransaction(request, graphId) {
    const raw = await readJsonBody(request, MAX_TRANSACTION_BYTES);
    if (!raw.ok) return jsonResponse({ error: raw.error.message, path: raw.error.path }, 400);
    const parsed2 = parseBatchBody(raw.value);
    if (!parsed2.ok) return jsonResponse({ error: parsed2.error.message, path: parsed2.error.path }, 400);
    const { batch, json } = parsed2.value;
    if (batch.facts.length > MAX_TRANSACTION_FACTS) {
      return jsonResponse({ error: `transaction cannot exceed ${MAX_TRANSACTION_FACTS} facts` }, 413);
    }
    if (new TextEncoder().encode(json).byteLength > MAX_TRANSACTION_BYTES) {
      return jsonResponse({ error: `canonical transaction exceeds ${MAX_TRANSACTION_BYTES} bytes` }, 413);
    }
    const payloadHash = await sha256Hex(json);
    if (this.activeWriterTxId !== void 0) {
      return this.writerBusy(this.activeWriterTxId);
    }
    const existingWriter = this.readGraphState().writer_tx_id;
    if (existingWriter !== null) {
      const outcome = await this.resumePersistedWriter(existingWriter);
      if (outcome instanceof Response) return outcome;
    }
    const pendingTopology = this.readGraphState().topology_op_id;
    if (pendingTopology !== null) {
      const outcome = await this.performSplit(pendingTopology);
      if (outcome instanceof Response) return outcome;
    }
    let prior = this.readTransaction(batch.txId);
    if (prior !== void 0 && (prior.phase === "complete" || prior.phase === "aborted") && prior.created_at_ms < Date.now() - TRANSACTION_IDEMPOTENCY_RETENTION_MS) {
      this.ctx.storage.sql.exec("DELETE FROM graph_transactions WHERE tx_id = ?", batch.txId);
      prior = void 0;
    }
    if (prior !== void 0) {
      if (prior.payload_hash !== payloadHash) {
        return jsonResponse({ error: "txId has already been used with a different fact batch" }, 409);
      }
      if (prior.phase === "complete") {
        return jsonResponse({ txId: batch.txId, commitSeq: prior.commit_seq, status: "committed" });
      }
      if (prior.phase === "aborted" || prior.phase === "cancelling") {
        return jsonResponse({ txId: batch.txId, status: "aborted" }, 409);
      }
      return jsonResponse({ error: "transaction recovery is in progress; retry with the same txId" }, 503, {
        "retry-after": "1"
      });
    }
    let routeState = this.readGraphState();
    if (routeState.topology_op_id !== null) return this.topologyBusy(routeState.topology_op_id);
    let directoryEpoch = routeState.directory_epoch;
    let participants = await this.groupBatch(batch, directoryEpoch);
    for (let splitCount = 0; splitCount <= MAX_SPLITS_PER_WRITE; splitCount += 1) {
      if (participants.length > MAX_TRANSACTION_PARTICIPANTS) {
        return jsonResponse({ error: `transaction cannot exceed ${MAX_TRANSACTION_PARTICIPANTS} participant leaves` }, 413);
      }
      const preflight = await this.preflightParticipants(batch, payloadHash, participants, directoryEpoch);
      const overloaded = preflight.find((result) => result.shouldSplit || !result.canAdmit);
      if (overloaded === void 0) break;
      if (!overloaded.shouldSplit || splitCount === MAX_SPLITS_PER_WRITE) {
        return jsonResponse({ error: "transaction cannot be admitted within the per-DO capacity budget", prefix: overloaded.address.prefix }, 413);
      }
      const splitResult = await this.splitPrefix(overloaded.address.prefix, false);
      if (splitResult instanceof Response) return splitResult;
      routeState = this.readGraphState();
      directoryEpoch = routeState.directory_epoch;
      participants = await this.groupBatch(batch, directoryEpoch);
    }
    const reservation = this.reserveTransaction(batch, payloadHash, json, participants, directoryEpoch);
    if (reservation.kind === "busy") return this.writerBusy(reservation.txId);
    if (reservation.kind === "topology-busy") return this.topologyBusy(this.readGraphState().topology_op_id ?? "split");
    if (reservation.kind === "route-changed") {
      return jsonResponse({ error: "directory changed while routing transaction; retry with the same txId", retryable: true }, 423, { "retry-after": "1" });
    }
    if (reservation.kind === "existing") {
      if (reservation.row.payload_hash !== payloadHash) {
        return jsonResponse({ error: "txId has already been used with a different fact batch" }, 409);
      }
      if (reservation.row.phase === "complete") {
        return jsonResponse({ txId: batch.txId, commitSeq: reservation.row.commit_seq, status: "committed" });
      }
      if (reservation.row.phase === "aborted") return jsonResponse({ txId: batch.txId, status: "aborted" }, 409);
      return jsonResponse({ error: "transaction recovery is in progress; retry with the same txId" }, 503);
    }
    this.activeWriterTxId = batch.txId;
    try {
      const outcome = await this.advanceTransaction(batch.txId);
      if (outcome === "aborted") {
        return jsonResponse({ txId: batch.txId, status: "aborted" }, 422);
      }
      const committed = this.readTransaction(batch.txId);
      if (committed === void 0) throw new CoordinatorError(500, "committed transaction record disappeared");
      return jsonResponse({ txId: batch.txId, commitSeq: committed.commit_seq, status: "committed" });
    } catch (error) {
      return jsonResponse({
        error: errorMessage(error),
        txId: batch.txId,
        retryable: true
      }, 503, { "retry-after": "1" });
    } finally {
      this.activeWriterTxId = void 0;
    }
  }
  async resumePersistedWriter(txId) {
    if (this.activeWriterTxId !== void 0) return this.writerBusy(this.activeWriterTxId);
    this.activeWriterTxId = txId;
    try {
      return await this.advanceTransaction(txId);
    } catch (error) {
      return jsonResponse({ error: errorMessage(error), txId, retryable: true }, 503, { "retry-after": "1" });
    } finally {
      this.activeWriterTxId = void 0;
    }
  }
  async advanceTransaction(txId) {
    let transaction = this.readTransaction(txId);
    if (transaction === void 0) throw new CoordinatorError(500, "transaction intent is missing");
    if (transaction.phase === "complete") return "committed";
    if (transaction.phase === "aborted") return "aborted";
    if (transaction.phase === "preparing") {
      if (transaction.batch_json === null) throw new CoordinatorError(500, "preparing transaction has no durable batch payload");
      const batch = parseFactBatch(JSON.parse(transaction.batch_json));
      if (!batch.ok) throw new CoordinatorError(500, `stored fact batch is corrupt: ${batch.error.message}`);
      const actualHash = await sha256Hex(canonicalBatchJson(batch.value));
      if (actualHash !== transaction.payload_hash) throw new CoordinatorError(500, "stored fact batch digest mismatch");
      const references = this.readParticipantReferences(transaction);
      const participants2 = await this.groupBatch(batch.value, transaction.directory_epoch, references);
      const prepareResults = await Promise.allSettled(participants2.map(
        (participant) => this.prepareParticipant(this.readGraphIdentity(), transaction, participant)
      ));
      const permanentFailure = prepareResults.find(
        (result) => result.status === "rejected" && result.reason instanceof ParticipantResponseError && result.reason.status >= 400 && result.reason.status < 500
      );
      if (permanentFailure !== void 0) {
        this.setTransactionPhase(txId, "cancelling");
        transaction = this.readTransaction(txId);
        if (transaction === void 0) throw new CoordinatorError(500, "transaction intent is missing during cancellation");
        return await this.finishCancellation(transaction);
      }
      const failedPrepare = prepareResults.find((result) => result.status === "rejected");
      if (failedPrepare !== void 0) {
        const reason = failedPrepare.status === "rejected" ? failedPrepare.reason : void 0;
        throw new CoordinatorError(503, `participant prepare is incomplete: ${errorMessage(reason)}`);
      }
      this.setTransactionPhase(txId, "committing");
      transaction = this.readTransaction(txId);
      if (transaction === void 0) throw new CoordinatorError(500, "transaction intent is missing after prepare");
    }
    if (transaction.phase === "cancelling") return await this.finishCancellation(transaction);
    if (transaction.phase !== "committing") throw new CoordinatorError(500, `unexpected transaction phase ${transaction.phase}`);
    const participants = this.readParticipantReferences(transaction);
    const commitResults = await Promise.allSettled(participants.map(
      (address) => this.commitParticipant(transaction, address)
    ));
    const failedCommit = commitResults.find((result) => result.status === "rejected");
    if (failedCommit !== void 0) {
      const reason = failedCommit.status === "rejected" ? failedCommit.reason : void 0;
      throw new CoordinatorError(503, `participant commit is incomplete: ${errorMessage(reason)}`);
    }
    this.publishCommit(transaction);
    await this.pruneVersions();
    return "committed";
  }
  async finishCancellation(transaction) {
    const participants = this.readParticipantReferences(transaction);
    const results = await Promise.allSettled(participants.map(
      (address) => this.cancelParticipant(transaction, address)
    ));
    const failure = results.find((result) => result.status === "rejected");
    if (failure !== void 0) {
      const reason = failure.status === "rejected" ? failure.reason : void 0;
      throw new CoordinatorError(503, `participant cancellation is incomplete: ${errorMessage(reason)}`);
    }
    this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec(
        "UPDATE graph_transactions SET phase = 'aborted', batch_json = NULL WHERE tx_id = ? AND phase = 'cancelling'",
        transaction.tx_id
      );
      this.ctx.storage.sql.exec(
        "UPDATE graph_state SET writer_tx_id = NULL WHERE singleton = 1 AND writer_tx_id = ?",
        transaction.tx_id
      );
    });
    return "aborted";
  }
  async preflightParticipants(batch, payloadHash, participants, directoryEpoch) {
    const state = this.readGraphState();
    const statementTimeMs = Math.max(Date.now(), state.next_statement_time_ms + 1);
    const results = await Promise.all(participants.map(async (participant) => {
      const result = await this.postShard(participant.address.prefix, "_preflight", {
        graphId: this.readGraphIdentity(),
        shardPrefix: participant.address.prefix,
        shardGeneration: participant.address.generation,
        directoryEpoch,
        txId: batch.txId,
        payloadHash,
        statementTimeMs,
        commitSeq: state.visible_seq + 1,
        facts: participant.facts
      });
      if (typeof result["shouldSplit"] !== "boolean" || typeof result["canAdmit"] !== "boolean") {
        throw new CoordinatorError(502, "shard returned an invalid capacity preflight result");
      }
      return { address: participant.address, shouldSplit: result["shouldSplit"], canAdmit: result["canAdmit"] };
    }));
    return results;
  }
  async splitPrefix(prefix, force) {
    const migrationId = this.reserveSplit(prefix, force);
    return this.performSplit(migrationId);
  }
  async groupBatch(batch, directoryEpoch, expectedAddresses) {
    const graphId = this.readGraphIdentity();
    const groups = /* @__PURE__ */ new Map();
    for (const [index, fact2] of batch.facts.entries()) {
      const virtualKey = await virtualKeyForEntity(graphId, fact2.entity);
      const address = expectedAddresses === void 0 ? (await resolveEntityLeaf(this.env, graphId, fact2.entity, directoryEpoch)).address : expectedAddresses.find((candidate) => matchesPrefix(virtualKey, candidate.prefix));
      if (address === void 0 || !matchesPrefix(virtualKey, address.prefix)) {
        throw new CoordinatorError(500, "transaction facts do not match their persisted shard routes");
      }
      const group = groups.get(address.prefix) ?? { address, facts: [] };
      if (group.address.generation !== address.generation) {
        throw new CoordinatorError(500, "one leaf was assigned inconsistent routing generations");
      }
      group.facts.push({ index, fact: factAsJson(fact2), virtualKey });
      groups.set(address.prefix, group);
    }
    return [...groups.values()].sort((left, right) => left.address.prefix < right.address.prefix ? -1 : 1);
  }
  reserveTransaction(batch, payloadHash, batchJson, participants, directoryEpoch) {
    return this.ctx.storage.transactionSync(() => {
      const state = this.readGraphState();
      if (state.topology_op_id !== null) return { kind: "topology-busy" };
      if (state.writer_tx_id !== null) return { kind: "busy", txId: state.writer_tx_id };
      if (state.directory_epoch !== directoryEpoch) return { kind: "route-changed" };
      const existing = this.readTransaction(batch.txId);
      if (existing !== void 0) return { kind: "existing", row: existing };
      const now = Date.now();
      this.ctx.storage.sql.exec(
        `DELETE FROM graph_transactions WHERE phase IN ('complete', 'aborted') AND created_at_ms < ?`,
        now - TRANSACTION_IDEMPOTENCY_RETENTION_MS
      );
      const outcomeCount = this.ctx.storage.sql.exec(
        "SELECT COUNT(*) AS count FROM graph_transactions WHERE phase IN ('complete', 'aborted')"
      ).toArray()[0]?.count ?? 0;
      if (outcomeCount >= MAX_RETAINED_TRANSACTION_OUTCOMES) {
        throw new CoordinatorError(429, `graph has reached its ${MAX_RETAINED_TRANSACTION_OUTCOMES}-outcome idempotency window`);
      }
      const metadataBytes = new TextEncoder().encode(batchJson).byteLength + participants.length * 96 + 1024;
      const coordinatorCapacity = accountStorage(this.ctx.storage.sql.databaseSize, {
        factLogBytes: 0,
        activeIndexBytes: 0,
        projectionBytes: 0,
        transactionStagingBytes: metadataBytes
      });
      if (!coordinatorCapacity.canAdmit) throw new CoordinatorError(413, "coordinator metadata would exceed the per-DO accounted capacity limit");
      if (participants.length === 0 || participants.length > MAX_TRANSACTION_PARTICIPANTS) {
        throw new CoordinatorError(413, `transaction cannot exceed ${MAX_TRANSACTION_PARTICIPANTS} participant leaves`);
      }
      const commitSeq = state.visible_seq + 1;
      const statementTimeMs = Math.max(Date.now(), state.next_statement_time_ms + 1);
      const nextStatementTimeMs = statementTimeMs + batch.facts.length;
      this.ctx.storage.sql.exec(
        `INSERT INTO graph_transactions
         (tx_id, payload_hash, batch_json, participants_json, directory_epoch, statement_time_ms, commit_seq, phase, created_at_ms)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'preparing', ?)`,
        batch.txId,
        payloadHash,
        batchJson,
        JSON.stringify(participants.map(({ address }) => address)),
        directoryEpoch,
        statementTimeMs,
        commitSeq,
        Date.now()
      );
      this.ctx.storage.sql.exec(
        "UPDATE graph_state SET writer_tx_id = ?, next_statement_time_ms = ? WHERE singleton = 1",
        batch.txId,
        nextStatementTimeMs
      );
      return { kind: "created" };
    });
  }
  publishCommit(transaction) {
    this.ctx.storage.transactionSync(() => {
      const current = this.readGraphState();
      if (current.writer_tx_id !== transaction.tx_id || current.visible_seq + 1 !== transaction.commit_seq) {
        throw new CoordinatorError(500, "graph commit watermark changed while a transaction was applying");
      }
      this.ctx.storage.sql.exec(
        "UPDATE graph_transactions SET phase = 'complete', batch_json = NULL WHERE tx_id = ? AND phase = 'committing'",
        transaction.tx_id
      );
      this.ctx.storage.sql.exec(
        "UPDATE graph_state SET visible_seq = ?, writer_tx_id = NULL WHERE singleton = 1",
        transaction.commit_seq
      );
    });
  }
  setTransactionPhase(txId, phase) {
    this.ctx.storage.transactionSync(() => {
      const tx = this.readTransaction(txId);
      if (tx === void 0) throw new CoordinatorError(500, "transaction intent disappeared");
      if (phase === "committing" && tx.phase !== "preparing") throw new CoordinatorError(500, "invalid commit decision transition");
      if (phase === "cancelling" && tx.phase !== "preparing" && tx.phase !== "cancelling") {
        throw new CoordinatorError(500, "cannot abort after a durable commit decision");
      }
      this.ctx.storage.sql.exec("UPDATE graph_transactions SET phase = ? WHERE tx_id = ?", phase, txId);
    });
  }
  async prepareParticipant(graphId, transaction, participant) {
    const body = {
      graphId,
      shardPrefix: participant.address.prefix,
      shardGeneration: participant.address.generation,
      directoryEpoch: transaction.directory_epoch,
      txId: transaction.tx_id,
      payloadHash: transaction.payload_hash,
      statementTimeMs: transaction.statement_time_ms,
      commitSeq: transaction.commit_seq,
      facts: participant.facts
    };
    await this.callParticipant(participant.address, "_prepare", body);
  }
  async commitParticipant(transaction, address) {
    await this.callParticipant(address, "_commit", {
      graphId: this.readGraphIdentity(),
      shardPrefix: address.prefix,
      shardGeneration: address.generation,
      directoryEpoch: transaction.directory_epoch,
      txId: transaction.tx_id,
      payloadHash: transaction.payload_hash,
      commitSeq: transaction.commit_seq
    });
  }
  async cancelParticipant(transaction, address) {
    await this.callParticipant(address, "_cancel", {
      graphId: this.readGraphIdentity(),
      shardPrefix: address.prefix,
      shardGeneration: address.generation,
      directoryEpoch: transaction.directory_epoch,
      txId: transaction.tx_id,
      payloadHash: transaction.payload_hash
    });
  }
  async callParticipant(address, path, body) {
    const stub = this.env.GRAPH_SHARDS.getByName(shardObjectName(this.readGraphIdentity(), address.prefix));
    const response = await stub.fetch(`https://shard.internal/${path}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const message = (await response.text()).slice(0, 512);
      throw new ParticipantResponseError(response.status, message);
    }
  }
  async runQuery(request, graphId) {
    const raw = await readJsonBody(request, 16384);
    if (!raw.ok) return jsonResponse({ error: raw.error.message }, 400);
    const body = requestObject(raw.value);
    if (!body.ok || typeof body.value["query"] !== "string") {
      return jsonResponse({ error: body.ok ? "query must be a string" : body.error.message }, 400);
    }
    const query = parseDatalogQuery(body.value["query"]);
    if (!query.ok) return jsonResponse({ error: query.error.message, offset: query.error.offset }, 400);
    const lease = this.beginReadLease();
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new DOMException("query time budget exceeded", "TimeoutError")), QUERY_TIMEOUT_MS);
    try {
      const source = new DistributedFactSource(this.env, graphId, lease.snapshotSeq, lease.directoryEpoch, lease.expiresAtMs);
      const rows = [];
      let responseBytes = 0;
      for await (const binding of evaluateDatalog(query.value, source, {
        maxResults: MAX_QUERY_RESULTS,
        signal: controller.signal
      })) {
        const row = Object.fromEntries(binding.entries());
        responseBytes += new TextEncoder().encode(JSON.stringify(row)).byteLength + 1;
        if (responseBytes > MAX_QUERY_RESPONSE_BYTES) throw new CoordinatorError(413, "query response byte budget exceeded");
        rows.push(row);
      }
      const serialized = JSON.stringify({
        rows,
        snapshotSeq: lease.snapshotSeq,
        metrics: source.metrics
      });
      if (new TextEncoder().encode(serialized).byteLength > MAX_QUERY_RESPONSE_BYTES) {
        throw new CoordinatorError(413, "query response byte budget exceeded");
      }
      return jsonStringResponse(serialized);
    } catch (error) {
      const status = error instanceof QueryResultLimitExceeded || error instanceof QueryScanBudgetExceeded ? 413 : error instanceof CoordinatorError ? error.status : controller.signal.aborted ? 408 : 502;
      return jsonResponse({ error: errorMessage(error), snapshotSeq: lease.snapshotSeq }, status);
    } finally {
      clearTimeout(timer);
      const minimum = this.releaseReadLease(lease.readId);
      await this.pruneVersions(minimum.minSnapshotSeq, minimum.minDirectoryEpoch);
    }
  }
  async readEntity(request, graphId) {
    const entity = parseUri(new URL(request.url).searchParams.get("uri"), "uri");
    if (!entity.ok) return jsonResponse({ error: entity.error.message }, 400);
    const lease = this.beginReadLease();
    try {
      const route = await resolveEntityLeaf(this.env, graphId, entity.value, lease.directoryEpoch);
      const stub = this.env.GRAPH_SHARDS.getByName(shardObjectName(graphId, route.address.prefix));
      const response = await stub.fetch("https://shard.internal/_entity", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          graphId,
          shardPrefix: route.address.prefix,
          shardGeneration: route.address.generation,
          directoryEpoch: lease.directoryEpoch,
          entity: entity.value,
          snapshotSeq: lease.snapshotSeq,
          leaseExpiresAtMs: lease.expiresAtMs
        })
      });
      if (response.status === 404) return jsonResponse({ entity: null, snapshotSeq: lease.snapshotSeq });
      if (!response.ok) return jsonResponse({ error: (await response.text()).slice(0, 512) }, 502);
      const projection = await response.json();
      return jsonResponse({ entity: projection, snapshotSeq: lease.snapshotSeq });
    } finally {
      const minimum = this.releaseReadLease(lease.readId);
      await this.pruneVersions(minimum.minSnapshotSeq, minimum.minDirectoryEpoch);
    }
  }
  beginReadLease() {
    return this.ctx.storage.transactionSync(() => {
      const now = Date.now();
      this.ctx.storage.sql.exec("DELETE FROM graph_read_leases WHERE expires_at_ms <= ?", now);
      const leaseCount = this.ctx.storage.sql.exec(
        "SELECT COUNT(*) AS count FROM graph_read_leases WHERE expires_at_ms > ?",
        now
      ).toArray()[0]?.count ?? 0;
      if (leaseCount >= MAX_READ_LEASES) throw new CoordinatorError(429, "graph has reached its concurrent read-lease limit");
      const graph = this.readGraphState();
      const readId = crypto.randomUUID();
      const expiresAtMs = now + READ_LEASE_TTL_MS;
      this.ctx.storage.sql.exec(
        "INSERT INTO graph_read_leases (read_id, snapshot_seq, directory_epoch, expires_at_ms) VALUES (?, ?, ?, ?)",
        readId,
        graph.visible_seq,
        graph.directory_epoch,
        expiresAtMs
      );
      return { readId, snapshotSeq: graph.visible_seq, directoryEpoch: graph.directory_epoch, expiresAtMs };
    });
  }
  releaseReadLease(readId) {
    return this.ctx.storage.transactionSync(() => {
      const now = Date.now();
      this.ctx.storage.sql.exec("DELETE FROM graph_read_leases WHERE read_id = ? OR expires_at_ms <= ?", readId, now);
      const lease = this.ctx.storage.sql.exec(
        "SELECT MIN(snapshot_seq) AS min_seq, MIN(directory_epoch) AS min_epoch FROM graph_read_leases WHERE expires_at_ms > ?",
        now
      ).toArray()[0];
      const state = this.readGraphState();
      return {
        minSnapshotSeq: lease?.min_seq ?? state.visible_seq,
        minDirectoryEpoch: lease?.min_epoch ?? state.directory_epoch
      };
    });
  }
  async pruneVersions(minSnapshotSeq, minDirectoryEpoch) {
    const minimum = minSnapshotSeq ?? this.minimumSnapshotSeq();
    const graphId = this.readGraphIdentity();
    const state = this.readGraphState();
    if (state.topology_op_id !== null) return;
    const minimumEpoch = minDirectoryEpoch ?? this.minimumDirectoryEpoch();
    const routes = await listShardLeaves(this.env, graphId, state.directory_epoch);
    await Promise.allSettled(routes.leaves.map(async (address) => {
      const stub = this.env.GRAPH_SHARDS.getByName(shardObjectName(graphId, address.prefix));
      const response = await stub.fetch("https://shard.internal/_prune", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          graphId,
          shardPrefix: address.prefix,
          shardGeneration: address.generation,
          directoryEpoch: state.directory_epoch,
          minSnapshotSeq: minimum
        })
      });
      if (!response.ok) console.warn("Poneglyph projection pruning deferred", address.prefix, response.status);
    }));
    await this.retireExpiredOwners(graphId, minimumEpoch);
  }
  async retireExpiredOwners(graphId, minimumEpoch) {
    const eligible = this.ctx.storage.sql.exec(
      `SELECT migration_id, source_prefix, source_generation, left_prefix, right_prefix, base_visible_seq,
        old_directory_epoch, split_epoch, phase, force, created_at_ms
       FROM graph_splits WHERE phase = 'cutover' AND split_epoch <= ?`,
      minimumEpoch
    ).toArray();
    for (const split of eligible) {
      try {
        await this.postShard(split.source_prefix, "_retire", {
          graphId,
          prefix: split.source_prefix,
          migrationId: split.migration_id
        });
        this.ctx.storage.sql.exec("DELETE FROM graph_splits WHERE migration_id = ? AND phase = 'cutover'", split.migration_id);
      } catch (error) {
        console.warn("Poneglyph old split owner retirement deferred", split.source_prefix, errorMessage(error));
      }
    }
  }
  minimumSnapshotSeq() {
    return this.ctx.storage.transactionSync(() => {
      const now = Date.now();
      this.ctx.storage.sql.exec("DELETE FROM graph_read_leases WHERE expires_at_ms <= ?", now);
      const lease = this.ctx.storage.sql.exec(
        "SELECT MIN(snapshot_seq) AS min_seq FROM graph_read_leases WHERE expires_at_ms > ?",
        now
      ).toArray()[0];
      return lease?.min_seq ?? this.readGraphState().visible_seq;
    });
  }
  minimumDirectoryEpoch() {
    return this.ctx.storage.transactionSync(() => {
      const now = Date.now();
      this.ctx.storage.sql.exec("DELETE FROM graph_read_leases WHERE expires_at_ms <= ?", now);
      const lease = this.ctx.storage.sql.exec(
        "SELECT MIN(directory_epoch) AS min_epoch FROM graph_read_leases WHERE expires_at_ms > ?",
        now
      ).toArray()[0];
      return lease?.min_epoch ?? this.readGraphState().directory_epoch;
    });
  }
  readGraphState() {
    const row = this.ctx.storage.sql.exec(
      "SELECT visible_seq, directory_epoch, writer_tx_id, topology_op_id, next_statement_time_ms FROM graph_state WHERE singleton = 1"
    ).toArray()[0];
    if (row === void 0) throw new CoordinatorError(500, "graph state row is missing");
    return row;
  }
  readTransaction(txId) {
    return this.ctx.storage.sql.exec(
      `SELECT tx_id, payload_hash, batch_json, participants_json, directory_epoch, statement_time_ms,
              commit_seq, phase, created_at_ms
       FROM graph_transactions WHERE tx_id = ?`,
      txId
    ).toArray()[0];
  }
  readParticipantReferences(transaction) {
    let input;
    try {
      input = JSON.parse(transaction.participants_json);
    } catch {
      throw new CoordinatorError(500, "stored participant list is corrupt");
    }
    if (!Array.isArray(input) || input.length === 0 || input.length > MAX_TRANSACTION_PARTICIPANTS) {
      throw new CoordinatorError(500, "stored participant list is invalid");
    }
    const references = [];
    const prefixes = /* @__PURE__ */ new Set();
    for (const item of input) {
      if (item === null || typeof item !== "object") throw new CoordinatorError(500, "stored participant address is invalid");
      const record = item;
      const prefix = parseVirtualPrefix(record["prefix"]);
      const generation = record["generation"];
      if (!prefix.ok || typeof generation !== "number" || !Number.isSafeInteger(generation) || generation < 0 || prefixes.has(prefix.value)) {
        throw new CoordinatorError(500, "stored participant address is invalid");
      }
      prefixes.add(prefix.value);
      references.push({ prefix: prefix.value, generation });
    }
    return references;
  }
  assertGraphIdentity(graphId) {
    this.ctx.storage.transactionSync(() => {
      const row = this.ctx.storage.sql.exec(
        "SELECT graph_id, routing_version FROM graph_identity WHERE singleton = 1"
      ).toArray()[0];
      if (row === void 0) {
        this.ctx.storage.sql.exec(
          "INSERT INTO graph_identity (singleton, graph_id, routing_version) VALUES (1, ?, ?)",
          graphId,
          ROUTING_VERSION
        );
        return;
      }
      if (row.graph_id !== graphId || row.routing_version !== ROUTING_VERSION) {
        throw new CoordinatorError(409, "coordinator Durable Object is bound to a different graph or routing version");
      }
    });
  }
  readGraphIdentity() {
    const row = this.ctx.storage.sql.exec(
      "SELECT graph_id FROM graph_identity WHERE singleton = 1"
    ).toArray()[0];
    const graphId = parseGraphId(row?.graph_id);
    if (!graphId.ok) throw new CoordinatorError(500, "coordinator graph identity is missing or corrupt");
    return graphId.value;
  }
  writerBusy(txId) {
    return jsonResponse({ error: "another graph transaction is being recovered or committed", txId, retryable: true }, 423, {
      "retry-after": "1"
    });
  }
  topologyBusy(operationId) {
    return jsonResponse({ error: "graph topology is being copied or cut over", operationId, retryable: true }, 423, {
      "retry-after": "1"
    });
  }
};
function parseGraphRoute(request) {
  const match = /^\/v1\/graphs\/([a-z0-9-]+)\/(transactions|query|entities)$/.exec(new URL(request.url).pathname);
  if (match === null) return void 0;
  const graphId = parseGraphId(match[1]);
  if (!graphId.ok) return void 0;
  const action = match[2];
  if (action !== "transactions" && action !== "query" && action !== "entities") return void 0;
  return { graphId: graphId.value, action };
}
var ParticipantResponseError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "ParticipantResponseError";
  }
  status;
};
var CoordinatorError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "CoordinatorError";
  }
  status;
};
function errorMessage(error) {
  return error instanceof Error ? error.message : String(error);
}

// ../../poneglyph/src/storage/shard.ts
import { DurableObject as DurableObject2 } from "cloudflare:workers";

// ../../poneglyph/src/storage/migration.ts
var MIGRATION_TABLES = {
  fact_log: ["fact_id", "tx_id", "tx_index", "commit_seq", "source", "entity", "entity_hash", "field", "value_json", "retraction", "stated_at"],
  active_facts: ["source", "entity", "entity_hash", "field", "value_json", "fact_id", "tx_id", "stated_at", "valid_from_seq", "valid_to_seq"],
  active_values: ["fact_id", "value_index", "source", "entity", "entity_hash", "field", "datalog_type", "datalog_value", "value_key", "value_json", "tx_id", "stated_at", "valid_from_seq", "valid_to_seq"],
  entity_versions: ["entity", "entity_hash", "fields_json", "last_tx_id", "valid_from_seq", "valid_to_seq"]
};
function parseMigrationTable(input) {
  return typeof input === "string" && Object.hasOwn(MIGRATION_TABLES, input) ? input : void 0;
}
function virtualKeyRange(prefix) {
  const parsed2 = parseVirtualPrefix(prefix);
  if (!parsed2.ok) throw new TypeError("invalid virtual prefix");
  const depth = BigInt(prefix.length);
  const low = prefix.length === 0 ? 0n : BigInt(`0b${prefix}`);
  const lower = low << 256n - depth;
  const upper = lower + ((1n << 256n - depth) - 1n);
  return [lower.toString(16).padStart(64, "0"), upper.toString(16).padStart(64, "0")];
}
function migrationRowBytes(rows) {
  return new TextEncoder().encode(JSON.stringify(rows)).byteLength;
}

// ../../poneglyph/src/storage/shard.ts
var ENTITY_TEXT_FIELDS = /* @__PURE__ */ new Set(["wiki:page:title", "schema:name"]);
var GraphShardDO = class extends DurableObject2 {
  constructor(ctx, env) {
    super(ctx, env);
    void ctx.blockConcurrencyWhile(async () => ensureShardSchema(ctx.storage));
  }
  async fetch(request) {
    const path = new URL(request.url).pathname;
    try {
      if (request.method === "POST" && path === "/_route") return await this.route(request);
      if (request.method === "POST" && path === "/_preflight") return await this.preflight(request);
      if (request.method === "POST" && path === "/_begin-split") return await this.beginSplit(request);
      if (request.method === "POST" && path === "/_init-child") return await this.initChild(request);
      if (request.method === "POST" && path === "/_export") return await this.exportPage(request);
      if (request.method === "POST" && path === "/_import") return await this.importPage(request);
      if (request.method === "POST" && path === "/_finish-child") return await this.finishChild(request);
      if (request.method === "POST" && path === "/_cutover") return await this.cutover(request);
      if (request.method === "POST" && path === "/_count") return await this.countRange(request);
      if (request.method === "POST" && path === "/_abort-split") return await this.abortSplit(request);
      if (request.method === "POST" && path === "/_retire") return await this.retire(request);
      if (request.method === "POST" && path === "/_prepare") return await this.prepare(request);
      if (request.method === "POST" && path === "/_commit") return await this.commit(request);
      if (request.method === "POST" && path === "/_cancel") return await this.cancel(request);
      if (request.method === "POST" && path === "/_scan") return await this.scan(request);
      if (request.method === "POST" && path === "/_entity") return await this.getEntity(request);
      if (request.method === "POST" && path === "/_prune") return await this.prune(request);
      return jsonResponse({ error: "not found" }, 404);
    } catch (error) {
      const status = error instanceof ShardProtocolError ? error.status : 500;
      return jsonResponse({ error: errorMessage2(error) }, status);
    }
  }
  async prepare(request) {
    const input = await readJsonBody(request, MAX_TRANSACTION_BYTES);
    if (!input.ok) return jsonResponse({ error: input.error.message, path: input.error.path }, 400);
    const batch = parseParticipantBatch(input.value);
    if (!batch.ok) return jsonResponse({ error: batch.error.message, path: batch.error.path }, 400);
    for (const indexedFact of batch.value.facts) {
      const actualKey = await virtualKeyForEntity(batch.value.graphId, indexedFact.fact.entity);
      if (actualKey !== indexedFact.virtualKey || !matchesPrefix(actualKey, batch.value.shardPrefix)) {
        return jsonResponse({ error: "participant received a fact outside its virtual-shard range" }, 409);
      }
    }
    const payloadJson = JSON.stringify(batch.value);
    const outcome = this.ctx.storage.transactionSync(() => {
      this.assertWritableIdentity(batch.value.graphId, batch.value.shardPrefix, batch.value.shardGeneration);
      this.ctx.storage.sql.exec(
        `DELETE FROM shard_transactions WHERE status IN ('committed', 'cancelled') AND created_at_ms < ?`,
        Date.now() - TRANSACTION_IDEMPOTENCY_RETENTION_MS
      );
      this.validatePreparedBatch(batch.value);
      this.assertCapacity(batch.value.facts.map((indexed) => indexed.fact));
      const existing = this.ctx.storage.sql.exec("SELECT payload_hash, status FROM shard_transactions WHERE tx_id = ?", batch.value.txId).toArray()[0];
      if (existing !== void 0) {
        if (existing.payload_hash !== batch.value.payloadHash) {
          throw new ShardProtocolError(409, "transaction ID was already used with a different participant payload");
        }
        if (existing.status === "cancelled") {
          throw new ShardProtocolError(409, "transaction was cancelled");
        }
        return existing.status;
      }
      this.ctx.storage.sql.exec(
        `INSERT INTO shard_transactions (tx_id, payload_hash, payload_json, status, created_at_ms)
         VALUES (?, ?, ?, 'prepared', ?)`,
        batch.value.txId,
        batch.value.payloadHash,
        payloadJson,
        Date.now()
      );
      return "prepared";
    });
    return jsonResponse({ status: outcome });
  }
  async commit(request) {
    const control = await this.readControl(request);
    if (!control.ok) return control.response;
    const { graphId, shardPrefix, shardGeneration, txId, payloadHash, commitSeq } = control.value;
    const result = this.ctx.storage.transactionSync(() => {
      this.assertWritableIdentity(graphId, shardPrefix, shardGeneration);
      const row = this.ctx.storage.sql.exec("SELECT payload_hash, payload_json, status FROM shard_transactions WHERE tx_id = ?", txId).toArray()[0];
      if (row === void 0) throw new ShardProtocolError(409, "transaction was not prepared on this shard");
      if (row.payload_hash !== payloadHash) throw new ShardProtocolError(409, "participant payload hash mismatch");
      if (row.status === "committed") return "committed";
      if (row.status !== "prepared" || row.payload_json === null) {
        throw new ShardProtocolError(409, "transaction is not in the prepared state");
      }
      const parsed2 = parseParticipantBatch(JSON.parse(row.payload_json));
      if (!parsed2.ok) throw new ShardProtocolError(500, `stored prepare record is invalid: ${parsed2.error.message}`);
      if (parsed2.value.commitSeq !== commitSeq) throw new ShardProtocolError(409, "commit sequence mismatch");
      this.applyParticipantBatch(parsed2.value);
      this.ctx.storage.sql.exec(
        `UPDATE shard_transactions SET payload_json = NULL, status = 'committed' WHERE tx_id = ?`,
        txId
      );
      return "committed";
    });
    return jsonResponse({ status: result, txId, commitSeq });
  }
  async cancel(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value)) {
      return jsonResponse({ error: input.ok ? "expected a cancel object" : input.error.message }, 400);
    }
    const graphId = parseGraphId(input.value["graphId"]);
    const txId = parseTransactionId(input.value["txId"]);
    const payloadHash = input.value["payloadHash"];
    const shardPrefix = parseVirtualPrefix(input.value["shardPrefix"]);
    const shardGeneration = readNonNegativeInteger2(input.value["shardGeneration"]);
    if (!graphId.ok || !txId.ok || !shardPrefix.ok || !shardGeneration.ok || typeof payloadHash !== "string" || !/^[a-f0-9]{64}$/.test(payloadHash)) {
      return jsonResponse({ error: "invalid cancel request" }, 400);
    }
    this.ctx.storage.transactionSync(() => {
      this.assertWritableIdentity(graphId.value, shardPrefix.value, shardGeneration.value);
      const row = this.ctx.storage.sql.exec("SELECT payload_hash, status FROM shard_transactions WHERE tx_id = ?", txId.value).toArray()[0];
      if (row !== void 0 && row.payload_hash !== payloadHash) {
        throw new ShardProtocolError(409, "participant payload hash mismatch");
      }
      if (row?.status === "committed") throw new ShardProtocolError(409, "committed transaction cannot be cancelled");
      if (row?.status === "cancelled") return;
      if (row === void 0) {
        this.ctx.storage.sql.exec(
          `INSERT INTO shard_transactions (tx_id, payload_hash, payload_json, status, created_at_ms)
           VALUES (?, ?, NULL, 'cancelled', ?)`,
          txId.value,
          payloadHash,
          Date.now()
        );
      } else {
        this.ctx.storage.sql.exec(
          `UPDATE shard_transactions SET payload_json = NULL, status = 'cancelled' WHERE tx_id = ?`,
          txId.value
        );
      }
    });
    return jsonResponse({ status: "cancelled", txId: txId.value });
  }
  async scan(request) {
    const input = await readJsonBody(request, 16384);
    if (!input.ok) return jsonResponse({ error: input.error.message }, 400);
    const scan = parseScanRequest(input.value);
    if (!scan.ok) return jsonResponse({ error: scan.error.message, path: scan.error.path }, 400);
    this.assertReadableIdentity(scan.value.graphId, scan.value.shardPrefix, scan.value.shardGeneration, scan.value.directoryEpoch);
    if (scan.value.leaseExpiresAtMs <= Date.now()) {
      return jsonResponse({ error: "read snapshot lease expired" }, 410);
    }
    if (scan.value.entity?.type === "string") {
      const parsedEntity = parseUri(scan.value.entity.value);
      if (!parsedEntity.ok || !matchesPrefix(await virtualKeyForEntity(scan.value.graphId, parsedEntity.value), scan.value.shardPrefix)) {
        return jsonResponse({ error: "entity is outside the requested virtual-shard range" }, 409);
      }
    }
    const prepared = this.prepareScan(scan.value);
    const encoder3 = new TextEncoder();
    let cursor;
    let closed = false;
    const body = new ReadableStream({
      pull: (controller) => {
        if (closed) return;
        if (scan.value.leaseExpiresAtMs <= Date.now()) {
          closed = true;
          controller.error(new ShardProtocolError(410, "read snapshot lease expired"));
          return;
        }
        const cursorClause = cursor === void 0 ? "" : " AND (entity > ? OR (entity = ? AND fact_id > ?) OR (entity = ? AND fact_id = ? AND value_index > ?))";
        const cursorArgs = cursor === void 0 ? [] : [cursor.entity, cursor.entity, cursor.factId, cursor.entity, cursor.factId, cursor.valueIndex];
        const rows = this.ctx.storage.sql.exec(
          `${prepared.sql}${cursorClause} ORDER BY entity, fact_id, value_index LIMIT ?`,
          ...prepared.args,
          ...cursorArgs,
          SHARD_SCAN_PAGE_SIZE
        ).toArray();
        if (rows.length === 0) {
          closed = true;
          controller.close();
          return;
        }
        const lastRow = rows.at(-1);
        if (lastRow !== void 0) cursor = { entity: lastRow.entity, factId: lastRow.fact_id, valueIndex: lastRow.value_index };
        const chunk = rows.map((row) => {
          const value = parseDatalogValue({ type: row.datalog_type, value: row.datalog_value });
          if (!value.ok) throw new ShardProtocolError(500, "stored Datalog tuple is corrupt");
          return JSON.stringify({ entity: row.entity, value: value.value }) + "\n";
        }).join("");
        controller.enqueue(encoder3.encode(chunk));
      },
      cancel: () => {
        closed = true;
      }
    });
    return new Response(body, {
      headers: {
        "content-type": "application/x-ndjson; charset=utf-8",
        "cache-control": "no-store"
      }
    });
  }
  async getEntity(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value)) {
      return jsonResponse({ error: input.ok ? "expected an entity read object" : input.error.message }, 400);
    }
    const graphId = parseGraphId(input.value["graphId"]);
    const entity = parseUri(input.value["entity"], "entity");
    const shardPrefix = parseVirtualPrefix(input.value["shardPrefix"]);
    const shardGeneration = readNonNegativeInteger2(input.value["shardGeneration"]);
    const directoryEpoch = readNonNegativeInteger2(input.value["directoryEpoch"]);
    const snapshotSeq = readNonNegativeInteger2(input.value["snapshotSeq"]);
    const leaseExpiresAtMs = readNonNegativeInteger2(input.value["leaseExpiresAtMs"]);
    if (!graphId.ok || !entity.ok || !shardPrefix.ok || !shardGeneration.ok || !directoryEpoch.ok || !snapshotSeq.ok || !leaseExpiresAtMs.ok) {
      return jsonResponse({ error: "invalid entity read request" }, 400);
    }
    if (!matchesPrefix(await virtualKeyForEntity(graphId.value, entity.value), shardPrefix.value)) {
      return jsonResponse({ error: "entity is not owned by this shard" }, 409);
    }
    this.assertReadableIdentity(graphId.value, shardPrefix.value, shardGeneration.value, directoryEpoch.value);
    if (leaseExpiresAtMs.value <= Date.now()) return jsonResponse({ error: "read snapshot lease expired" }, 410);
    const row = this.ctx.storage.sql.exec(
      `SELECT fields_json, last_tx_id FROM entity_versions
       WHERE entity = ? AND valid_from_seq <= ? AND (valid_to_seq IS NULL OR valid_to_seq > ?)
       ORDER BY valid_from_seq DESC LIMIT 1`,
      entity.value,
      snapshotSeq.value,
      snapshotSeq.value
    ).toArray()[0];
    if (row === void 0) return jsonResponse({ error: "entity not found" }, 404);
    return jsonResponse({
      uri: entity.value,
      namespace: new URL(entity.value).protocol.slice(0, -1),
      kind: new URL(entity.value).pathname.split(":")[0] ?? "",
      fields: JSON.parse(row.fields_json),
      lastProcessedTxId: row.last_tx_id,
      snapshotSeq: snapshotSeq.value
    });
  }
  async prune(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value)) {
      return jsonResponse({ error: input.ok ? "expected a prune request object" : input.error.message }, 400);
    }
    const graphId = parseGraphId(input.value["graphId"]);
    const shardPrefix = parseVirtualPrefix(input.value["shardPrefix"]);
    const shardGeneration = readNonNegativeInteger2(input.value["shardGeneration"]);
    const minSnapshotSeq = readNonNegativeInteger2(input.value["minSnapshotSeq"]);
    if (!graphId.ok || !shardPrefix.ok || !shardGeneration.ok || !minSnapshotSeq.ok) return jsonResponse({ error: "invalid prune request" }, 400);
    this.ctx.storage.transactionSync(() => {
      this.assertWritableIdentity(graphId.value, shardPrefix.value, shardGeneration.value);
      this.ctx.storage.sql.exec(
        "DELETE FROM active_values WHERE valid_to_seq IS NOT NULL AND valid_to_seq <= ?",
        minSnapshotSeq.value
      );
      this.ctx.storage.sql.exec(
        "DELETE FROM active_facts WHERE valid_to_seq IS NOT NULL AND valid_to_seq <= ?",
        minSnapshotSeq.value
      );
      this.ctx.storage.sql.exec(
        "DELETE FROM entity_versions WHERE valid_to_seq IS NOT NULL AND valid_to_seq <= ?",
        minSnapshotSeq.value
      );
    });
    return jsonResponse({ status: "pruned", minSnapshotSeq: minSnapshotSeq.value });
  }
  prepareScan(scan) {
    const clauses = [
      "field = ?",
      "valid_from_seq <= ?",
      "(valid_to_seq IS NULL OR valid_to_seq > ?)"
    ];
    const args = [scan.field, scan.snapshotSeq, scan.snapshotSeq];
    if (scan.entity !== void 0) {
      if (scan.entity.type !== "string") return { sql: "SELECT entity, fact_id, value_index, datalog_type, datalog_value FROM active_values WHERE 0", args: [] };
      const entity = parseUri(scan.entity.value);
      if (!entity.ok) {
        return { sql: "SELECT entity, fact_id, value_index, datalog_type, datalog_value FROM active_values WHERE 0", args: [] };
      }
      clauses.push("entity = ?");
      args.push(entity.value);
    }
    if (scan.value !== void 0) {
      const factValue = datalogValueToFactValue(scan.field, scan.value);
      if (factValue === void 0) {
        return { sql: "SELECT entity, fact_id, value_index, datalog_type, datalog_value FROM active_values WHERE 0", args: [] };
      }
      clauses.push("value_key = ?");
      args.push(JSON.stringify(factValue));
    }
    return {
      sql: `SELECT entity, fact_id, value_index, datalog_type, datalog_value FROM active_values WHERE ${clauses.join(" AND ")}`,
      args
    };
  }
  validatePreparedBatch(batch) {
    const factsByEntity = /* @__PURE__ */ new Map();
    for (const indexed of batch.facts) {
      const facts = factsByEntity.get(indexed.fact.entity) ?? [];
      facts.push(indexed);
      factsByEntity.set(indexed.fact.entity, facts);
    }
    for (const [entity, facts] of factsByEntity) {
      const activeRows = this.ctx.storage.sql.exec(
        `SELECT source, field, value_json FROM active_facts
         WHERE entity = ? AND valid_to_seq IS NULL`,
        entity
      ).toArray();
      const activeKeys = new Set(activeRows.map((row) => JSON.stringify([row.source, row.field, row.value_json])));
      const currentProjection = this.ctx.storage.sql.exec(
        `SELECT fields_json, last_tx_id FROM entity_versions
         WHERE entity = ? AND valid_to_seq IS NULL LIMIT 1`,
        entity
      ).toArray()[0];
      const projectedFields = this.readProjectionFields(currentProjection?.fields_json);
      for (const indexed of facts.sort((left, right) => left.index - right.index)) {
        const fact2 = indexed.fact;
        const valueJson = JSON.stringify(fact2.value);
        const activeKey = JSON.stringify([fact2.source, fact2.field, valueJson]);
        if (fact2.retraction) {
          if (!activeKeys.delete(activeKey)) {
            throw new ShardProtocolError(422, `cannot retract an inactive fact tuple for entity ${entity}`);
          }
          const projected = projectedFields.get(fact2.field);
          if (projected !== void 0 && JSON.stringify(projected) === valueJson) projectedFields.delete(fact2.field);
        } else {
          activeKeys.add(activeKey);
          projectedFields.set(fact2.field, fact2.value);
        }
        if (activeKeys.size > MAX_ACTIVE_FACTS_PER_ENTITY) {
          throw new ShardProtocolError(413, `entity ${entity} exceeds ${MAX_ACTIVE_FACTS_PER_ENTITY} active fact tuples`);
        }
        if (projectedFields.size > MAX_ENTITY_FIELDS) {
          throw new ShardProtocolError(413, `entity ${entity} exceeds ${MAX_ENTITY_FIELDS} projected fields`);
        }
      }
    }
  }
  readProjectionFields(fieldsJson) {
    const fields = /* @__PURE__ */ new Map();
    if (fieldsJson === void 0) return fields;
    const raw = JSON.parse(fieldsJson);
    if (!isRecord(raw)) throw new ShardProtocolError(500, "stored entity projection is corrupt");
    for (const [field, inputValue] of Object.entries(raw)) {
      const value = parseFactValue(inputValue, `entity.fields.${field}`);
      if (!value.ok) throw new ShardProtocolError(500, "stored entity projection is corrupt");
      fields.set(field, value.value);
    }
    return fields;
  }
  applyParticipantBatch(batch) {
    const affectedEntities = /* @__PURE__ */ new Set();
    const facts = [...batch.facts].sort((left, right) => left.index - right.index);
    for (const indexed of facts) {
      const fact2 = indexed.fact;
      affectedEntities.add(fact2.entity);
      const valueJson = JSON.stringify(fact2.value);
      const current = this.ctx.storage.sql.exec(
        `SELECT source, entity, field, value_json, fact_id FROM active_facts
         WHERE source = ? AND entity = ? AND field = ? AND value_json = ? AND valid_to_seq IS NULL
         LIMIT 1`,
        fact2.source,
        fact2.entity,
        fact2.field,
        valueJson
      ).toArray()[0];
      const factId = `poneglyph:fact:${encodeURIComponent(batch.graphId)}:${encodeURIComponent(batch.txId)}:${batch.commitSeq}:${indexed.index}`;
      const parsedFactId = parseFactId(factId);
      if (!parsedFactId.ok) throw new ShardProtocolError(500, "could not construct a fact ID");
      const statedAt = new Date(batch.statementTimeMs + indexed.index).toISOString();
      this.ctx.storage.sql.exec(
        `INSERT INTO fact_log (fact_id, tx_id, tx_index, commit_seq, source, entity, entity_hash, field, value_json, retraction, stated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        parsedFactId.value,
        batch.txId,
        indexed.index,
        batch.commitSeq,
        fact2.source,
        fact2.entity,
        indexed.virtualKey,
        fact2.field,
        valueJson,
        fact2.retraction ? 1 : 0,
        statedAt
      );
      if (current !== void 0) this.closeActiveFact(current.fact_id, batch.commitSeq);
      if (!fact2.retraction) this.insertActiveFact(batch, indexed, parsedFactId.value, statedAt, valueJson);
    }
    for (const entity of affectedEntities) this.updateEntityProjection(batch, facts, entity);
  }
  closeActiveFact(factId, commitSeq) {
    this.ctx.storage.sql.exec(
      "UPDATE active_facts SET valid_to_seq = ? WHERE fact_id = ? AND valid_to_seq IS NULL",
      commitSeq,
      factId
    );
    this.ctx.storage.sql.exec(
      "UPDATE active_values SET valid_to_seq = ? WHERE fact_id = ? AND valid_to_seq IS NULL",
      commitSeq,
      factId
    );
  }
  insertActiveFact(batch, indexed, factId, statedAt, valueJson) {
    const fact2 = indexed.fact;
    this.ctx.storage.sql.exec(
      `INSERT INTO active_facts
       (source, entity, entity_hash, field, value_json, fact_id, tx_id, stated_at, valid_from_seq, valid_to_seq)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)`,
      fact2.source,
      fact2.entity,
      indexed.virtualKey,
      fact2.field,
      valueJson,
      factId,
      batch.txId,
      statedAt,
      batch.commitSeq
    );
    const values = fact2.value.type === "list" ? fact2.value.value : [fact2.value];
    for (const [valueIndex, item] of values.entries()) {
      const datalog = factScalarToDatalogValue(item);
      const itemJson = JSON.stringify(item);
      this.ctx.storage.sql.exec(
        `INSERT INTO active_values
         (fact_id, value_index, source, entity, entity_hash, field, datalog_type, datalog_value, value_key, value_json,
          tx_id, stated_at, valid_from_seq, valid_to_seq)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)`,
        factId,
        valueIndex,
        fact2.source,
        fact2.entity,
        indexed.virtualKey,
        fact2.field,
        datalog.type,
        datalog.value,
        itemJson,
        itemJson,
        batch.txId,
        statedAt,
        batch.commitSeq
      );
    }
  }
  updateEntityProjection(batch, facts, entity) {
    const existing = this.ctx.storage.sql.exec(
      `SELECT fields_json, last_tx_id FROM entity_versions WHERE entity = ? AND valid_to_seq IS NULL LIMIT 1`,
      entity
    ).toArray()[0];
    const fields = /* @__PURE__ */ new Map();
    if (existing !== void 0) {
      const raw = JSON.parse(existing.fields_json);
      if (!isRecord(raw)) throw new ShardProtocolError(500, "stored entity projection is corrupt");
      for (const [field, inputValue] of Object.entries(raw)) {
        const value = parseFactValue(inputValue, `entity.fields.${field}`);
        if (!value.ok) throw new ShardProtocolError(500, "stored entity projection is corrupt");
        fields.set(field, value.value);
      }
    }
    for (const indexed of facts) {
      const fact2 = indexed.fact;
      if (fact2.entity !== entity) continue;
      if (fact2.retraction) {
        const current = fields.get(fact2.field);
        if (current !== void 0 && JSON.stringify(current) === JSON.stringify(fact2.value)) fields.delete(fact2.field);
      } else {
        fields.set(fact2.field, fact2.value);
      }
    }
    if (existing !== void 0) {
      this.ctx.storage.sql.exec(
        "UPDATE entity_versions SET valid_to_seq = ? WHERE entity = ? AND valid_to_seq IS NULL",
        batch.commitSeq,
        entity
      );
    }
    if (fields.size === 0) return;
    const fieldsJson = JSON.stringify(Object.fromEntries(
      [...fields.entries()].sort(([left], [right]) => compareUnicodeScalars(left, right))
    ));
    this.ctx.storage.sql.exec(
      `INSERT INTO entity_versions (entity, entity_hash, fields_json, last_tx_id, valid_from_seq, valid_to_seq)
       VALUES (?, ?, ?, ?, ?, NULL)`,
      entity,
      facts.find((indexed) => indexed.fact.entity === entity)?.virtualKey ?? "",
      fieldsJson,
      batch.txId,
      batch.commitSeq
    );
  }
  async readControl(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value)) {
      return { ok: false, response: jsonResponse({ error: input.ok ? "expected a commit object" : input.error.message }, 400) };
    }
    const graphId = parseGraphId(input.value["graphId"]);
    const shardPrefix = parseVirtualPrefix(input.value["shardPrefix"]);
    const shardGeneration = readNonNegativeInteger2(input.value["shardGeneration"]);
    const directoryEpoch = readNonNegativeInteger2(input.value["directoryEpoch"]);
    const txId = parseTransactionId(input.value["txId"]);
    const payloadHash = input.value["payloadHash"];
    const commitSeq = readPositiveInteger(input.value["commitSeq"]);
    if (!graphId.ok || !shardPrefix.ok || !shardGeneration.ok || !directoryEpoch.ok || !txId.ok || !commitSeq.ok || typeof payloadHash !== "string" || !/^[a-f0-9]{64}$/.test(payloadHash)) {
      return { ok: false, response: jsonResponse({ error: "invalid commit request" }, 400) };
    }
    return {
      ok: true,
      value: {
        graphId: graphId.value,
        shardPrefix: shardPrefix.value,
        shardGeneration: shardGeneration.value,
        directoryEpoch: directoryEpoch.value,
        txId: txId.value,
        payloadHash,
        commitSeq: commitSeq.value
      }
    };
  }
  async route(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid directory route request" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const prefix = parseVirtualPrefix(input.value["prefix"]);
    const epoch = readNonNegativeInteger2(input.value["directoryEpoch"]);
    if (!graphId.ok || !prefix.ok || !epoch.ok) return jsonResponse({ error: "invalid directory route identity" }, 400);
    const identity = this.ctx.storage.transactionSync(() => this.assertIdentity(graphId.value, prefix.value));
    if (identity.role === "leaf") return jsonResponse({ kind: "leaf", prefix: identity.prefix, generation: identity.generation });
    if (identity.split_epoch === null || identity.child_zero_prefix === null || identity.child_one_prefix === null) {
      throw new ShardProtocolError(500, "router node has incomplete child metadata");
    }
    return jsonResponse({
      kind: "router",
      prefix: identity.prefix,
      generation: identity.generation,
      splitEpoch: identity.split_epoch,
      children: [identity.child_zero_prefix, identity.child_one_prefix],
      retired: identity.migration_state === "retired"
    });
  }
  async beginSplit(request) {
    const input = await readJsonBody(request, 8192);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid split request" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const prefix = parseVirtualPrefix(input.value["prefix"]);
    const generation = readNonNegativeInteger2(input.value["generation"]);
    const migrationId = input.value["migrationId"];
    const splitEpoch = readPositiveInteger(input.value["splitEpoch"]);
    const left = parseVirtualPrefix(input.value["leftPrefix"]);
    const right = parseVirtualPrefix(input.value["rightPrefix"]);
    const force = input.value["force"] === true;
    if (!graphId.ok || !prefix.ok || !generation.ok || typeof migrationId !== "string" || !splitEpoch.ok || !left.ok || !right.ok || left.value !== `${prefix.value}0` || right.value !== `${prefix.value}1`) {
      return jsonResponse({ error: "invalid split identity or children" }, 400);
    }
    const outcome = this.ctx.storage.transactionSync(() => {
      const identity = this.assertIdentity(graphId.value, prefix.value);
      if (identity.role === "router" && identity.migration_id === migrationId) {
        return { status: "already-cut-over", leftReservedBytes: 0, rightReservedBytes: 0 };
      }
      if (identity.role !== "leaf" || identity.generation !== generation.value) {
        throw new ShardProtocolError(409, "split source route is stale");
      }
      if (identity.migration_id !== null && identity.migration_id !== migrationId) {
        throw new ShardProtocolError(423, "another migration already owns this source leaf");
      }
      const leftUsage = this.estimateRange(left.value);
      const rightUsage = this.estimateRange(right.value);
      const emptyFootprint = { factLogBytes: 0, activeIndexBytes: 0, projectionBytes: 0, transactionStagingBytes: 0 };
      if (!accountStorage(0, emptyFootprint, leftUsage.reservedBytes).canAdmit || !accountStorage(0, emptyFootprint, rightUsage.reservedBytes).canAdmit) {
        return { status: "capacity-limit", leftReservedBytes: leftUsage.reservedBytes, rightReservedBytes: rightUsage.reservedBytes };
      }
      const distinctKeys = this.ctx.storage.sql.exec(
        "SELECT COUNT(DISTINCT entity_hash) AS count FROM fact_log"
      ).toArray()[0]?.count ?? 0;
      const sourceRowCount = leftUsage.rowCount + rightUsage.rowCount;
      const reachedVirtualKeyLimit = prefix.value.length >= 256;
      const hasNoMovableRows = sourceRowCount === 0;
      const hasOnlyOneEntityKey = distinctKeys <= 1 && sourceRowCount > 0;
      if (!force && (reachedVirtualKeyLimit || hasNoMovableRows || hasOnlyOneEntityKey)) {
        return { status: "no-progress", leftReservedBytes: leftUsage.reservedBytes, rightReservedBytes: rightUsage.reservedBytes };
      }
      this.ctx.storage.sql.exec(
        `UPDATE shard_identity SET migration_id = ?, migration_state = 'copying', split_epoch = ?,
          child_zero_prefix = ?, child_one_prefix = ? WHERE singleton = 1`,
        migrationId,
        splitEpoch.value,
        left.value,
        right.value
      );
      return { status: "copying", leftReservedBytes: leftUsage.reservedBytes, rightReservedBytes: rightUsage.reservedBytes };
    });
    return jsonResponse(outcome);
  }
  async initChild(request) {
    const input = await readJsonBody(request, 8192);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid child initialization request" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const prefix = parseVirtualPrefix(input.value["prefix"]);
    const migrationId = input.value["migrationId"];
    const reservedBytes = readNonNegativeInteger2(input.value["reservedBytes"]);
    if (!graphId.ok || !prefix.ok || typeof migrationId !== "string" || !reservedBytes.ok) return jsonResponse({ error: "invalid child initialization identity" }, 400);
    this.ctx.storage.transactionSync(() => {
      const identity = this.assertIdentity(graphId.value, prefix.value);
      if (identity.role !== "leaf" || identity.migration_id !== null && identity.migration_id !== migrationId) {
        throw new ShardProtocolError(409, "child Durable Object is already assigned to another route or migration");
      }
      const pending = { factLogBytes: 0, activeIndexBytes: 0, projectionBytes: 0, transactionStagingBytes: 0 };
      const importedPageCount = this.ctx.storage.sql.exec(
        "SELECT COUNT(*) AS count FROM migration_import_pages WHERE migration_id = ?",
        migrationId
      ).toArray()[0]?.count ?? 0;
      const currentReservation = this.ctx.storage.sql.exec(
        "SELECT migration_reserved_bytes FROM shard_accounting WHERE singleton = 1"
      ).toArray()[0]?.migration_reserved_bytes ?? 0;
      const nextReservation = importedPageCount > 0 ? currentReservation : reservedBytes.value;
      const capacity = accountStorage(this.ctx.storage.sql.databaseSize, pending, nextReservation);
      if (!capacity.canAdmit) throw new ShardProtocolError(413, "child migration reservation exceeds its per-DO capacity budget");
      this.ctx.storage.sql.exec(
        "UPDATE shard_identity SET migration_id = ?, migration_state = 'copying' WHERE singleton = 1",
        migrationId
      );
      this.ctx.storage.sql.exec(
        "UPDATE shard_accounting SET migration_reserved_bytes = ? WHERE singleton = 1",
        nextReservation
      );
    });
    return jsonResponse({ status: "ready-to-import" });
  }
  async exportPage(request) {
    const input = await readJsonBody(request, 8192);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid export page request" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const sourcePrefix = parseVirtualPrefix(input.value["sourcePrefix"]);
    const targetPrefix = parseVirtualPrefix(input.value["targetPrefix"]);
    const migrationId = input.value["migrationId"];
    const table = parseMigrationTable(input.value["table"]);
    const pageNumber = readNonNegativeInteger2(input.value["pageNumber"]);
    const afterRowId = readNonNegativeInteger2(input.value["afterRowId"]);
    if (!graphId.ok || !sourcePrefix.ok || !targetPrefix.ok || typeof migrationId !== "string" || table === void 0 || !pageNumber.ok || !afterRowId.ok) {
      return jsonResponse({ error: "invalid export cursor" }, 400);
    }
    const source = this.ctx.storage.sql.exec(
      "SELECT graph_id, prefix, generation, role, split_epoch, child_zero_prefix, child_one_prefix, migration_id, migration_state FROM shard_identity WHERE singleton = 1"
    ).toArray()[0];
    if (source?.graph_id !== graphId.value || source.prefix !== sourcePrefix.value || source.migration_id !== migrationId || source.migration_state !== "copying") {
      return jsonResponse({ error: "source is not fenced for this migration" }, 409);
    }
    if (targetPrefix.value !== source.child_zero_prefix && targetPrefix.value !== source.child_one_prefix) {
      return jsonResponse({ error: "target range is not a child of this split" }, 409);
    }
    const [lower, upper] = virtualKeyRange(targetPrefix.value);
    const columns = MIGRATION_TABLES[table];
    const selected = this.ctx.storage.sql.exec(
      `SELECT rowid AS copy_row_id, ${columns.join(", ")} FROM ${table}
       WHERE entity_hash BETWEEN ? AND ? AND rowid > ? ORDER BY rowid LIMIT ?`,
      lower,
      upper,
      afterRowId.value,
      SPLIT_COPY_PAGE_SIZE
    ).toArray();
    const rows = [];
    let lastRowId = afterRowId.value;
    let serializedBytes = 0;
    for (const selectedRow of selected) {
      const row = {};
      for (const column of columns) {
        row[column] = selectedRow[column] ?? null;
      }
      const rowBytes = new TextEncoder().encode(JSON.stringify(row)).byteLength;
      if (rows.length > 0 && serializedBytes + rowBytes > 15e5) break;
      if (rowBytes > 15e5) throw new ShardProtocolError(413, "one stored row exceeds the bounded split-page size");
      rows.push(row);
      serializedBytes += rowBytes;
      lastRowId = selectedRow.copy_row_id;
    }
    const hasMore = selected.length === SPLIT_COPY_PAGE_SIZE || rows.length < selected.length;
    return jsonResponse({
      migrationId,
      table,
      targetPrefix: targetPrefix.value,
      pageNumber: pageNumber.value,
      afterRowId: afterRowId.value,
      nextRowId: lastRowId,
      hasMore,
      pageHash: await sha256Hex(JSON.stringify(rows)),
      rows
    });
  }
  async importPage(request) {
    const input = await readJsonBody(request, 2e6);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid migration page" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const targetPrefix = parseVirtualPrefix(input.value["targetPrefix"]);
    const migrationId = input.value["migrationId"];
    const table = parseMigrationTable(input.value["table"]);
    const pageNumber = readNonNegativeInteger2(input.value["pageNumber"]);
    const pageHash = input.value["pageHash"];
    const inputRows = input.value["rows"];
    if (!graphId.ok || !targetPrefix.ok || typeof migrationId !== "string" || table === void 0 || !pageNumber.ok || typeof pageHash !== "string" || !/^[a-f0-9]{64}$/.test(pageHash) || !Array.isArray(inputRows)) {
      return jsonResponse({ error: "invalid migration page identity" }, 400);
    }
    const rows = [];
    const columns = MIGRATION_TABLES[table];
    for (const [index, inputRow] of inputRows.entries()) {
      if (!isRecord(inputRow) || Object.keys(inputRow).length !== columns.length) return jsonResponse({ error: `invalid migration row ${index}` }, 400);
      const row = {};
      for (const column of columns) {
        const value = inputRow[column];
        if (value !== null && typeof value !== "number" && typeof value !== "string") return jsonResponse({ error: `invalid ${column} in migration row` }, 400);
        row[column] = value;
      }
      const key = parseVirtualKey(row["entity_hash"]);
      if (!key.ok || !matchesPrefix(key.value, targetPrefix.value)) return jsonResponse({ error: "migration row is outside its target range" }, 409);
      rows.push(row);
    }
    if (await sha256Hex(JSON.stringify(rows)) !== pageHash) return jsonResponse({ error: "migration page digest mismatch" }, 409);
    const serializedBytes = migrationRowBytes(rows);
    const growthEstimate = serializedBytes * 3;
    const result = this.ctx.storage.transactionSync(() => {
      const identity = this.assertIdentity(graphId.value, targetPrefix.value);
      if (identity.role !== "leaf" || identity.migration_id !== migrationId || identity.migration_state !== "copying") {
        throw new ShardProtocolError(409, "target is not initialized for this migration");
      }
      const receipt = this.ctx.storage.sql.exec(
        `SELECT page_hash FROM migration_import_pages
         WHERE migration_id = ? AND table_name = ? AND target_prefix = ? AND page_number = ?`,
        migrationId,
        table,
        targetPrefix.value,
        pageNumber.value
      ).toArray()[0];
      if (receipt !== void 0) {
        if (receipt.page_hash !== pageHash) throw new ShardProtocolError(409, "migration page number was replayed with different contents");
        return "duplicate";
      }
      const reserved = this.ctx.storage.sql.exec(
        "SELECT migration_reserved_bytes FROM shard_accounting WHERE singleton = 1"
      ).toArray()[0]?.migration_reserved_bytes ?? 0;
      const nextReserve = Math.max(0, reserved - growthEstimate);
      const capacity = accountStorage(this.ctx.storage.sql.databaseSize, {
        factLogBytes: serializedBytes,
        activeIndexBytes: serializedBytes * 2,
        projectionBytes: 0,
        transactionStagingBytes: 0
      }, nextReserve);
      if (!capacity.canAdmit) throw new ShardProtocolError(413, "migration page would exceed the target's accounted capacity limit");
      const placeholders = columns.map(() => "?").join(", ");
      const insertSql = `INSERT OR IGNORE INTO ${table} (${columns.join(", ")}) VALUES (${placeholders})`;
      for (const row of rows) this.ctx.storage.sql.exec(insertSql, ...columns.map((column) => row[column]));
      this.ctx.storage.sql.exec(
        `INSERT INTO migration_import_pages (migration_id, table_name, target_prefix, page_number, page_hash, row_count)
         VALUES (?, ?, ?, ?, ?, ?)`,
        migrationId,
        table,
        targetPrefix.value,
        pageNumber.value,
        pageHash,
        rows.length
      );
      this.ctx.storage.sql.exec("UPDATE shard_accounting SET migration_reserved_bytes = ? WHERE singleton = 1", nextReserve);
      return "imported";
    });
    return jsonResponse({ status: result, rowCount: rows.length });
  }
  async finishChild(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid child finalize request" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const prefix = parseVirtualPrefix(input.value["prefix"]);
    const migrationId = input.value["migrationId"];
    if (!graphId.ok || !prefix.ok || typeof migrationId !== "string") return jsonResponse({ error: "invalid child finalize identity" }, 400);
    this.ctx.storage.transactionSync(() => {
      const identity = this.assertIdentity(graphId.value, prefix.value);
      if (identity.migration_id !== migrationId || identity.role !== "leaf") throw new ShardProtocolError(409, "child migration identity mismatch");
      this.ctx.storage.sql.exec("UPDATE shard_identity SET migration_state = 'active', migration_id = NULL WHERE singleton = 1");
      this.ctx.storage.sql.exec("UPDATE shard_accounting SET migration_reserved_bytes = 0 WHERE singleton = 1");
    });
    return jsonResponse({ status: "active" });
  }
  async cutover(request) {
    const input = await readJsonBody(request, 8192);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid cutover request" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const prefix = parseVirtualPrefix(input.value["prefix"]);
    const generation = readNonNegativeInteger2(input.value["generation"]);
    const migrationId = input.value["migrationId"];
    const splitEpoch = readPositiveInteger(input.value["splitEpoch"]);
    const left = parseVirtualPrefix(input.value["leftPrefix"]);
    const right = parseVirtualPrefix(input.value["rightPrefix"]);
    if (!graphId.ok || !prefix.ok || !generation.ok || typeof migrationId !== "string" || !splitEpoch.ok || !left.ok || !right.ok) {
      return jsonResponse({ error: "invalid cutover identity" }, 400);
    }
    this.ctx.storage.transactionSync(() => {
      const identity = this.assertIdentity(graphId.value, prefix.value);
      if (identity.role === "router" && identity.migration_id === migrationId && identity.split_epoch === splitEpoch.value) return;
      if (identity.role !== "leaf" || identity.generation !== generation.value || identity.migration_id !== migrationId || identity.migration_state !== "copying") {
        throw new ShardProtocolError(409, "source is not ready for cutover");
      }
      this.ctx.storage.sql.exec(
        `UPDATE shard_identity SET role = 'router', generation = generation + 1, migration_state = 'ready',
          split_epoch = ?, child_zero_prefix = ?, child_one_prefix = ? WHERE singleton = 1`,
        splitEpoch.value,
        left.value,
        right.value
      );
    });
    return jsonResponse({ status: "cut-over", splitEpoch: splitEpoch.value });
  }
  async countRange(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid migration count request" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const nodePrefix = parseVirtualPrefix(input.value["nodePrefix"]);
    const rangePrefix = parseVirtualPrefix(input.value["rangePrefix"]);
    const table = parseMigrationTable(input.value["table"]);
    if (!graphId.ok || !nodePrefix.ok || !rangePrefix.ok || table === void 0) return jsonResponse({ error: "invalid count range" }, 400);
    this.ctx.storage.transactionSync(() => this.assertIdentity(graphId.value, nodePrefix.value));
    const [lower, upper] = virtualKeyRange(rangePrefix.value);
    const count = this.ctx.storage.sql.exec(
      `SELECT COUNT(*) AS count FROM ${table} WHERE entity_hash BETWEEN ? AND ?`,
      lower,
      upper
    ).toArray()[0]?.count ?? 0;
    return jsonResponse({ count });
  }
  async abortSplit(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid split abort request" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const prefix = parseVirtualPrefix(input.value["prefix"]);
    const migrationId = input.value["migrationId"];
    if (!graphId.ok || !prefix.ok || typeof migrationId !== "string") return jsonResponse({ error: "invalid split abort identity" }, 400);
    this.ctx.storage.transactionSync(() => {
      const identity = this.assertIdentity(graphId.value, prefix.value);
      if (identity.role === "router") throw new ShardProtocolError(409, "a published split cannot be rolled back");
      if (identity.migration_id !== migrationId) return;
      this.ctx.storage.sql.exec(
        `UPDATE shard_identity SET migration_id = NULL, migration_state = 'active', split_epoch = NULL,
          child_zero_prefix = NULL, child_one_prefix = NULL WHERE singleton = 1`
      );
    });
    return jsonResponse({ status: "active" });
  }
  async retire(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value)) return jsonResponse({ error: "invalid retirement request" }, 400);
    const graphId = parseGraphId(input.value["graphId"]);
    const prefix = parseVirtualPrefix(input.value["prefix"]);
    const migrationId = input.value["migrationId"];
    if (!graphId.ok || !prefix.ok || typeof migrationId !== "string") return jsonResponse({ error: "invalid retirement identity" }, 400);
    this.ctx.storage.transactionSync(() => {
      const identity = this.assertIdentity(graphId.value, prefix.value);
      if (identity.role !== "router" || identity.migration_id !== migrationId) throw new ShardProtocolError(409, "router migration identity mismatch");
      if (identity.migration_state === "retired") return;
      for (const table of Object.keys(MIGRATION_TABLES)) this.ctx.storage.sql.exec(`DELETE FROM ${table}`);
      this.ctx.storage.sql.exec("DELETE FROM shard_transactions");
      this.ctx.storage.sql.exec("DELETE FROM migration_import_pages");
      this.ctx.storage.sql.exec("UPDATE shard_identity SET migration_state = 'retired' WHERE singleton = 1");
    });
    return jsonResponse({ status: "retired" });
  }
  estimateRange(prefix) {
    const [lower, upper] = virtualKeyRange(prefix);
    let rowCount = 0;
    let payloadBytes = 0;
    for (const table of Object.keys(MIGRATION_TABLES)) {
      const columns = MIGRATION_TABLES[table];
      const lengths = columns.map((column) => `COALESCE(LENGTH(CAST(${column} AS BLOB)), 0)`).join(" + ");
      const aggregate = this.ctx.storage.sql.exec(
        `SELECT COUNT(*) AS rows, COALESCE(SUM(${lengths} + 256), 0) AS bytes FROM ${table}
         WHERE entity_hash BETWEEN ? AND ?`,
        lower,
        upper
      ).toArray()[0];
      rowCount += aggregate?.rows ?? 0;
      payloadBytes += aggregate?.bytes ?? 0;
    }
    return { rowCount, reservedBytes: Math.ceil(payloadBytes * 3) + 1e6 };
  }
  async preflight(request) {
    const input = await readJsonBody(request, MAX_TRANSACTION_BYTES);
    if (!input.ok) return jsonResponse({ error: input.error.message }, 400);
    const batch = parseParticipantBatch(input.value);
    if (!batch.ok) return jsonResponse({ error: batch.error.message }, 400);
    for (const indexed of batch.value.facts) {
      const key = await virtualKeyForEntity(batch.value.graphId, indexed.fact.entity);
      if (key !== indexed.virtualKey || !matchesPrefix(key, batch.value.shardPrefix)) {
        return jsonResponse({ error: "preflight facts do not belong to this shard range" }, 409);
      }
    }
    const identity = this.ctx.storage.transactionSync(() => this.assertIdentity(batch.value.graphId, batch.value.shardPrefix));
    if (identity.role !== "leaf" || identity.generation !== batch.value.shardGeneration || identity.migration_state !== "active") {
      return jsonResponse({ error: "shard route is stale or topology is moving" }, 409);
    }
    return jsonResponse(this.capacityFor(batch.value.facts.map((indexed) => indexed.fact)));
  }
  assertWritableIdentity(graphId, prefix, generation) {
    const identity = this.assertIdentity(graphId, prefix);
    if (identity.role !== "leaf" || identity.generation !== generation || identity.migration_state !== "active") {
      throw new ShardProtocolError(409, "shard is not the active writable owner for this route");
    }
  }
  assertReadableIdentity(graphId, prefix, generation, epoch) {
    const identity = this.assertIdentity(graphId, prefix);
    if (identity.role === "leaf" && identity.generation === generation) return;
    if (identity.role === "router" && identity.split_epoch !== null && epoch < identity.split_epoch && generation === identity.generation - 1 && identity.migration_state !== "retired") return;
    throw new ShardProtocolError(409, "shard is not the readable owner for the requested directory epoch");
  }
  assertIdentity(graphId, prefix) {
    const row = this.ctx.storage.sql.exec(
      `SELECT graph_id, prefix, generation, role, split_epoch, child_zero_prefix, child_one_prefix, migration_id, migration_state
       FROM shard_identity WHERE singleton = 1`
    ).toArray()[0];
    if (row === void 0) {
      this.ctx.storage.sql.exec(
        `INSERT INTO shard_identity (singleton, graph_id, prefix, generation, role, split_epoch,
          child_zero_prefix, child_one_prefix, migration_id, migration_state)
         VALUES (1, ?, ?, 0, 'leaf', NULL, NULL, NULL, NULL, 'active')`,
        graphId,
        prefix
      );
      return {
        graph_id: graphId,
        prefix,
        generation: 0,
        role: "leaf",
        split_epoch: null,
        child_zero_prefix: null,
        child_one_prefix: null,
        migration_id: null,
        migration_state: "active"
      };
    }
    if (row.graph_id !== graphId || row.prefix !== prefix) {
      throw new ShardProtocolError(409, "Durable Object identity does not match its graph/prefix route");
    }
    return row;
  }
  capacityFor(facts) {
    const accounting = this.ctx.storage.sql.exec("SELECT migration_reserved_bytes, synthetic_size_bytes FROM shard_accounting WHERE singleton = 1").toArray()[0];
    const migrationReserve = accounting?.migration_reserved_bytes ?? 0;
    const syntheticSize = accounting?.synthetic_size_bytes ?? 0;
    const entities = [...new Set(facts.map((fact2) => fact2.entity))];
    const existingProjectionBytes = new Map(entities.map((entity) => [entity, 0]));
    for (let offset = 0; offset < entities.length; offset += 500) {
      const page = entities.slice(offset, offset + 500);
      const placeholders = page.map(() => "?").join(", ");
      const rows = this.ctx.storage.sql.exec(
        `SELECT entity, LENGTH(CAST(fields_json AS BLOB)) AS bytes FROM entity_versions
         WHERE valid_to_seq IS NULL AND entity IN (${placeholders})`,
        ...page
      ).toArray();
      for (const row of rows) existingProjectionBytes.set(row.entity, row.bytes);
    }
    return accountStorage(
      this.ctx.storage.sql.databaseSize + syntheticSize,
      estimateMutationFootprint(facts, existingProjectionBytes),
      migrationReserve
    );
  }
  assertCapacity(facts) {
    const account = this.capacityFor(facts);
    if (!account.canAdmit) throw new ShardProtocolError(413, `per-DO accounted capacity limit exceeded (${account.projectedAccountedBytes} bytes)`);
  }
};
function datalogValueToFactValue(field, value) {
  if (value.type === "integer") return Object.freeze({ type: "number", value: value.value });
  if (ENTITY_TEXT_FIELDS.has(field)) return Object.freeze({ type: "text", value: value.value });
  const reference = parseUri(value.value);
  return reference.ok ? Object.freeze({ type: "reference", value: reference.value }) : Object.freeze({ type: "text", value: value.value });
}
function readNonNegativeInteger2(input) {
  return typeof input === "number" && Number.isSafeInteger(input) && input >= 0 ? { ok: true, value: input } : { ok: false };
}
function readPositiveInteger(input) {
  return typeof input === "number" && Number.isSafeInteger(input) && input >= 1 ? { ok: true, value: input } : { ok: false };
}
function errorMessage2(error) {
  return error instanceof Error ? error.message : String(error);
}
var ShardProtocolError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
    this.name = "ShardProtocolError";
  }
  status;
};

// ../../poneglyph/src/todo_demo/hub.ts
import { DurableObject as DurableObject3 } from "cloudflare:workers";
var TodoHubDO = class extends DurableObject3 {
  async fetch(request) {
    const path = new URL(request.url).pathname;
    if (request.method === "POST" && path === "/broadcast") return await this.receiveInvalidation(request);
    if (request.method !== "GET" || path !== "/connect") return jsonResponse({ error: "not found" }, 404);
    if (request.headers.get("upgrade")?.toLowerCase() !== "websocket") {
      return jsonResponse({ error: "WebSocket upgrade required" }, 426);
    }
    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    this.ctx.acceptWebSocket(server);
    return new Response(null, { status: 101, webSocket: client });
  }
  async receiveInvalidation(request) {
    const input = await readJsonBody(request, 4096);
    if (!input.ok || !isRecord(input.value) || input.value["type"] !== "invalidate" || typeof input.value["graphId"] !== "string" || typeof input.value["txId"] !== "string" || typeof input.value["commitSeq"] !== "number" || !Array.isArray(input.value["changedLists"]) || !input.value["changedLists"].every((list) => typeof list === "string")) {
      return jsonResponse({ error: "invalid invalidation event" }, 400);
    }
    const result = this.broadcast(input.value);
    return jsonResponse(result);
  }
  broadcast(invalidation) {
    const message = JSON.stringify(invalidation);
    let delivered = 0;
    for (const socket of this.ctx.getWebSockets()) {
      try {
        if (socket.readyState === WebSocket.OPEN) {
          socket.send(message);
          delivered += 1;
        }
      } catch {
        try {
          socket.close(1011, "notification delivery failed");
        } catch {
        }
      }
    }
    return { delivered };
  }
  webSocketMessage(socket, message) {
    if (message === "ping") socket.send("pong");
  }
  webSocketClose() {
  }
  webSocketError() {
  }
};

// ../../poneglyph/src/worker.ts
var worker_default = {
  async fetch(request, env) {
    const todo = await handleTodoRequest(request, env);
    if (todo !== void 0) return todo;
    const match = /^\/v1\/graphs\/([^/]+)\/(transactions|query|entities)$/.exec(new URL(request.url).pathname);
    if (match === null) return jsonResponse({ error: "not found" }, 404);
    const graphId = parseGraphId(match[1]);
    if (!graphId.ok) return jsonResponse({ error: graphId.error.message, path: graphId.error.path }, 400);
    const coordinator = env.GRAPH_COORDINATORS.getByName(coordinatorObjectName(graphId.value));
    return coordinator.fetch(request);
  }
};

// worker/database.ts
var BenchCoordinatorDO = class extends GraphCoordinatorDO {
  audit() {
    return {
      state: this.ctx.storage.sql.exec("SELECT * FROM graph_state").toArray(),
      phases: this.ctx.storage.sql.exec("SELECT phase, COUNT(*) AS count FROM graph_transactions GROUP BY phase").toArray(),
      databaseBytes: this.ctx.storage.sql.databaseSize
    };
  }
};
var BenchShardDO = class extends GraphShardDO {
  audit(after) {
    const identity = this.ctx.storage.sql.exec("SELECT * FROM shard_identity").toArray();
    if (identity[0]?.role === "router") return { identity, facts: [] };
    return {
      identity,
      facts: this.ctx.storage.sql.exec("SELECT rowid AS ordinal, tx_id, source, entity, field, value_json, retraction FROM fact_log WHERE rowid > ? ORDER BY rowid LIMIT 512", after).toArray(),
      ...after === 0 ? {
        active: this.ctx.storage.sql.exec("SELECT COUNT(*) AS count FROM active_facts WHERE valid_to_seq IS NULL").toArray(),
        maxCommitSeq: this.ctx.storage.sql.exec("SELECT COALESCE(MAX(commit_seq), 0) AS value FROM fact_log").toArray(),
        mismatchedFacts: this.ctx.storage.sql.exec(`SELECT COUNT(*) AS count FROM active_facts f LEFT JOIN fact_log l ON l.fact_id = f.fact_id
        WHERE f.valid_to_seq IS NULL AND (l.fact_id IS NULL OR l.retraction != 0 OR f.source != l.source OR f.entity != l.entity
        OR f.field != l.field OR f.value_json != l.value_json OR f.tx_id != l.tx_id OR f.valid_from_seq != l.commit_seq)`).toArray(),
        mismatchedDatalog: this.ctx.storage.sql.exec(`SELECT COUNT(*) AS count FROM active_values WHERE valid_to_seq IS NULL AND
        (datalog_value != json_extract(value_json, '$.value') OR datalog_type != CASE json_extract(value_json, '$.type') WHEN 'number' THEN 'integer' ELSE 'string' END)`).toArray(),
        values: this.ctx.storage.sql.exec("SELECT COUNT(*) AS count FROM active_values WHERE valid_to_seq IS NULL").toArray(),
        mismatchedValues: this.ctx.storage.sql.exec(`SELECT COUNT(*) AS count FROM active_values v JOIN active_facts f ON f.fact_id = v.fact_id
        WHERE v.valid_to_seq IS NULL AND f.valid_to_seq IS NULL AND
        (v.entity != f.entity OR v.field != f.field OR v.source != f.source OR v.value_json != f.value_json OR v.value_key != f.value_json OR v.value_index != 0 OR v.valid_from_seq != f.valid_from_seq)`).toArray(),
        missingValues: this.ctx.storage.sql.exec(`SELECT COUNT(*) AS count FROM active_facts f WHERE f.valid_to_seq IS NULL AND NOT EXISTS
        (SELECT 1 FROM active_values v WHERE v.fact_id = f.fact_id AND v.valid_to_seq IS NULL)`).toArray(),
        orphanValues: this.ctx.storage.sql.exec(`SELECT COUNT(*) AS count FROM active_values v WHERE v.valid_to_seq IS NULL AND NOT EXISTS
        (SELECT 1 FROM active_facts f WHERE f.source = v.source AND f.entity = v.entity AND f.field = v.field
          AND f.value_json = v.value_json AND f.valid_to_seq IS NULL AND f.fact_id = v.fact_id)`).toArray(),
        statuses: this.ctx.storage.sql.exec("SELECT status, COUNT(*) AS count FROM shard_transactions GROUP BY status").toArray(),
        databaseBytes: this.ctx.storage.sql.databaseSize
      } : {}
    };
  }
};
var database_default = {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/__bench/")) {
      if (!env.AUDIT_TOKEN || request.headers.get("authorization") !== `Bearer ${env.AUDIT_TOKEN}`) return new Response("unauthorized", { status: 401 });
      if (url.pathname === "/__bench/coordinator") return Response.json(await env.GRAPH_COORDINATORS.getByName(coordinatorObjectName(env.GRAPH_ID)).audit());
      if (url.pathname === "/__bench/shard") {
        const prefix = parseVirtualPrefix(url.searchParams.get("prefix") ?? "");
        const after = Number(url.searchParams.get("after") ?? 0);
        if (!prefix.ok || !Number.isSafeInteger(after) || after < 0) return new Response("bad cursor", { status: 400 });
        return Response.json(await env.GRAPH_SHARDS.getByName(shardObjectName(env.GRAPH_ID, prefix.value)).audit(after));
      }
      return new Response("not found", { status: 404 });
    }
    return worker_default.fetch(request, env);
  }
};
export {
  BenchCoordinatorDO,
  BenchShardDO,
  TodoHubDO,
  database_default as default
};
